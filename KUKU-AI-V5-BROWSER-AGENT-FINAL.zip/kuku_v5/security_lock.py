import hashlib, json, os, sys, getpass

PASSWORD_HASH = "2b41609e839be304a434ade56f81a6147e8049f81cbad843e85bb9ebac3b2c49"  # filled below
MANIFEST_NAME = "SECURITY_MANIFEST.json"


def _base():
    return os.path.dirname(os.path.abspath(__file__))


def verify_password():
    try:
        pw = getpass.getpass("KUKU AI PASSWORD: ")
    except Exception:
        pw = input("KUKU AI PASSWORD: ")
    return hashlib.sha256(pw.encode("utf-8")).hexdigest() == PASSWORD_HASH


def verify_integrity():
    path=os.path.join(_base(), MANIFEST_NAME)
    try:
        data=json.load(open(path,'r',encoding='utf-8'))
        for rel, expected in data.get('files',{}).items():
            fp=os.path.join(_base(), rel)
            if not os.path.isfile(fp): return False, f"Missing file: {rel}"
            got=hashlib.sha256(open(fp,'rb').read()).hexdigest()
            if got != expected: return False, f"Changed file: {rel}"
        return True, "OK"
    except Exception as e:
        return False, str(e)
