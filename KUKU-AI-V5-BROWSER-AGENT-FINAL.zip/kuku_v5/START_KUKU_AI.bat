@echo off
setlocal
cd /d "%~dp0"
if "%GEMINI_API_KEY%"=="" (
  echo [KUKU AI] GEMINI_API_KEY is not set.
  echo Set it in PowerShell first: $env:GEMINI_API_KEY="YOUR_NEW_GEMINI_KEY"
  pause
  exit /b 1
)
python main.py
if errorlevel 1 pause
