# KUKU AI — KUKU Personal AI

KUKU AI is a separate assistant build based on the existing AHMAD JARVIS capabilities, with a new identity, UI palette, startup lock branding, and a different Gemini Live voice.

## Included capabilities
- Gemini Live voice conversation
- Windows local computer control (when Remote Control is enabled)
- Browser and application control
- File operations and code helper
- Multi-file developer agent
- Screen/camera vision and hand-gesture camera
- YouTube playback
- Web search and website scraping
- AI website builder
- Reminders, weather, system monitoring and memory
- Defensive camera security scanning for authorized private networks
- Defensive DDoS/network monitoring from the base build

## API key
The package intentionally does **not** bundle a Gemini API key. In PowerShell, set:

```powershell
$env:GEMINI_API_KEY="YOUR_NEW_GEMINI_KEY"
python main.py
```

Use a fresh key if an older key was exposed or rejected.

## Voice
The default Gemini Live voice is `Aoede`, distinct from the previous AHMAD JARVIS build.

## Safety
Computer control is intended for the user's own laptop. The security scanner is defensive only: it does not brute-force passwords, bypass authentication, exploit cameras, or disrupt networks.

## New in KUKU Agent Mode
- `agent_task` turns complex 3+ step goals into an explicit plan.
- Safe coding goals can be delegated automatically to the existing multi-file Dev Agent.
- Desktop/browser/file tasks remain routed through the native KUKU tools.
- No arbitrary shell runner, credential bypass, malware, DDoS, or destructive automation is added.


## V4 Visual Computer Agent
KUKU can inspect the current desktop screenshot with Gemini vision and execute a bounded sequence of ordinary UI actions. It refuses credential handling, security bypass, attacks, and destructive automation.


## V5 Browser Agent
KUKU can now plan bounded multi-step browser tasks from visible page text and execute ordinary navigation/search/click/type/scroll actions through the existing browser controller. Sensitive credential, payment, purchase, bypass, attack, and malware workflows are refused.
