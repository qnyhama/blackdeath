"""Safe local workspace inspection/test agent for KUKU AI.

It intentionally avoids arbitrary shell execution. Only read-only inspection,
git status/diff, and common project test/build commands are allowed.
"""
from __future__ import annotations

import os
import shlex
import subprocess
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
WORKSPACES = BASE_DIR / "workspace"
MAX_READ = 30000

_ALLOWED = {
    "pytest": {"pytest"},
    "python_tests": {"python", "python3", "py"},
    "npm_test": {"npm"},
    "node_test": {"node"},
    "cargo_test": {"cargo"},
    "git_status": {"git"},
}


def _root(path: str | None) -> Path:
    p = Path(path).expanduser() if path else WORKSPACES
    if not p.is_absolute():
        p = (BASE_DIR / p).resolve()
    else:
        p = p.resolve()
    return p


def _inside(root: Path, target: Path) -> bool:
    try:
        target.resolve().relative_to(root.resolve())
        return True
    except ValueError:
        return False


def _safe_rel(root: Path, rel: str) -> Path:
    target = (root / rel).resolve()
    if not _inside(root, target):
        raise ValueError("Path must stay inside the selected workspace.")
    return target


def _run(cmd: list[str], root: Path, timeout: int = 60) -> str:
    if not cmd:
        return "No command supplied."
    try:
        proc = subprocess.run(
            cmd, cwd=str(root), capture_output=True, text=True,
            encoding="utf-8", errors="replace", timeout=max(5, min(timeout, 180)),
            shell=False,
        )
        out = (proc.stdout or "").strip()
        err = (proc.stderr or "").strip()
        body = "\n\n".join(x for x in (out, err) if x)
        return f"exit_code={proc.returncode}\n{body[:12000]}" if body else f"exit_code={proc.returncode}"
    except subprocess.TimeoutExpired:
        return f"Timed out after {timeout}s."
    except Exception as exc:
        return f"Run failed: {exc}"


def workspace_agent(parameters: dict | None = None, **_) -> str:
    p = parameters or {}
    action = str(p.get("action", "inspect")).lower().strip()
    root = _root(p.get("workspace"))
    root.mkdir(parents=True, exist_ok=True)

    if action == "inspect":
        rows = []
        for item in sorted(root.rglob("*")):
            if any(part in {".git", "__pycache__", "node_modules", ".venv", "venv"} for part in item.parts):
                continue
            if item.is_file():
                rel = item.relative_to(root)
                rows.append(str(rel))
            if len(rows) >= 500:
                rows.append("… truncated at 500 files")
                break
        return "Workspace: %s\nFiles:\n%s" % (root, "\n".join(rows) if rows else "(empty)")

    if action == "read":
        rel = str(p.get("file", "")).strip()
        if not rel:
            return "Missing file path."
        target = _safe_rel(root, rel)
        if not target.is_file():
            return "File not found: %s" % rel
        try:
            text = target.read_text(encoding="utf-8")
            return text[:MAX_READ] + ("\n… truncated" if len(text) > MAX_READ else "")
        except Exception as exc:
            return f"Could not read file: {exc}"

    if action == "git_status":
        return _run(["git", "status", "--short"], root, 30)

    if action == "git_diff":
        return _run(["git", "diff", "--", "."], root, 30)

    if action in {"pytest", "python_tests", "npm_test", "node_test", "cargo_test"}:
        if action == "pytest":
            cmd = ["pytest"]
        elif action == "python_tests":
            cmd = ["python", "-m", "pytest"]
        elif action == "npm_test":
            cmd = ["npm", "test", "--", "--runInBand"]
        elif action == "node_test":
            cmd = ["node", "--test"]
        else:
            cmd = ["cargo", "test"]
        return _run(cmd, root, int(p.get("timeout", 60)))

    if action == "run_safe":
        raw = str(p.get("command", "")).strip()
        if not raw:
            return "Missing safe command."
        # Parse without a shell and reject shell operators/redirection.
        if any(token in raw for token in ("&&", "||", ";", "|", ">", "<", "`", "$(")):
            return "Blocked: shell chaining, pipes, redirection, and command substitution are not allowed."
        try:
            cmd = shlex.split(raw, posix=os.name != "nt")
        except ValueError as exc:
            return f"Invalid command: {exc}"
        if not cmd:
            return "Missing command."
        exe = Path(cmd[0]).name.lower()
        allowed = {x.lower() for group in _ALLOWED.values() for x in group}
        if exe not in allowed:
            return "Blocked command. Allowed tools are pytest, python test runner, npm test, node test, cargo test, and git status/diff."
        if exe == "git" and len(cmd) >= 2 and cmd[1] not in {"status", "diff"}:
            return "Blocked git operation. Only status and diff are allowed."
        if exe == "npm" and len(cmd) >= 2 and cmd[1] != "test":
            return "Blocked npm operation. Only npm test is allowed."
        if exe == "cargo" and len(cmd) >= 2 and cmd[1] != "test":
            return "Blocked cargo operation. Only cargo test is allowed."
        if exe in {"pytest", "python", "python3", "py", "node", "cargo", "npm", "git"}:
            return _run(cmd, root, int(p.get("timeout", 60)))

    return "Unknown workspace_agent action. Use inspect, read, git_status, git_diff, pytest, python_tests, npm_test, node_test, cargo_test, or run_safe."
