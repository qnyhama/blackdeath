"""KUKU AI Visual Computer Agent.

Uses a local screenshot + Gemini vision to choose a small, safe sequence of
ordinary desktop actions. It is intentionally bounded and does not handle
passwords, security bypasses, destructive commands, or hidden persistence.
"""
from __future__ import annotations

import io
import json
import os
from pathlib import Path
from typing import Any

from google import genai
from google.genai import types

try:
    import pyautogui
except ImportError:  # pragma: no cover
    pyautogui = None

from actions.computer_control import computer_control

BASE_DIR = Path(__file__).resolve().parent.parent
CONFIG = BASE_DIR / "config" / "api_keys.json"

ALLOWED = {"click", "double_click", "type", "press", "hotkey", "scroll", "move", "wait"}
BLOCK_WORDS = (
    "password", "passcode", "otp", "one-time code", "verification code",
    "credit card", "bank", "private key", "seed phrase", "api key",
    "delete everything", "format disk", "shutdown", "restart",
    "bypass", "brute force", "ddos", "malware", "credential",
)


def _api_key() -> str:
    key = os.environ.get("GEMINI_API_KEY", "").strip()
    if key:
        return key
    try:
        return str(json.loads(CONFIG.read_text(encoding="utf-8")).get("gemini_api_key") or "").strip()
    except Exception:
        return ""


def _client():
    key = _api_key()
    if not key:
        raise RuntimeError("GEMINI_API_KEY is not configured.")
    return genai.Client(api_key=key)


def _screenshot_bytes() -> bytes:
    if pyautogui is None:
        raise RuntimeError("PyAutoGUI is not installed. Run: pip install pyautogui")
    img = pyautogui.screenshot()
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return buf.getvalue()


def _blocked(text: str) -> bool:
    low = (text or "").lower()
    return any(w in low for w in BLOCK_WORDS)


def _ask_vision(goal: str, shot: bytes) -> dict[str, Any]:
    prompt = f"""You are KUKU AI's visual desktop agent.
User goal: {goal}

Look at the current screenshot and return ONLY JSON:
{{"done": false, "reason": "short", "actions": [
  {{"action":"click","x":100,"y":100}},
  {{"action":"type","text":"hello"}},
  {{"action":"press","key":"enter"}},
  {{"action":"hotkey","keys":"ctrl+l"}},
  {{"action":"scroll","direction":"down","amount":3}},
  {{"action":"move","x":100,"y":100}},
  {{"action":"wait","seconds":1}}
]}}

Rules:
- Choose at most 4 actions for this turn.
- Use coordinates only when clearly visible in the screenshot.
- Never interact with passwords, OTPs, API keys, banking/payment fields,
  private credentials, security controls, or authentication bypasses.
- Never delete files, format drives, install malware, launch attacks, or disable security.
- If the goal is destructive, credential-related, or unclear, return done=false,
  actions=[], and explain why in reason.
- Prefer navigation, opening apps, ordinary typing, clicking, scrolling, and waiting.
- If the goal is already satisfied, return done=true and actions=[].
"""
    contents = [
        types.Part.from_text(text=prompt),
        types.Part.from_bytes(data=shot, mime_type="image/png"),
    ]
    response = _client().models.generate_content(model="gemini-2.5-flash", contents=contents)
    text = (response.text or "").strip()
    if text.startswith("```"):
        text = text.strip("`")
        if text.startswith("json"):
            text = text[4:].strip()
    return json.loads(text)


def visual_computer_agent(parameters: dict | None = None, player=None) -> str:
    p = parameters or {}
    goal = str(p.get("goal") or p.get("description") or "").strip()
    max_rounds = max(1, min(int(p.get("rounds") or 4), 8))
    if not goal:
        return "KUKU: تکایە ئامانجی کاری کۆمپیوتەرەکەت بنووسە."
    if _blocked(goal):
        return "KUKU: ئەم داواکارییە credential/security یان کارێکی مەترسیدارە؛ جێبەجێی ناکەم."

    logs = []
    for rnd in range(1, max_rounds + 1):
        shot = _screenshot_bytes()
        plan = _ask_vision(goal, shot)
        if plan.get("done"):
            return "KUKU VISUAL AGENT: تەواوە.\n" + ("\n".join(logs) if logs else "هیچ کردارێک پێویست نەبوو.")

        actions = plan.get("actions") or []
        if not actions:
            return "KUKU VISUAL AGENT: " + str(plan.get("reason") or "نەتوانرا هەنگاوی دڵنیابەخش بدۆزرێتەوە.")

        for a in actions[:4]:
            action = str(a.get("action") or "").lower().strip()
            if action not in ALLOWED:
                continue
            text_blob = json.dumps(a, ensure_ascii=False)
            if _blocked(text_blob):
                return "KUKU VISUAL AGENT: هەنگاوێکی credential/security ناسرا؛ وەستاندرا."
            args = dict(a)
            args.pop("action", None)
            result = computer_control({"action": action, **args}, player=player)
            logs.append(f"R{rnd}: {action} → {result}")

    return "KUKU VISUAL AGENT: سنووری هەنگاوەکان گەیشتە کۆتایی.\n" + "\n".join(logs)
