"""KUKU AI safe multi-step agent orchestrator.

This module focuses on turning a complex user goal into a concrete plan and,
for software-development tasks, handing the implementation to the existing
Dev Agent. It deliberately does not provide arbitrary shell execution,
credential handling, security bypass, or destructive automation.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

from google import genai

try:
    from actions.dev_agent import dev_agent
except Exception:  # pragma: no cover
    dev_agent = None

BASE_DIR = Path(__file__).resolve().parent.parent
API_CONFIG_PATH = BASE_DIR / "config" / "api_keys.json"


def _api_key() -> str:
    key = os.environ.get("GEMINI_API_KEY", "").strip()
    if key:
        return key
    try:
        return str(json.loads(API_CONFIG_PATH.read_text(encoding="utf-8")).get("gemini_api_key") or "").strip()
    except Exception:
        return ""


def _model():
    key = _api_key()
    if not key:
        raise RuntimeError("GEMINI_API_KEY is not configured.")
    return genai.Client(api_key=key).models


def _plan(goal: str) -> dict[str, Any]:
    prompt = f"""You are KUKU AI's task planner.
Create a concise, practical plan for this user goal:
{goal}

Return ONLY valid JSON:
{{
  "category": "coding|desktop|browser|files|research|other",
  "goal": "short restatement",
  "steps": ["step 1", "step 2", "step 3"],
  "needs_confirmation": false,
  "notes": "short safety/implementation note"
}}

Rules:
- Never plan password cracking, authentication bypass, malware, DDoS attacks,
  unauthorized surveillance, credential theft, or destructive actions.
- For destructive actions, set needs_confirmation=true.
- Prefer existing KUKU tools over inventing capabilities.
- For software projects, category=coding.
"""
    response = _model().generate_content(model="gemini-2.5-flash", contents=prompt)
    text = (response.text or "").strip()
    if text.startswith("```"):
        text = text.strip("`")
        if text.startswith("json"):
            text = text[4:].strip()
    return json.loads(text)


def agent_task(parameters: dict, player=None, speak=None) -> str:
    p = parameters or {}
    goal = str(p.get("goal") or p.get("description") or "").strip()
    execute = bool(p.get("execute", True))
    if not goal:
        return "کاکە، ئامانجەکەت بۆ KUKU بنووسە."

    try:
        plan = _plan(goal)
    except Exception as exc:
        return f"KUKU Agent نتوانی پلانەکە دروست بکات: {exc}"

    steps = plan.get("steps") or []
    category = str(plan.get("category") or "other")
    confirmation = bool(plan.get("needs_confirmation"))

    if player:
        try:
            player.write_log(f"[Agent] Plan: {category} — {len(steps)} steps")
            for i, step in enumerate(steps, 1):
                player.write_log(f"[Agent] {i}. {step}")
        except Exception:
            pass

    # Only coding implementation is automatically delegated. Other categories
    # are returned as a plan so the main assistant can invoke the right native
    # tool(s) with the user's explicit intent and current state.
    if execute and category == "coding" and not confirmation and dev_agent is not None:
        result = dev_agent(
            parameters={
                "description": goal,
                "language": str(p.get("language") or "python"),
                "project_name": str(p.get("project_name") or "").strip(),
                "timeout": int(p.get("timeout") or 30),
            },
            player=player,
            speak=speak,
        )
        return "KUKU AGENT PLAN:\n" + "\n".join(f"{i}. {s}" for i, s in enumerate(steps, 1)) + "\n\n" + str(result)

    plan_text = "\n".join(f"{i}. {s}" for i, s in enumerate(steps, 1))
    if confirmation:
        return f"KUKU AGENT PLAN — confirmation required:\n{plan_text}\n\nNotes: {plan.get('notes','')}"
    return f"KUKU AGENT PLAN:\n{plan_text}\n\nNext native tool category: {category}."
