"""KUKU AI Browser Agent.

Bounded browser planner that reads visible page text and delegates ordinary,
non-sensitive browser actions to the existing browser_control tool.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

from google import genai
from google.genai import types

from actions.browser_control import browser_control

BASE_DIR = Path(__file__).resolve().parent.parent
CONFIG = BASE_DIR / "config" / "api_keys.json"

ALLOWED = {
    "go_to", "search", "click", "smart_click", "smart_type", "type",
    "press", "scroll", "back", "forward", "reload", "new_tab", "get_text",
}
BLOCK_WORDS = (
    "password", "passcode", "otp", "one-time code", "verification code",
    "api key", "secret key", "private key", "seed phrase", "credit card",
    "debit card", "bank account", "banking", "wallet", "buy", "purchase",
    "checkout", "pay now", "payment", "bypass", "brute force", "ddos",
    "malware", "credential", "delete account", "change password",
)


def _api_key() -> str:
    key = os.environ.get("GEMINI_API_KEY", "").strip()
    if key:
        return key
    try:
        return str(json.loads(CONFIG.read_text(encoding="utf-8")).get("gemini_api_key") or "").strip()
    except Exception:
        return ""


def _client():
    key = _api_key()
    if not key:
        raise RuntimeError("GEMINI_API_KEY is not configured.")
    return genai.Client(api_key=key)


def _blocked(text: str) -> bool:
    low = (text or "").lower()
    return any(w in low for w in BLOCK_WORDS)


def _plan(goal: str, page_text: str, current_url: str) -> dict[str, Any]:
    prompt = f"""You are KUKU AI's browser agent.
Goal: {goal}
Current URL: {current_url}
Visible page text (may be truncated):
{page_text[:9000]}

Return ONLY JSON in this format:
{{"done": false, "reason": "short", "actions": [
  {{"action":"search","query":"example query"}},
  {{"action":"smart_click","description":"Settings"}},
  {{"action":"smart_type","description":"Search","text":"hello"}},
  {{"action":"press","key":"Enter"}},
  {{"action":"scroll","direction":"down","amount":600}},
  {{"action":"go_to","url":"https://example.com"}},
  {{"action":"back"}},
  {{"action":"reload"}}
]}}

Rules:
- At most 4 actions this round.
- Use visible text and semantic descriptions whenever possible.
- Do not handle passwords, OTPs, API keys, payment/banking data, private credentials,
  security controls, authentication bypasses, purchases, account deletion, attacks,
  or malware. If the goal needs any of these, return done=false and actions=[].
- Do not invent successful outcomes. If the visible page shows the goal is complete,
  return done=true.
- Prefer ordinary navigation, search, reading, clicking public buttons/links,
  typing non-sensitive text, scrolling, and opening public pages.
"""
    response = _client().models.generate_content(
        model="gemini-2.5-flash",
        contents=[types.Part.from_text(text=prompt)],
    )
    text = (response.text or "").strip()
    if text.startswith("```"):
        text = text.strip("`")
        if text.startswith("json"):
            text = text[4:].strip()
    return json.loads(text)


def browser_agent(parameters: dict | None = None, player=None) -> str:
    p = parameters or {}
    goal = str(p.get("goal") or p.get("description") or "").strip()
    rounds = max(1, min(int(p.get("rounds") or 5), 8))
    browser = str(p.get("browser") or "").strip()
    if not goal:
        return "KUKU: تکایە ئامانجی browser ـەکە بنووسە."
    if _blocked(goal):
        return "KUKU BROWSER AGENT: ئەم داواکارییە لە بابەتی credential/payment/security ـە؛ جێبەجێ ناکرێت."

    logs: list[str] = []
    for rnd in range(1, rounds + 1):
        text_result = browser_control({"action": "get_text", "browser": browser} if browser else {"action": "get_text"}, player=player)
        url_result = browser_control({"action": "get_url", "browser": browser} if browser else {"action": "get_url"}, player=player)
        if _blocked(text_result) and any(w in text_result.lower() for w in ("password", "credit card", "api key", "seed phrase")):
            # Page may legitimately contain a login form; do not expose or interact with it.
            text_result = "[Sensitive form/content detected; do not interact with it.]"

        plan = _plan(goal, text_result, url_result)
        if plan.get("done"):
            return "KUKU BROWSER AGENT: تەواوە.\n" + "\n".join(logs)
        actions = plan.get("actions") or []
        if not actions:
            return "KUKU BROWSER AGENT: " + str(plan.get("reason") or "هەنگاوی دڵنیابەخش نەدۆزرایەوە.")

        for a in actions[:4]:
            action = str(a.get("action") or "").lower().strip()
            if action not in ALLOWED:
                continue
            blob = json.dumps(a, ensure_ascii=False)
            if _blocked(blob):
                return "KUKU BROWSER AGENT: هەنگاوی sensitive/security ناسرا؛ وەستاندرا."
            args = dict(a)
            args.pop("action", None)
            if browser:
                args["browser"] = browser
            result = browser_control({"action": action, **args}, player=player)
            logs.append(f"R{rnd}: {action} → {str(result)[:220]}")

    return "KUKU BROWSER AGENT: سنووری هەنگاوەکان گەیشتە کۆتایی.\n" + "\n".join(logs)
