# BLACKDEATH / JARVIS — Gemini Live

ئەم وەشانە کاتێک Gemini API key هەبێت ڕاستەوخۆ بە Gemini Live پەیوەندی دەکات و KUKU AI proxy بەکارناهێنێت. ئەمە سنووری ٥ خولەکەی KUKU AI لادەبات؛ quota/rate-limit ـەکانی Google هێشتا هەیە.

## Windows PowerShell
لە ناو فولدەری پرۆژەکە:

```powershell
$env:GEMINI_API_KEY = "YOUR_GEMINI_API_KEY"
py -m pip install -r requirements.txt
py main.py
```

Firebase API key ـی وێبسایتی BLACKDEATH بە تەنیا جێگرەوەی Gemini API key نییە. وێبسایتەکە Gemini لە ڕێگەی Firebase AI Logic بۆ chat بەکاردهێنێت؛ voice backend ـی Gemini Live ـی تایبەتی لە فایلەکەدا نەدۆزرایەوە.
