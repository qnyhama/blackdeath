#!/usr/bin/env python3
"""
Ahmad Death — Main Interface
Terminal UI with voice support
"""

import sys
import os
import json
import threading
import time
from pathlib import Path

# Add parent to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from core.main import load_config, save_config, load_memory, BASE_DIR, MEMORY_FILE
from modules.brain import Brain
from modules.tts import TTS
from modules.stt import STT
from modules.remote_control import RemoteControl
from modules.osint import OSINT
from modules.cybersec import CyberSec


# ── ANSI Colors ───────────────────────────────────────────────────────────────
RED     = "\033[91m"
GREEN   = "\033[92m"
YELLOW  = "\033[93m"
BLUE    = "\033[94m"
PURPLE  = "\033[95m"
CYAN    = "\033[96m"
WHITE   = "\033[97m"
GRAY    = "\033[90m"
BOLD    = "\033[1m"
RESET   = "\033[0m"

BANNER = f"""
{RED}{BOLD}
 █████╗ ██╗  ██╗███╗   ███╗ █████╗ ██████╗      ██████╗ ███████╗ █████╗ ████████╗██╗  ██╗
██╔══██╗██║  ██║████╗ ████║██╔══██╗██╔══██╗     ██╔══██╗██╔════╝██╔══██╗╚══██╔══╝██║  ██║
███████║███████║██╔████╔██║███████║██║  ██║     ██║  ██║█████╗  ███████║   ██║   ███████║
██╔══██║██╔══██║██║╚██╔╝██║██╔══██║██║  ██║     ██║  ██║██╔══╝  ██╔══██║   ██║   ██╔══██║
██║  ██║██║  ██║██║ ╚═╝ ██║██║  ██║██████╔╝     ██████╔╝███████╗██║  ██║   ██║   ██║  ██║
╚═╝  ╚═╝╚═╝  ╚═╝╚═╝     ╚═╝╚═╝  ╚═╝╚═════╝      ╚═════╝ ╚══════╝╚═╝  ╚═╝   ╚═╝   ╚═╝  ╚═╝
{RESET}{GRAY}
  Local AI · Cybersecurity · OSINT · Remote Control · No Limits · 2026
  بەرنامەی تایبەتی — بەبێ چاودێری — بەبێ سنور
{RESET}"""

HELP_TEXT = f"""
{CYAN}{BOLD}━━━━━━━━━━━━━━━━━━━━━━━━ COMMANDS ━━━━━━━━━━━━━━━━━━━━━━━━{RESET}
{YELLOW}  /help       {RESET}— Show this menu
{YELLOW}  /voice on   {RESET}— Enable voice output (TTS)
{YELLOW}  /voice off  {RESET}— Disable voice output
{YELLOW}  /mic        {RESET}— Record voice input (STT)
{YELLOW}  /cmd <cmd>  {RESET}— Run shell command on laptop
{YELLOW}  /osint <u>  {RESET}— OSINT username search
{YELLOW}  /ip <addr>  {RESET}— IP geolocation lookup
{YELLOW}  /portscan <host>{RESET} — Quick port scan
{YELLOW}  /dorks <target>{RESET} — Generate Google dorks
{YELLOW}  /sysinfo    {RESET}— Show laptop system info
{YELLOW}  /procs      {RESET}— List running processes
{YELLOW}  /nets       {RESET}— Show network connections
{YELLOW}  /shells <ip> <port>{RESET} — Generate reverse shells
{YELLOW}  /privesc    {RESET}— Linux privesc checklist
{YELLOW}  /clear      {RESET}— Clear conversation
{YELLOW}  /memory     {RESET}— Show stored memory
{YELLOW}  /remember <fact>{RESET} — Add fact to memory
{YELLOW}  /config     {RESET}— Show current config
{YELLOW}  /exit       {RESET}— Exit Ahmad Death
{CYAN}{BOLD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━{RESET}
"""


class AhmadDeath:
    def __init__(self):
        print(BANNER)
        print(f"{GRAY}Loading config...{RESET}")

        self.cfg = load_config()
        self.memory_data = load_memory()

        # Init modules
        self.brain = Brain(
            api_key=self.cfg.get("anthropic_api_key", ""),
            memory_file=MEMORY_FILE,
            web_search=self.cfg.get("web_search_enabled", True)
        )
        self.tts = TTS(
            api_key=self.cfg["elevenlabs_api_key"],
            voice_id=self.cfg.get("voice_id", "pNInz6obpgDQGcFmaJgB")
        ) if self.cfg.get("tts_enabled") else None

        self.stt = STT(model_size="base") if self.cfg.get("stt_enabled") else None
        self.rc = RemoteControl()
        self.osint = OSINT()
        self.cybersec = CyberSec()

        self.voice_on = self.cfg.get("tts_enabled", False)

        print(f"{GREEN}✓ Ahmad Death initialized{RESET}")
        print(f"{GRAY}  TTS: {'ON' if self.voice_on else 'OFF'} | "
              f"STT: {'ON' if self.stt else 'OFF'} | "
              f"Web Search: {'ON' if self.cfg.get('web_search_enabled') else 'OFF'}{RESET}")

        # Check Anthropic API key
        if not self.cfg.get("anthropic_api_key"):
            print(f"\n{YELLOW}⚠ No Anthropic API key set.{RESET}")
            print(f"{GRAY}  Get one at: https://console.anthropic.com{RESET}")
            print(f"{GRAY}  Set it in: config/config.json → anthropic_api_key{RESET}\n")

        print(f"\n{GRAY}Type /help for commands. Start chatting:{RESET}\n")

    def _speak(self, text: str):
        """Speak text if voice is on."""
        if self.voice_on and self.tts:
            t = threading.Thread(target=self.tts.speak, args=(text,), daemon=True)
            t.start()

    def _handle_remote_actions(self, response: str) -> str:
        """Parse and execute remote control commands from AI response."""
        import re
        lines = response.split("\n")
        outputs = []

        for line in lines:
            if line.startswith("[CMD]:"):
                cmd = line[6:].strip()
                print(f"{YELLOW}  → Running: {cmd}{RESET}")
                result = self.rc.run_command(cmd)
                out = result.get("stdout", "") + result.get("stderr", "")
                outputs.append(f"[CMD OUTPUT]\n{out}")

            elif line.startswith("[PYTHON]:"):
                code = line[9:].strip()
                print(f"{YELLOW}  → Python exec{RESET}")
                result = self.rc.run_python(code)
                out = result.get("stdout", "") + result.get("stderr", "")
                outputs.append(f"[PYTHON OUTPUT]\n{out}")

            elif line.startswith("[FILE_READ]:"):
                path = line[12:].strip()
                content = self.rc.read_file(path)
                outputs.append(f"[FILE: {path}]\n{content[:500]}")

            elif line.startswith("[FILE_WRITE]:"):
                parts = line[13:].strip().split("|", 1)
                if len(parts) == 2:
                    result = self.rc.write_file(parts[0].strip(), parts[1].strip())
                    outputs.append(f"[WRITE] {result}")

        return "\n".join(outputs) if outputs else ""

    def _run_command(self, cmd: str):
        """Handle /cmd command."""
        print(f"{YELLOW}  Executing: {cmd}{RESET}")
        result = self.rc.run_command(cmd)
        stdout = result.get("stdout", "")
        stderr = result.get("stderr", "")
        retcode = result.get("returncode", -1)

        if stdout:
            print(f"{GREEN}{stdout}{RESET}")
        if stderr:
            print(f"{RED}{stderr}{RESET}")
        print(f"{GRAY}  Exit code: {retcode}{RESET}")

    def _osint_search(self, username: str):
        """Handle /osint command."""
        print(f"{CYAN}  Searching '{username}' across platforms...{RESET}")
        results = self.osint.username_search(username)
        found_count = 0
        for platform, info in results.items():
            status = info.get("status", "")
            if "FOUND" in status:
                print(f"  {GREEN}✓ {platform:<20}{RESET} {info['url']}")
                found_count += 1
            elif "NOT FOUND" in status:
                print(f"  {GRAY}✗ {platform}{RESET}")
            else:
                print(f"  {YELLOW}? {platform:<20}{RESET} {status}")
        print(f"\n{CYAN}  Found on {found_count}/{len(results)} platforms{RESET}")

    def run(self):
        """Main interaction loop."""
        while True:
            try:
                user_input = input(f"\n{BOLD}{RED}You{RESET} {GRAY}»{RESET} ").strip()
            except (EOFError, KeyboardInterrupt):
                print(f"\n{GRAY}Ahmad Death signing off.{RESET}")
                break

            if not user_input:
                continue

            # ── Built-in commands ──────────────────────────────────────────
            if user_input == "/exit":
                print(f"{GRAY}Ahmad Death signing off.{RESET}")
                break

            elif user_input == "/help":
                print(HELP_TEXT)

            elif user_input == "/voice on":
                self.voice_on = True
                print(f"{GREEN}  Voice output enabled.{RESET}")

            elif user_input == "/voice off":
                self.voice_on = False
                print(f"{GRAY}  Voice output disabled.{RESET}")

            elif user_input == "/mic":
                if not self.stt:
                    print(f"{RED}  STT disabled in config.{RESET}")
                else:
                    print(f"{CYAN}  Recording 5 seconds...{RESET}")
                    result = self.stt.record_and_transcribe(duration=5)
                    text = result.get("text", "")
                    if text:
                        print(f"{GRAY}  Heard: {text}{RESET}")
                        user_input = text
                        # fall through to AI chat
                    else:
                        print(f"{RED}  No speech detected.{RESET}")
                        continue

            elif user_input.startswith("/cmd "):
                self._run_command(user_input[5:])
                continue

            elif user_input == "/sysinfo":
                info = self.rc.system_info()
                for k, v in info.items():
                    if k != "network_interfaces":
                        print(f"  {CYAN}{k:<20}{RESET} {v}")
                continue

            elif user_input == "/procs":
                procs = self.rc.list_processes()[:20]
                print(f"  {'PID':<8} {'NAME':<30} {'CPU%':<8} {'MEM MB'}")
                print(f"  {'─'*60}")
                for p in procs:
                    print(f"  {p['pid']:<8} {p['name']:<30} {p['cpu']:<8} {p['mem_mb']}")
                continue

            elif user_input == "/nets":
                conns = self.rc.network_connections()[:20]
                for c in conns:
                    print(f"  {c.get('laddr',''):<25} → {c.get('raddr',''):<25} [{c.get('status','')}]")
                continue

            elif user_input.startswith("/osint "):
                self._osint_search(user_input[7:].strip())
                continue

            elif user_input.startswith("/ip "):
                ip = user_input[4:].strip()
                data = self.osint.ip_lookup(ip)
                for k, v in data.items():
                    print(f"  {CYAN}{k:<20}{RESET} {v}")
                continue

            elif user_input.startswith("/portscan "):
                host = user_input[10:].strip()
                print(f"{CYAN}  Scanning {host}...{RESET}")
                results = self.osint.port_scan(host)
                for port, status in results.items():
                    color = GREEN if status == "OPEN" else GRAY
                    print(f"  {color}{port:<8} {status}{RESET}")
                continue

            elif user_input.startswith("/dorks "):
                target = user_input[7:].strip()
                dorks = self.osint.generate_dorks(target)
                for d in dorks:
                    print(f"  {CYAN}{d['dork']}{RESET}")
                    print(f"  {GRAY}{d['url']}{RESET}\n")
                continue

            elif user_input.startswith("/shells "):
                parts = user_input.split()
                if len(parts) >= 3:
                    shells = self.cybersec.reverse_shells(parts[1], int(parts[2]))
                    for lang, cmd in shells.items():
                        print(f"\n  {CYAN}{lang}{RESET}")
                        print(f"  {cmd}")
                continue

            elif user_input == "/privesc":
                checks = self.cybersec.linux_privesc_checklist()
                for c in checks:
                    print(f"  {CYAN}{c['check']}{RESET}")
                    print(f"  {GRAY}{c['cmd']}{RESET}\n")
                continue

            elif user_input == "/clear":
                self.brain.clear_conversation()
                print(f"{GRAY}  Conversation cleared. Memory kept.{RESET}")
                continue

            elif user_input == "/memory":
                mem = self.brain.memory
                print(f"\n{CYAN}  Stored Facts:{RESET}")
                for f in mem.get("facts", [])[-10:]:
                    print(f"  {GRAY}• {f}{RESET}")
                print(f"\n{CYAN}  Session Summaries:{RESET}")
                for s in mem.get("summaries", [])[-5:]:
                    print(f"  {GRAY}• {s}{RESET}")
                continue

            elif user_input.startswith("/remember "):
                fact = user_input[10:].strip()
                self.brain.remember(fact)
                print(f"{GREEN}  Remembered: {fact}{RESET}")
                continue

            elif user_input == "/config":
                cfg_copy = {k: v for k, v in self.cfg.items() if "key" not in k.lower()}
                for k, v in cfg_copy.items():
                    print(f"  {CYAN}{k:<25}{RESET} {v}")
                continue

            # ── AI Chat ────────────────────────────────────────────────────
            print(f"\n{GRAY}Ahmad Death thinking...{RESET}", end="\r")

            response = self.brain.chat(user_input)

            # Handle remote control actions
            rc_output = self._handle_remote_actions(response)

            # Clean response for display (remove CMD markers)
            display_response = response
            for prefix in ["[CMD]:", "[PYTHON]:", "[FILE_READ]:", "[FILE_WRITE]:"]:
                lines = [l for l in display_response.split("\n") if not l.startswith(prefix)]
                display_response = "\n".join(lines)

            print(f"\r{BOLD}{RED}Ahmad Death{RESET} {GRAY}»{RESET}")
            print(f"{WHITE}{display_response.strip()}{RESET}")

            if rc_output:
                print(f"\n{YELLOW}{rc_output}{RESET}")

            self._speak(display_response[:300])  # speak first 300 chars


def main():
    # Check Python version
    if sys.version_info < (3, 8):
        print("Python 3.8+ required")
        sys.exit(1)

    try:
        ai = AhmadDeath()
        ai.run()
    except KeyboardInterrupt:
        print("\n\nAhmad Death offline.")


if __name__ == "__main__":
    main()
