"""
Ahmad Death — OSINT Module
Username enum, email/phone lookup, IP geo, metadata, social media intelligence
"""

import re
import json
import socket
import urllib.request
import urllib.parse
import subprocess
from pathlib import Path
from datetime import datetime


class OSINT:
    def __init__(self):
        self.results = {}

    # ── Username Enumeration ─────────────────────────────────────────────────
    PLATFORMS = {
        "GitHub":        "https://github.com/{u}",
        "Twitter/X":     "https://twitter.com/{u}",
        "Instagram":     "https://www.instagram.com/{u}/",
        "TikTok":        "https://www.tiktok.com/@{u}",
        "Reddit":        "https://www.reddit.com/user/{u}",
        "YouTube":       "https://www.youtube.com/@{u}",
        "Telegram":      "https://t.me/{u}",
        "LinkedIn":      "https://www.linkedin.com/in/{u}",
        "Pinterest":     "https://www.pinterest.com/{u}",
        "Snapchat":      "https://www.snapchat.com/add/{u}",
        "Twitch":        "https://www.twitch.tv/{u}",
        "Steam":         "https://steamcommunity.com/id/{u}",
        "Spotify":       "https://open.spotify.com/user/{u}",
        "Patreon":       "https://www.patreon.com/{u}",
        "Keybase":       "https://keybase.io/{u}",
        "GitLab":        "https://gitlab.com/{u}",
        "Medium":        "https://medium.com/@{u}",
        "Quora":         "https://www.quora.com/profile/{u}",
        "Roblox":        "https://www.roblox.com/user.aspx?username={u}",
        "Fiverr":        "https://www.fiverr.com/{u}",
    }

    def username_search(self, username: str) -> dict:
        """Check username across major platforms."""
        found = {}
        for platform, url_template in self.PLATFORMS.items():
            url = url_template.replace("{u}", urllib.parse.quote(username))
            try:
                req = urllib.request.Request(
                    url,
                    headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}
                )
                with urllib.request.urlopen(req, timeout=5) as resp:
                    code = resp.getcode()
                    if code == 200:
                        found[platform] = {"url": url, "status": "FOUND"}
                    else:
                        found[platform] = {"url": url, "status": f"HTTP {code}"}
            except urllib.error.HTTPError as e:
                if e.code == 404:
                    found[platform] = {"url": url, "status": "NOT FOUND"}
                else:
                    found[platform] = {"url": url, "status": f"HTTP {e.code}"}
            except Exception as e:
                found[platform] = {"url": url, "status": f"ERROR: {e}"}
        return found

    # ── IP Intelligence ──────────────────────────────────────────────────────
    def ip_lookup(self, ip: str) -> dict:
        """Geolocate and get info on an IP address."""
        try:
            url = f"http://ip-api.com/json/{ip}?fields=status,message,country,countryCode,region,regionName,city,zip,lat,lon,timezone,isp,org,as,query"
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=10) as resp:
                data = json.loads(resp.read().decode())
            return data
        except Exception as e:
            return {"error": str(e)}

    def my_ip(self) -> str:
        """Get public IP of this machine."""
        try:
            with urllib.request.urlopen("https://api.ipify.org", timeout=5) as resp:
                return resp.read().decode().strip()
        except:
            return "unknown"

    def reverse_dns(self, ip: str) -> str:
        """Reverse DNS lookup."""
        try:
            return socket.gethostbyaddr(ip)[0]
        except:
            return "no reverse DNS"

    def port_scan(self, host: str, ports: list = None) -> dict:
        """Quick TCP port scan."""
        if ports is None:
            ports = [21, 22, 23, 25, 53, 80, 110, 143, 443, 445, 3306, 3389, 5432, 6379, 8080, 8443]
        results = {}
        for port in ports:
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(1)
                result = sock.connect_ex((host, port))
                results[port] = "OPEN" if result == 0 else "CLOSED"
                sock.close()
            except Exception as e:
                results[port] = f"ERROR: {e}"
        return results

    def dns_lookup(self, domain: str) -> dict:
        """DNS records for a domain."""
        records = {}
        record_types = ["A", "AAAA", "MX", "NS", "TXT", "CNAME"]
        for rtype in record_types:
            try:
                result = subprocess.run(
                    ["nslookup", "-type=" + rtype, domain],
                    capture_output=True, text=True, timeout=5
                )
                records[rtype] = result.stdout
            except:
                records[rtype] = "error"
        return records

    def whois(self, domain: str) -> str:
        """WHOIS lookup."""
        try:
            result = subprocess.run(["whois", domain], capture_output=True, text=True, timeout=10)
            return result.stdout
        except:
            return "whois not available — install whois package"

    # ── Email OSINT ──────────────────────────────────────────────────────────
    def email_validate(self, email: str) -> dict:
        """Basic email validation and domain check."""
        pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        is_valid = bool(re.match(pattern, email))
        domain = email.split("@")[-1] if "@" in email else ""
        result = {
            "email": email,
            "valid_format": is_valid,
            "domain": domain,
        }
        if domain:
            # check MX record
            try:
                r = subprocess.run(["nslookup", "-type=MX", domain], capture_output=True, text=True, timeout=5)
                result["mx_records"] = r.stdout
            except:
                result["mx_records"] = "unavailable"
        return result

    def breach_check_hint(self, email: str) -> str:
        """Hint for breach checking (requires HaveIBeenPwned API key)."""
        return f"Check {email} at: https://haveibeenpwned.com/account/{urllib.parse.quote(email)}\nAPI: https://haveibeenpwned.com/API/v3"

    # ── Phone OSINT ──────────────────────────────────────────────────────────
    def phone_info(self, phone: str) -> dict:
        """Basic phone number analysis."""
        clean = re.sub(r'[^\d+]', '', phone)
        info = {"raw": phone, "cleaned": clean}

        country_prefixes = {
            "+964": "Iraq",  "+90": "Turkey", "+98": "Iran",
            "+1": "USA/Canada", "+44": "UK", "+49": "Germany",
            "+7": "Russia", "+86": "China", "+91": "India",
            "+33": "France", "+34": "Spain", "+39": "Italy",
            "+55": "Brazil", "+81": "Japan", "+82": "South Korea",
        }
        for prefix, country in country_prefixes.items():
            if clean.startswith(prefix):
                info["country"] = country
                info["prefix"] = prefix
                break

        return info

    # ── Metadata Extraction ───────────────────────────────────────────────────
    def extract_metadata(self, file_path: str) -> dict:
        """Extract metadata from files (images, docs, etc.)."""
        try:
            # Try exiftool first
            result = subprocess.run(
                ["exiftool", "-json", file_path],
                capture_output=True, text=True, timeout=15
            )
            if result.returncode == 0:
                data = json.loads(result.stdout)
                return data[0] if data else {}
        except FileNotFoundError:
            pass
        except Exception as e:
            return {"error": str(e)}

        # Fallback: basic file info
        p = Path(file_path)
        if not p.exists():
            return {"error": "File not found"}
        stat = p.stat()
        return {
            "filename": p.name,
            "size_bytes": stat.st_size,
            "created": datetime.fromtimestamp(stat.st_ctime).isoformat(),
            "modified": datetime.fromtimestamp(stat.st_mtime).isoformat(),
            "extension": p.suffix,
            "note": "Install exiftool for full metadata extraction"
        }

    # ── Network Recon ─────────────────────────────────────────────────────────
    def nmap_scan(self, target: str, flags: str = "-sV -O --open") -> str:
        """Run nmap scan (requires nmap installed)."""
        try:
            result = subprocess.run(
                ["nmap"] + flags.split() + [target],
                capture_output=True, text=True, timeout=120
            )
            return result.stdout or result.stderr
        except FileNotFoundError:
            return "nmap not installed — sudo apt install nmap"
        except Exception as e:
            return str(e)

    def traceroute(self, host: str) -> str:
        """Traceroute to host."""
        import platform
        cmd = "tracert" if platform.system() == "Windows" else "traceroute"
        try:
            result = subprocess.run([cmd, host], capture_output=True, text=True, timeout=30)
            return result.stdout
        except FileNotFoundError:
            return f"{cmd} not available"
        except Exception as e:
            return str(e)

    # ── Google Dorking ────────────────────────────────────────────────────────
    def generate_dorks(self, target: str) -> list:
        """Generate Google dorks for a target."""
        dorks = [
            f'site:{target}',
            f'site:{target} filetype:pdf',
            f'site:{target} filetype:doc OR filetype:docx',
            f'site:{target} filetype:xls OR filetype:xlsx',
            f'site:{target} inurl:admin',
            f'site:{target} inurl:login',
            f'site:{target} intext:password',
            f'site:{target} intext:"index of"',
            f'site:{target} ext:env OR ext:config OR ext:cfg',
            f'site:{target} ext:sql',
            f'site:{target} ext:log',
            f'"@{target}" email',
            f'"{target}" site:linkedin.com',
            f'"{target}" site:pastebin.com',
            f'intitle:"index of" site:{target}',
        ]
        search_base = "https://www.google.com/search?q="
        return [{"dork": d, "url": search_base + urllib.parse.quote(d)} for d in dorks]

    # ── Shodan-style Banner Grab ──────────────────────────────────────────────
    def banner_grab(self, host: str, port: int) -> str:
        """Grab service banner from host:port."""
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(3)
            sock.connect((host, port))
            sock.send(b"HEAD / HTTP/1.0\r\n\r\n")
            banner = sock.recv(1024).decode("utf-8", errors="replace")
            sock.close()
            return banner
        except Exception as e:
            return f"[ERROR] {e}"
