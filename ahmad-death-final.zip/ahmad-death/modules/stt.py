"""
Ahmad Death — STT Module
Speech-to-text using faster-whisper (local, offline)
"""

import subprocess
import tempfile
import os
import threading
from pathlib import Path


class STT:
    def __init__(self, model_size: str = "base"):
        """
        model_size options: tiny, base, small, medium, large
        Larger = more accurate but slower
        """
        self.model_size = model_size
        self._model = None
        self._lock = threading.Lock()

    def _load_model(self):
        """Lazy load whisper model."""
        if self._model is None:
            try:
                from faster_whisper import WhisperModel
                self._model = WhisperModel(self.model_size, device="cpu", compute_type="int8")
                print(f"[STT] Whisper model '{self.model_size}' loaded.")
            except ImportError:
                print("[STT] faster-whisper not installed. Run: pip install faster-whisper")
                self._model = None

    def transcribe_file(self, audio_path: str, language: str = None) -> dict:
        """Transcribe an audio file."""
        self._load_model()
        if self._model is None:
            return {"error": "Whisper not installed", "text": ""}

        try:
            segments, info = self._model.transcribe(
                audio_path,
                language=language,  # None = auto-detect
                beam_size=5,
                vad_filter=True,
            )
            text = " ".join([seg.text for seg in segments]).strip()
            return {
                "text": text,
                "language": info.language,
                "language_probability": round(info.language_probability, 3),
                "duration": round(info.duration, 2)
            }
        except Exception as e:
            return {"error": str(e), "text": ""}

    def record_and_transcribe(self, duration: int = 5, language: str = None) -> dict:
        """Record from microphone and transcribe."""
        tmp = tempfile.NamedTemporaryFile(suffix=".wav", delete=False)
        tmp_path = tmp.name
        tmp.close()

        print(f"[STT] Recording for {duration} seconds...")

        recorded = self._record_audio(tmp_path, duration)
        if not recorded:
            return {"error": "Recording failed", "text": ""}

        result = self.transcribe_file(tmp_path, language=language)

        try:
            os.unlink(tmp_path)
        except:
            pass

        return result

    def _record_audio(self, output_path: str, duration: int) -> bool:
        """Record audio using available system tools."""
        # Try PyAudio first
        try:
            import pyaudio
            import wave

            CHUNK = 1024
            FORMAT = pyaudio.paInt16
            CHANNELS = 1
            RATE = 16000

            p = pyaudio.PyAudio()
            stream = p.open(format=FORMAT, channels=CHANNELS,
                           rate=RATE, input=True, frames_per_buffer=CHUNK)

            frames = []
            for _ in range(0, int(RATE / CHUNK * duration)):
                data = stream.read(CHUNK, exception_on_overflow=False)
                frames.append(data)

            stream.stop_stream()
            stream.close()
            p.terminate()

            with wave.open(output_path, 'wb') as wf:
                wf.setnchannels(CHANNELS)
                wf.setsampwidth(p.get_sample_size(FORMAT))
                wf.setframerate(RATE)
                wf.writeframes(b''.join(frames))

            return True

        except ImportError:
            pass
        except Exception as e:
            print(f"[STT] PyAudio error: {e}")

        # Fallback: arecord (Linux)
        try:
            result = subprocess.run(
                ["arecord", "-d", str(duration), "-f", "cd", "-t", "wav", output_path],
                capture_output=True, timeout=duration + 5
            )
            return result.returncode == 0
        except FileNotFoundError:
            pass

        # Fallback: sox
        try:
            result = subprocess.run(
                ["rec", "-r", "16000", "-c", "1", output_path, "trim", "0", str(duration)],
                capture_output=True, timeout=duration + 5
            )
            return result.returncode == 0
        except FileNotFoundError:
            pass

        print("[STT] No recording tool found. Install pyaudio or arecord.")
        return False

    def listen_continuous(self, callback, language: str = None, stop_event=None):
        """Continuously listen and transcribe. callback(text) called on each utterance."""
        import threading
        import time

        if stop_event is None:
            import threading
            stop_event = threading.Event()

        print("[STT] Starting continuous listening... (call stop_event.set() to stop)")

        while not stop_event.is_set():
            result = self.record_and_transcribe(duration=4, language=language)
            text = result.get("text", "").strip()
            if text:
                callback(text)
            time.sleep(0.1)
