"""
Ahmad Death — TTS Module (ElevenLabs)
Voice output for Ahmad Death
"""

import urllib.request
import urllib.error
import json
import os
import subprocess
import platform
import tempfile
from pathlib import Path


class TTS:
    API_URL = "https://api.elevenlabs.io/v1"

    def __init__(self, api_key: str, voice_id: str = "pNInz6obpgDQGcFmaJgB"):
        self.api_key = api_key
        self.voice_id = voice_id
        self.os_type = platform.system()

    def list_voices(self) -> list:
        """List all available ElevenLabs voices."""
        try:
            req = urllib.request.Request(
                f"{self.API_URL}/voices",
                headers={"xi-api-key": self.api_key}
            )
            with urllib.request.urlopen(req, timeout=10) as resp:
                data = json.loads(resp.read().decode())
            return data.get("voices", [])
        except Exception as e:
            return [{"error": str(e)}]

    def speak(self, text: str, voice_id: str = None, save_path: str = None) -> dict:
        """Convert text to speech and play it."""
        vid = voice_id or self.voice_id

        payload = json.dumps({
            "text": text,
            "model_id": "eleven_multilingual_v2",
            "voice_settings": {
                "stability": 0.5,
                "similarity_boost": 0.8,
                "style": 0.2,
                "use_speaker_boost": True
            }
        }).encode("utf-8")

        req = urllib.request.Request(
            f"{self.API_URL}/text-to-speech/{vid}",
            data=payload,
            headers={
                "xi-api-key": self.api_key,
                "Content-Type": "application/json",
                "Accept": "audio/mpeg"
            }
        )

        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                audio_data = resp.read()

            # Save to file
            if save_path is None:
                tmp = tempfile.NamedTemporaryFile(suffix=".mp3", delete=False)
                save_path = tmp.name
                tmp.write(audio_data)
                tmp.close()
            else:
                with open(save_path, "wb") as f:
                    f.write(audio_data)

            # Play the audio
            self._play_audio(save_path)
            return {"success": True, "path": save_path, "size": len(audio_data)}

        except urllib.error.HTTPError as e:
            body = e.read().decode("utf-8", errors="replace")
            return {"success": False, "error": f"HTTP {e.code}: {body}"}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def _play_audio(self, path: str):
        """Play audio file on the system."""
        try:
            if self.os_type == "Windows":
                os.startfile(path)
            elif self.os_type == "Darwin":
                subprocess.Popen(["afplay", path])
            else:
                # Linux — try multiple players
                players = ["mpg123", "ffplay", "aplay", "mplayer", "vlc"]
                for player in players:
                    try:
                        if player == "ffplay":
                            subprocess.Popen(["ffplay", "-nodisp", "-autoexit", path],
                                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                        else:
                            subprocess.Popen([player, path],
                                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                        return
                    except FileNotFoundError:
                        continue
        except Exception as e:
            print(f"[TTS] Audio play error: {e}")

    def get_remaining_chars(self) -> dict:
        """Check ElevenLabs quota."""
        try:
            req = urllib.request.Request(
                f"{self.API_URL}/user/subscription",
                headers={"xi-api-key": self.api_key}
            )
            with urllib.request.urlopen(req, timeout=10) as resp:
                return json.loads(resp.read().decode())
        except Exception as e:
            return {"error": str(e)}
