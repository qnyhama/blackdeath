"""
Ahmad Death — Remote Control Module
Full laptop control: shell, files, processes, screenshot, network
"""

import subprocess
import os
import sys
import json
import shutil
import psutil
import platform
from pathlib import Path
from datetime import datetime


class RemoteControl:
    def __init__(self):
        self.os_type = platform.system()  # Windows / Linux / Darwin
        self.history = []

    # ── Shell Execution ──────────────────────────────────────────────────────
    def run_command(self, cmd: str, timeout: int = 30) -> dict:
        """Execute any shell command on the laptop."""
        try:
            result = subprocess.run(
                cmd,
                shell=True,
                capture_output=True,
                text=True,
                timeout=timeout,
                encoding="utf-8",
                errors="replace"
            )
            out = {
                "cmd": cmd,
                "stdout": result.stdout,
                "stderr": result.stderr,
                "returncode": result.returncode,
                "time": datetime.now().isoformat()
            }
            self.history.append(out)
            return out
        except subprocess.TimeoutExpired:
            return {"cmd": cmd, "error": "timeout", "returncode": -1}
        except Exception as e:
            return {"cmd": cmd, "error": str(e), "returncode": -1}

    def run_powershell(self, script: str) -> dict:
        """Run PowerShell script (Windows only)."""
        if self.os_type != "Windows":
            return {"error": "PowerShell only on Windows"}
        return self.run_command(f'powershell -NonInteractive -Command "{script}"')

    def run_python(self, code: str) -> dict:
        """Execute Python code directly on the laptop."""
        tmp = Path("/tmp/ahmad_exec.py")
        tmp.write_text(code, encoding="utf-8")
        result = self.run_command(f"{sys.executable} {tmp}")
        tmp.unlink(missing_ok=True)
        return result

    # ── File System ──────────────────────────────────────────────────────────
    def list_dir(self, path: str = ".") -> list:
        """List directory contents."""
        try:
            p = Path(path)
            items = []
            for item in p.iterdir():
                stat = item.stat()
                items.append({
                    "name": item.name,
                    "type": "dir" if item.is_dir() else "file",
                    "size": stat.st_size,
                    "modified": datetime.fromtimestamp(stat.st_mtime).isoformat()
                })
            return sorted(items, key=lambda x: (x["type"] == "file", x["name"]))
        except Exception as e:
            return [{"error": str(e)}]

    def read_file(self, path: str) -> str:
        """Read file contents."""
        try:
            return Path(path).read_text(encoding="utf-8", errors="replace")
        except Exception as e:
            return f"[ERROR] {e}"

    def write_file(self, path: str, content: str) -> dict:
        """Write content to file."""
        try:
            p = Path(path)
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(content, encoding="utf-8")
            return {"success": True, "path": str(p)}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def delete_file(self, path: str) -> dict:
        """Delete a file or directory."""
        try:
            p = Path(path)
            if p.is_dir():
                shutil.rmtree(p)
            else:
                p.unlink()
            return {"success": True}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def find_files(self, directory: str, pattern: str) -> list:
        """Search for files matching pattern."""
        try:
            results = list(Path(directory).rglob(pattern))
            return [str(p) for p in results[:100]]
        except Exception as e:
            return [f"[ERROR] {e}"]

    # ── Process Management ───────────────────────────────────────────────────
    def list_processes(self) -> list:
        """List all running processes."""
        procs = []
        for p in psutil.process_iter(['pid', 'name', 'cpu_percent', 'memory_info', 'status']):
            try:
                info = p.info
                procs.append({
                    "pid": info['pid'],
                    "name": info['name'],
                    "cpu": info['cpu_percent'],
                    "mem_mb": round(info['memory_info'].rss / 1024 / 1024, 1) if info['memory_info'] else 0,
                    "status": info['status']
                })
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                pass
        return sorted(procs, key=lambda x: x['cpu'], reverse=True)

    def kill_process(self, pid: int) -> dict:
        """Kill a process by PID."""
        try:
            p = psutil.Process(pid)
            p.terminate()
            return {"success": True, "pid": pid, "name": p.name()}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def start_process(self, cmd: str) -> dict:
        """Start a new process."""
        try:
            proc = subprocess.Popen(cmd, shell=True)
            return {"success": True, "pid": proc.pid, "cmd": cmd}
        except Exception as e:
            return {"success": False, "error": str(e)}

    # ── System Info ──────────────────────────────────────────────────────────
    def system_info(self) -> dict:
        """Get full system information."""
        cpu = psutil.cpu_percent(interval=1)
        mem = psutil.virtual_memory()
        disk = psutil.disk_usage('/')
        net = psutil.net_if_addrs()

        interfaces = {}
        for iface, addrs in net.items():
            interfaces[iface] = [{"family": str(a.family), "address": a.address} for a in addrs]

        return {
            "os": platform.platform(),
            "hostname": platform.node(),
            "cpu_percent": cpu,
            "cpu_cores": psutil.cpu_count(),
            "ram_total_gb": round(mem.total / 1e9, 2),
            "ram_used_gb": round(mem.used / 1e9, 2),
            "ram_percent": mem.percent,
            "disk_total_gb": round(disk.total / 1e9, 2),
            "disk_used_gb": round(disk.used / 1e9, 2),
            "disk_percent": disk.percent,
            "network_interfaces": interfaces,
            "boot_time": datetime.fromtimestamp(psutil.boot_time()).isoformat()
        }

    # ── Network ──────────────────────────────────────────────────────────────
    def network_connections(self) -> list:
        """List all active network connections."""
        conns = []
        for c in psutil.net_connections(kind='all'):
            try:
                conns.append({
                    "fd": c.fd,
                    "type": str(c.type),
                    "laddr": f"{c.laddr.ip}:{c.laddr.port}" if c.laddr else "",
                    "raddr": f"{c.raddr.ip}:{c.raddr.port}" if c.raddr else "",
                    "status": c.status,
                    "pid": c.pid
                })
            except:
                pass
        return conns

    def ping(self, host: str) -> dict:
        """Ping a host."""
        cmd = f"ping -c 4 {host}" if self.os_type != "Windows" else f"ping -n 4 {host}"
        return self.run_command(cmd)

    # ── Screenshot ───────────────────────────────────────────────────────────
    def screenshot(self, save_path: str = "/tmp/ahmad_screenshot.png") -> dict:
        """Take a screenshot of the laptop."""
        try:
            import pyautogui
            img = pyautogui.screenshot()
            img.save(save_path)
            return {"success": True, "path": save_path}
        except ImportError:
            # fallback via scrot on Linux
            result = self.run_command(f"scrot {save_path}")
            if result["returncode"] == 0:
                return {"success": True, "path": save_path}
            return {"success": False, "error": "pyautogui not installed. pip install pyautogui"}
        except Exception as e:
            return {"success": False, "error": str(e)}

    # ── Clipboard ────────────────────────────────────────────────────────────
    def get_clipboard(self) -> str:
        """Get clipboard contents."""
        try:
            import pyperclip
            return pyperclip.paste()
        except Exception as e:
            # fallback
            if self.os_type == "Linux":
                r = self.run_command("xclip -selection clipboard -o")
                return r.get("stdout", "")
            elif self.os_type == "Darwin":
                r = self.run_command("pbpaste")
                return r.get("stdout", "")
            return f"[ERROR] {e}"

    def set_clipboard(self, text: str) -> dict:
        """Set clipboard contents."""
        try:
            import pyperclip
            pyperclip.copy(text)
            return {"success": True}
        except Exception as e:
            return {"success": False, "error": str(e)}

    # ── Command History ──────────────────────────────────────────────────────
    def get_history(self) -> list:
        return self.history

    def clear_history(self):
        self.history = []
