#!/usr/bin/env python3
"""
Ahmad Death — Setup Script
Run this first to configure everything
"""

import json
import os
import sys
import subprocess
from pathlib import Path

BASE_DIR = Path(__file__).parent

def print_banner():
    print("""
╔══════════════════════════════════════════╗
║         AHMAD DEATH — SETUP              ║
║   Local AI · No Sign-In · No Limits      ║
╚══════════════════════════════════════════╝
""")

def install_deps():
    print("Installing Python dependencies...")
    try:
        subprocess.run(
            [sys.executable, "-m", "pip", "install", "-r", 
             str(BASE_DIR / "requirements.txt"), "--break-system-packages"],
            check=False
        )
        print("✓ Dependencies installed")
    except Exception as e:
        print(f"⚠ Dependency install issue: {e}")
        print("  Try manually: pip install psutil faster-whisper pyaudio pyautogui pyperclip")

def setup_config():
    config_path = BASE_DIR / "config" / "config.json"
    config_path.parent.mkdir(parents=True, exist_ok=True)

    existing = {}
    if config_path.exists():
        with open(config_path, "r") as f:
            existing = json.load(f)

    print("\n── Configuration ──────────────────────────────────────")
    print("ElevenLabs API key is already set in config.")
    print("")

    anthropic_key = existing.get("anthropic_api_key", "")
    if not anthropic_key:
        print("Anthropic API key (for Claude AI brain):")
        print("Get one free at: https://console.anthropic.com")
        key = input("Enter Anthropic API key (or press Enter to skip): ").strip()
        if key:
            existing["anthropic_api_key"] = key

    # Voice settings
    voice = input("\nEnable voice output TTS? (y/n) [y]: ").strip().lower()
    existing["tts_enabled"] = voice != "n"

    mic = input("Enable microphone input STT? (y/n) [y]: ").strip().lower()
    existing["stt_enabled"] = mic != "n"

    web = input("Enable web search (2026 news)? (y/n) [y]: ").strip().lower()
    existing["web_search_enabled"] = web != "n"

    # ElevenLabs voice selection
    print("\n── ElevenLabs Voice ───────────────────────────────────")
    print("Default voice ID is set. To change, enter a new ElevenLabs voice ID.")
    print("Browse voices: https://elevenlabs.io/voice-library")
    vid = input("Voice ID (press Enter to keep default): ").strip()
    if vid:
        existing["voice_id"] = vid

    # Save
    with open(config_path, "w") as f:
        json.dump(existing, f, indent=2, ensure_ascii=False)
    print(f"\n✓ Config saved to {config_path}")

def create_launcher():
    """Create a simple launch script."""
    launcher_path = BASE_DIR / "run.py"
    launcher_content = '''#!/usr/bin/env python3
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
from ui.app import main
main()
'''
    launcher_path.write_text(launcher_content)
    launcher_path.chmod(0o755)
    print(f"✓ Launcher created: {launcher_path}")

    # Windows batch
    bat_path = BASE_DIR / "run.bat"
    bat_path.write_text(f"@echo off\npython \"{launcher_path}\"\npause\n")
    print(f"✓ Windows launcher: {bat_path}")

    # Linux/Mac shell script
    sh_path = BASE_DIR / "run.sh"
    sh_path.write_text(f"#!/bin/bash\npython3 \"{launcher_path}\"\n")
    sh_path.chmod(0o755)
    print(f"✓ Linux/Mac launcher: {sh_path}")

def main():
    print_banner()

    print("Step 1: Installing dependencies...")
    install_deps()

    print("\nStep 2: Configuration...")
    setup_config()

    print("\nStep 3: Creating launchers...")
    create_launcher()

    print("""
╔══════════════════════════════════════════╗
║           SETUP COMPLETE!                ║
║                                          ║
║  Run Ahmad Death:                        ║
║    python run.py                         ║
║    ./run.sh  (Linux/Mac)                 ║
║    run.bat   (Windows)                   ║
╚══════════════════════════════════════════╝
""")

if __name__ == "__main__":
    main()
