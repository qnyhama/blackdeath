# Ahmad Death — AI تایبەتی

AI تایبەتی بۆ لاپتۆپت. بەبێ چاودێری. بەبێ سنور. بەبێ Sign-In.

---

## دامەزراندن

```bash
# ١. کۆدەکە بیخە فۆڵدەرەکەت
# ٢. سێتاپ بکە
python setup.py

# ٣. دەستپێ بکە
python run.py
```

---

## تایبەتمەندییەکان

| تایبەتمەندی | وردەکاری |
|---|---|
| **AI Brain** | Claude claude-sonnet-4-6 — وەڵامی زیرەک، بیرەوەری درێژخایەن |
| **دەنگ (TTS)** | ElevenLabs — قسەکردنی سروشتی |
| **بیستن (STT)** | Whisper — ئەمجارە locally، بەبێ ئینتەرنیت |
| **Remote Control** | شەڵ کۆمەند، فایل، پرۆسێس، screenshot |
| **OSINT** | Username enum، IP geo، port scan، Google dorks |
| **Cybersecurity** | Red team، blue team، exploits، reverse shells، privesc |
| **Web Search** | هەواڵی 2026، سۆشیال میدیا |
| **زمان** | کوردی سۆرانی + هەموو زمانەکان |

---

## فرمانەکان

```
/help          ← لیستی هەموو فرمانەکان
/cmd <cmd>     ← شەڵ کۆمەند کارپێ بکە
/osint <user>  ← OSINT بۆ username
/ip <addr>     ← ئایپی بشناسە
/portscan <h>  ← پۆرت سکان
/dorks <site>  ← Google دۆرکس
/shells <ip> <port>  ← Reverse shells
/privesc       ← چێکلیستی privilege escalation
/voice on/off  ← دەنگ سازبکە
/mic           ← مایکرۆفۆن
/sysinfo       ← زانیاری سیستەم
/memory        ← بیرەوەری AI
/remember <x>  ← شتێک لە بیر بکەوێت
/clear         ← گفتوگۆ پاک بکەوەتەوە
```

---

## Config

فایلی `config/config.json`:

```json
{
  "name": "Ahmad Death",
  "elevenlabs_api_key": "AQ.Ab8RN6Jn3YdAAGVhWSLFdG7cl8MpZIviwi6WJc_KLvGuTqxfyQ",
  "anthropic_api_key": "کلیلەکەت لێرە",
  "tts_enabled": true,
  "stt_enabled": true,
  "web_search_enabled": true
}
```

---

## دامەزراندنی پێویستییەکان

```bash
# Python packages
pip install psutil faster-whisper pyaudio pyautogui pyperclip

# Linux — بۆ دەنگی MP3
sudo apt install mpg123

# بۆ Metadata extraction
sudo apt install exiftool

# بۆ Network recon
sudo apt install nmap whois
```

---

## پرۆژە

```
ahmad-death/
├── core/
│   └── main.py          ← Config + Memory
├── modules/
│   ├── brain.py         ← Claude API + Memory
│   ├── tts.py           ← ElevenLabs دەنگ
│   ├── stt.py           ← Whisper بیستن
│   ├── remote_control.py← کۆنترۆڵی لاپتۆپ
│   ├── osint.py         ← OSINT tools
│   └── cybersec.py      ← Cyber tools
├── ui/
│   └── app.py           ← ڕووکاری سەرەکی
├── config/
│   └── config.json      ← Config
├── memory/
│   └── long_term.json   ← بیرەوەری AI
├── setup.py             ← دامەزراندن
├── run.py               ← دەستپێکردن
└── requirements.txt     ← Packages
```
