@echo off
title AHMAD AI
color 0a
echo.
echo  ================================
echo    AHMAD AI - Starting...
echo  ================================
echo.

:: Set API Key
set ANTHROPIC_API_KEY=YOUR_API_KEY_HERE

:: Check Python
python --version >nul 2>&1
if errorlevel 1 (
    echo [!] Python niye - python.org/downloads dakawla
    pause
    exit
)

:: Install deps if needed
echo [*] Dependencies check...
pip install anthropic psutil --quiet --break-system-packages 2>nul
pip install anthropic psutil --quiet 2>nul

:: Run
echo [*] AHMAD AI destpekird...
echo.
python ahmad_ai.py

pause
