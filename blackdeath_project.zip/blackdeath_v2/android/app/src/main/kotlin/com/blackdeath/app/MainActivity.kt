package com.blackdeath.app

import android.content.Context
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.os.Bundle
import android.view.WindowManager
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {

    private val CHANNEL = "blackdeath/control"
    private var isFlashOn = false

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL).setMethodCallHandler { call, result ->
            when (call.method) {

                // ── فلاشلایت ─────────────────────────────────────────────
                "toggleFlash" -> {
                    try {
                        val on = call.argument<Boolean>("on") ?: !isFlashOn
                        val cameraManager = getSystemService(Context.CAMERA_SERVICE) as CameraManager
                        val cameraId = cameraManager.cameraIdList.firstOrNull { id ->
                            cameraManager.getCameraCharacteristics(id)
                                .get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                        }
                        if (cameraId != null) {
                            cameraManager.setTorchMode(cameraId, on)
                            isFlashOn = on
                            result.success(on)
                        } else {
                            result.error("NO_FLASH", "فلاش نییە", null)
                        }
                    } catch (e: Exception) {
                        result.error("FLASH_ERROR", e.message, null)
                    }
                }

                // ── دەنگ ──────────────────────────────────────────────────
                "setVolume" -> {
                    try {
                        val level = call.argument<Int>("level") ?: 8
                        val audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
                        audioManager.setStreamVolume(
                            AudioManager.STREAM_MUSIC,
                            level.coerceIn(0, audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)),
                            0
                        )
                        result.success(level)
                    } catch (e: Exception) {
                        result.error("VOLUME_ERROR", e.message, null)
                    }
                }

                // ── شاشە ──────────────────────────────────────────────────
                "keepScreenOn" -> {
                    try {
                        val on = call.argument<Boolean>("on") ?: true
                        runOnUiThread {
                            if (on) {
                                window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                            } else {
                                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                            }
                        }
                        result.success(on)
                    } catch (e: Exception) {
                        result.error("SCREEN_ERROR", e.message, null)
                    }
                }

                // ── ڕووناکی ───────────────────────────────────────────────
                "setBrightness" -> {
                    try {
                        val level = call.argument<Double>("level") ?: 0.5
                        runOnUiThread {
                            val lp = window.attributes
                            lp.screenBrightness = level.toFloat().coerceIn(0f, 1f)
                            window.attributes = lp
                        }
                        result.success(level)
                    } catch (e: Exception) {
                        result.error("BRIGHTNESS_ERROR", e.message, null)
                    }
                }

                else -> result.notImplemented()
            }
        }
    }
}
