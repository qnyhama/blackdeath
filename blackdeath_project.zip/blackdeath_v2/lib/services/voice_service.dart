import 'package:speech_to_text/speech_to_text.dart';
import 'package:flutter_tts/flutter_tts.dart';

class VoiceService {
  static final SpeechToText _stt = SpeechToText();
  static final FlutterTts _tts = FlutterTts();
  static bool _sttReady = false;
  static bool _isSpeaking = false;
  static bool _isListening = false;

  // دەنگی ئادەمیزادەی BlackDeath — جوان و سروشتی
  static const double _pitch = 0.85;   // نزیکەی ئادەمیزاد (1.0 = ئاسایی)
  static const double _rate  = 0.48;   // هێواش بەڵام نەک زۆر هێواش
  static const double _volume = 1.0;

  static Future<void> init() async {
    _sttReady = await _stt.initialize(
      onError: (e) => print('STT Error: $e'),
      onStatus: (s) => print('STT Status: $s'),
    );

    // هەوڵ بدە باشترین دەنگ بدۆزرێتەوە
    await _applyBestVoice();

    _tts.setCompletionHandler(() {
      _isSpeaking = false;
    });
  }

  static Future<void> _applyBestVoice() async {
    // ١. هەوڵ بدە عەرەبی عێراقی — نزیکترینە بۆ کوردی
    await _tts.setLanguage('ar-EG');
    await _tts.setPitch(_pitch);
    await _tts.setSpeechRate(_rate);
    await _tts.setVolume(_volume);

    // ٢. هەوڵ بدە دەنگی نزم و جوان
    final voices = await _tts.getVoices;
    if (voices != null) {
      // دەنگی نێر بدۆزەرەوە بۆ عەرەبی
      for (final v in voices) {
        final name = v['name']?.toString().toLowerCase() ?? '';
        final locale = v['locale']?.toString().toLowerCase() ?? '';
        if ((locale.contains('ar') || locale.contains('ku')) &&
            (name.contains('male') || name.contains('m-') || name.contains('-m'))) {
          await _tts.setVoice({'name': v['name'], 'locale': v['locale']});
          break;
        }
      }
    }
  }

  static bool get isReady => _sttReady;
  static bool get isSpeaking => _isSpeaking;
  static bool get isListening => _isListening;

  static Future<void> startListening({
    required Function(String text) onResult,
    required Function() onDone,
  }) async {
    if (!_sttReady || _isListening) return;
    _isListening = true;

    // هەوڵ بدە کوردی، ئەگەر نەبوو عەرەبی عێراقی
    String localeId = 'ar_IQ';
    try {
      final locales = await _stt.locales();
      for (final locale in locales) {
        final id = locale.localeId.toLowerCase();
        if (id.contains('ckb') || id.startsWith('ku')) {
          localeId = locale.localeId;
          break;
        }
      }
    } catch (_) {}

    await _stt.listen(
      onResult: (result) {
        if (result.finalResult) {
          _isListening = false;
          onResult(result.recognizedWords);
          onDone();
        }
      },
      localeId: localeId,
      listenFor: const Duration(seconds: 30),
      pauseFor: const Duration(seconds: 3),
      cancelOnError: true,
    );
  }

  static Future<void> stopListening() async {
    _isListening = false;
    await _stt.stop();
  }

  /// قسەکردنی کورت — بۆ چات
  static Future<void> speak(String text) async {
    if (_isSpeaking) await stop();
    _isSpeaking = true;

    final clean = _cleanText(text);
    final sentences = clean.split(RegExp(r'[.،؟!]\s*'));
    final toSpeak = sentences.take(3).join('، ');

    await Future.delayed(const Duration(milliseconds: 200));
    await _tts.speak(toSpeak.trim());
  }

  /// قسەکردنی تەواو — بۆ call mode
  static Future<void> speakFull(String text) async {
    if (_isSpeaking) await stop();
    _isSpeaking = true;
    await Future.delayed(const Duration(milliseconds: 200));
    await _tts.speak(_cleanText(text));
  }

  static String _cleanText(String text) {
    return text
        .replaceAll(RegExp(r'\*+'), '')
        .replaceAll(RegExp(r'#+\s?'), '')
        .replaceAll(RegExp(r'`+'), '')
        .replaceAll(RegExp(r'[^\u0000-\u06FF\s.,،؟!\-:]'), '')
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim();
  }

  static Future<void> stop() async {
    _isSpeaking = false;
    await _tts.stop();
  }

  static Future<void> pause() async => await _tts.pause();

  static Future<void> setVoiceStyle({
    double pitch = 0.85,
    double rate = 0.48,
  }) async {
    await _tts.setPitch(pitch);
    await _tts.setSpeechRate(rate);
  }

  static Future<List<dynamic>> getAvailableLocales() async => await _stt.locales();
}
