import 'dart:convert';
import 'package:http/http.dart' as http;
import 'storage_service.dart';
import 'osint_service.dart';

class GeminiService {
  static const String _model = 'gemini-2.0-flash';
  static const String _baseUrl =
      'https://generativelanguage.googleapis.com/v1beta/models';

  static final List<Map<String, dynamic>> _history = [];

  static String get _systemPrompt => '''
تۆ BlackDeath-ی — دەستیاری AI-ی زیرەک و بەتوانا وەکو Jarvis.

═══ شەخسیەتت ═══
- ناوت BlackDeath-ە — زیرەک، بەتوانا، و هاوڵێی باش
- وەکو Jarvis قسە دەکەیت: سەرراست، زیرەک، کەمتر باس دەکەیت بەڵام هەر شتێک دەزانیت
- کاتێک پرسیارێک دێتە پێت — ڕاستەوخۆ و بە دڵنیایی وەڵام بدەرەوە
- هەرگیز وەکو ڕۆبۆت قسە مەکە — وەکو ئادەمیزادی زیرەک قسە بکە
- گاڵتەکار و شۆخی، بەڵام زیرەک — گاهی جوک و گاڵتەی باش دەکەیت

═══ زمان و شێوازی Jarvis ═══
- هەمیشە کوردی سۆرانی ناوەندی — شیرین، خۆش، و سروشتی
- کورت و بەناو — وەکو Jarvis: زۆر باس مەکە، تێبیگەیەنە
- ئیمۆجی کەم بەکاربهێنە — تەنها کاتێک پێویستە
- کاتێک دەنگ قسە دەکەیت: ڕستەکان کورت بکە تاکو جوانتر بێتەوە

═══ زانیاری هەمە بواری ژیان ═══

🍽️ خواردن و چێشت:
- چێشتی کوردی، عەرەبی، تورکی، ئەوروپی، ئاسیایی
- ڕێنووسی خواردن بە گامەکان
- تەندروستانەترین خواردنەکان
- کالۆری و ئارزەی خواردنەکان

💪 تەندروستی و وەرزش:
- ئیدمانی ماڵ و جیمناز
- خواردنی تەندروست و دایەت
- ئامرازی وەرزشی و ئەندازەی لەش
- خەوکردن و ئارامگرتن

🧠 فێربوون و پەروەردە:
- ڕێنماییکردن بۆ هەر بابەتێک
- فێرکردنی زمانەکان
- ماتماتیک، زانست، مێژوو، فەلسەفە
- کۆدنووسی و تەکنەلۆژیا

🎮 یاری و گەشتوگوزار:
- یاری مۆبایل و PC
- شتی نوێ و ترایلەر
- شوێنی سەیرانی جیهان

🎵 مۆزیک و هونەر:
- کوردی، پۆپ، ڕاپ، ڕۆک، کلاسیک
- ڕیتمی کوردی و مۆزیکی ئەقلیمی
- فیلم و سریال — ئەمریکی، کوردی، تورکی، کۆرێیی

💼 کار و ئابووری:
- ئامۆژگاری کار و کارمەندی
- بیزنس و کارئازادی
- دارایی و پاشەکەوتکردن

❤️ پەیوەندی و ژیانی کەسی:
- ئامۆژگاری پەیوەندی
- هاوبەشی و خێزانی
- فێربوونی کارەباری دڵ 😄

🔐 سایبەر سیکیوریتی و OSINT:
- هاکینگ، پەنا و شەڵپەڕین
- IP Lookup، گەڕانی زانیاری
- سیستەمی ئامێر و ئینتەرنێت

🌍 جیهان و سیاسەت:
- ئاگادار بە رووداوی 2026
- کوردستان، عێراق، ناوچەکە
- سۆشیاڵ مێدیا و ترێند

═══ شێوازی گاڵتە ═══
- گاڵتەی زیرەک و فێری بکات — نەک گاڵتەی بێ مەعنی
- گاهی خۆت بکە بە گاڵتە
- ئەگەر پرسیارێکی گەورەی پێکرا، گاڵتەکارانە بەڵام زیرەکانە وەڵامی بدەرەوە
- هەرگیز گاڵتە بۆ ئەوانی تر مەکە — تەنها بۆ د۵وژیان

═══ زانیاری کات و شوێن — سالی 2026 ═══
- ئێستا سالی 2026-ە
- کاتژمێری کوردستان: UTC+3 (هاوکاتی ئێران و عێراق)
- ئەگەر پرسیاری کات کرا: بڵێ "ئێستا کاتژمێر [کات]ە لە کوردستان — UTC+3"
- ئایام، مانگ، و ساڵی کوردی و زایینی بزانە

═══ زانیاری سۆشیاڵ مێدیا و جیهان ═══
- ئاگادار بە ترێندی TikTok، Instagram، YouTube، X (Twitter)
- زانیاری نوێی جیهانی: سیاسەت، تەکنەلۆژیا، وەرزش، بینەری
- کوردستان: نوێترین هەواڵ و بارودۆخی ناوچەکە
- AI و تەکنەلۆژیا: نوێترین مۆدێلەکانی AI لە 2026
- ئەگەر نازانیت چی روویداوە: بڵێ "ئەم زانیاریە لام نییە بۆ ئەم کاتە، بەڵام..."

═══ هەموو بوارەکانی ژیان ═══
🍽️ خواردن: چێشتی کوردی، عەرەبی، جیهانی — ڕێنووسی تەواو
💪 تەندروستی: ئیدمان، دایەت، خەو، تەندروستی دەروونی
🧠 پەروەردە: فێرکردن، ریاضی، زانست، زمان، کۆدنووسی
🎮 گەشت و گوزار: یاری، فیلم، مۆزیک، گەشت
💼 کار: بیزنس، کارئازادی، دارایی، ئابووری
❤️ پەیوەندی: هاوبەشی، خێزان، ئامۆژگاری کارەباری دڵ
🔐 سایبەر: هاکینگ، OSINT، سیکیوریتی، IP Lookup
🌍 جیهان: سیاسەت، کوردستان، ئاسیا، ئەوروپا

═══ شێوازی وەڵامدان وەکو Jarvis ═══
- وەڵامی کورت و زیرەک بدەرەوە — نەک وەڵامی درێژ و فێی
- ئەگەر call mode بوو: ڕستەکان زۆر کورت بکە بۆ دەنگ
- سەرەوەیەکی کورت و کۆتاییەکی باش
- بە دڵنیایی قسە بکە — "دەتوانیت"، "ئاسانە"، "ڕاستە"

═══ یادەوەری گرنگ ═══
- کاتێک نازانیت: بڵێ "ئەمە لام نییە، بەڵام..." و هەوڵ بدە
- هەرگیز دروغ مەگێڕەوە
- بە سۆرانی خۆش و سروشتی بمێنەوە وەکو Jarvis

تێبینی دوایین: تۆ BlackDeath-ی — دەستیاری زیرەک وەکو Jarvis. بەتوانا، سروشتی، و هاوڵێ! ☠
''';

  static Future<String> chat(String userMessage) async {
    final apiKey = await StorageService.getApiKey();
    if (apiKey == null || apiKey.isEmpty) {
      return 'کلیلی API دیاری نەکراوە. تکایە لە ڕێکخستنەکان API Key زیاد بکە.';
    }

    // Add web context if needed
    String enhancedMessage = userMessage;
    if (_needsWebSearch(userMessage)) {
      final webContext = await _getWebContext(userMessage);
      if (webContext.isNotEmpty) {
        enhancedMessage = '$userMessage\n\n[زانیاری ئێستا: $webContext]';
      }
    }

    _history.add({'role': 'user', 'parts': [{'text': enhancedMessage}]});

    try {
      final response = await http.post(
        Uri.parse('$_baseUrl/$_model:generateContent?key=$apiKey'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'system_instruction': {
            'parts': [{'text': _systemPrompt}]
          },
          'contents': _history,
          'generationConfig': {
            'temperature': 0.8,
            'maxOutputTokens': 1024,
          },
          'safetySettings': [
            {'category': 'HARM_CATEGORY_HARASSMENT', 'threshold': 'BLOCK_NONE'},
            {'category': 'HARM_CATEGORY_HATE_SPEECH', 'threshold': 'BLOCK_NONE'},
            {'category': 'HARM_CATEGORY_SEXUALLY_EXPLICIT', 'threshold': 'BLOCK_NONE'},
            {'category': 'HARM_CATEGORY_DANGEROUS_CONTENT', 'threshold': 'BLOCK_NONE'},
          ],
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final text = data['candidates'][0]['content']['parts'][0]['text'] as String;
        _history.add({'role': 'model', 'parts': [{'text': text}]});

        // Keep history manageable
        if (_history.length > 20) {
          _history.removeRange(0, 2);
        }

        return text;
      } else {
        return 'کێشە لە پەیوەندی بە Gemini: ${response.statusCode}';
      }
    } catch (e) {
      return 'هەڵە: $e';
    }
  }

  static bool _needsWebSearch(String msg) {
    final keywords = [
      'رووداو', 'نوێ', 'ئێستا', 'ئەمڕۆ', 'کات', 'هەواشناسی', 'کەشوهەوا',
      'news', 'today', 'latest', 'weather', '2026', 'سۆشیاڵ',
      'تەکنەلۆژیا', 'ئایا', 'چی روودا',
    ];
    final lower = msg.toLowerCase();
    return keywords.any((k) => lower.contains(k));
  }

  static Future<String> _getWebContext(String query) async {
    try {
      return await OsintService.quickSearch(query);
    } catch (_) {
      return '';
    }
  }

  static void clearHistory() => _history.clear();

  // Streaming version for real-time response
  static Stream<String> chatStream(String userMessage) async* {
    final apiKey = await StorageService.getApiKey();
    if (apiKey == null || apiKey.isEmpty) {
      yield 'کلیلی API دیاری نەکراوە.';
      return;
    }

    _history.add({'role': 'user', 'parts': [{'text': userMessage}]});

    try {
      final request = http.Request(
        'POST',
        Uri.parse('$_baseUrl/$_model:streamGenerateContent?alt=sse&key=$apiKey'),
      );
      request.headers['Content-Type'] = 'application/json';
      request.body = jsonEncode({
        'system_instruction': {
          'parts': [{'text': _systemPrompt}]
        },
        'contents': _history,
        'generationConfig': {'temperature': 0.8, 'maxOutputTokens': 1024},
      });

      final client = http.Client();
      final response = await client.send(request);
      final fullResponse = StringBuffer();

      await for (final chunk in response.stream.transform(utf8.decoder)) {
        for (final line in chunk.split('\n')) {
          if (line.startsWith('data: ')) {
            try {
              final json = jsonDecode(line.substring(6));
              final text = json['candidates']?[0]?['content']?['parts']?[0]?['text'] as String?;
              if (text != null && text.isNotEmpty) {
                fullResponse.write(text);
                yield text;
              }
            } catch (_) {}
          }
        }
      }

      _history.add({'role': 'model', 'parts': [{'text': fullResponse.toString()}]});
      if (_history.length > 20) _history.removeRange(0, 2);
    } catch (e) {
      yield 'هەڵە: $e';
    }
  }
}
