import 'package:url_launcher/url_launcher.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:battery_plus/battery_plus.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter/services.dart';
import 'package:flutter/material.dart';

class MobileControlService {
  static final _battery = Battery();
  static final _connectivity = Connectivity();
  static final _deviceInfo = DeviceInfoPlugin();
  static final _notifications = FlutterLocalNotificationsPlugin();

  // ── METHOD CHANNEL بۆ فیچەری نەیتیڤ ─────────────────────────────────────
  static const _channel = MethodChannel('blackdeath/control');

  // ── INIT ──────────────────────────────────────────────────────────────────
  static Future<void> init() async {
    const androidSettings = AndroidInitializationSettings('@mipmap/ic_launcher');
    const iosSettings = DarwinInitializationSettings(
      requestAlertPermission: true,
      requestBadgePermission: true,
      requestSoundPermission: true,
    );
    await _notifications.initialize(
      const InitializationSettings(android: androidSettings, iOS: iosSettings),
    );
  }

  // ══════════════════════════════════════════════════════════════════════════
  // 🔋 BATTERY
  // ══════════════════════════════════════════════════════════════════════════
  static Future<Map<String, dynamic>> getBatteryInfo() async {
    final level = await _battery.batteryLevel;
    final state = await _battery.batteryState;
    return {
      'level': level,
      'state': state.name,
      'isCharging': state == BatteryState.charging || state == BatteryState.full,
      'isFull': state == BatteryState.full,
    };
  }

  // ══════════════════════════════════════════════════════════════════════════
  // 🌐 NETWORK
  // ══════════════════════════════════════════════════════════════════════════
  static Future<Map<String, dynamic>> getNetworkInfo() async {
    final result = await _connectivity.checkConnectivity();
    final connected = result.isNotEmpty && result.first != ConnectivityResult.none;
    return {
      'connected': connected,
      'type': connected ? result.first.name : 'none',
      'isWifi': connected && result.first == ConnectivityResult.wifi,
      'isMobile': connected && result.first == ConnectivityResult.mobile,
      'isEthernet': connected && result.first == ConnectivityResult.ethernet,
    };
  }

  // ══════════════════════════════════════════════════════════════════════════
  // 📱 DEVICE INFO
  // ══════════════════════════════════════════════════════════════════════════
  static Future<Map<String, dynamic>> getDeviceInfo() async {
    try {
      final info = await _deviceInfo.androidInfo;
      return {
        'platform': 'android',
        'brand': info.brand,
        'model': info.model,
        'version': info.version.release,
        'sdk': info.version.sdkInt,
        'device': info.device,
        'product': info.product,
        'manufacturer': info.manufacturer,
        'isPhysical': info.isPhysicalDevice,
      };
    } catch (_) {
      try {
        final info = await _deviceInfo.iosInfo;
        return {
          'platform': 'ios',
          'brand': 'Apple',
          'model': info.model,
          'version': info.systemVersion,
          'name': info.name,
          'isPhysical': info.isPhysicalDevice,
        };
      } catch (_) {
        return {'platform': 'unknown'};
      }
    }
  }

  // ══════════════════════════════════════════════════════════════════════════
  // 📲 APP LAUNCHER — ئاپ کراوەکە
  // ══════════════════════════════════════════════════════════════════════════
  static const _appSchemes = {
    'whatsapp'  : 'whatsapp://',
    'telegram'  : 'tg://',
    'youtube'   : 'youtube://',
    'instagram' : 'instagram://',
    'twitter'   : 'twitter://',
    'x'         : 'twitter://',
    'tiktok'    : 'tiktok://',
    'chrome'    : 'googlechrome://',
    'maps'      : 'comgooglemaps://',
    'snapchat'  : 'snapchat://',
    'facebook'  : 'fb://',
    'messenger' : 'fb-messenger://',
    'spotify'   : 'spotify://',
    'gmail'     : 'googlegmail://',
    'calendar'  : 'content://com.android.calendar',
    'settings'  : 'app-settings:',
    'camera'    : 'camera://',
    'gallery'   : 'content://media',
    'files'     : 'content://com.android.externalstorage.documents',
    'calculator': 'calculator://',
    'clock'     : 'clock://',
    'contacts'  : 'content://contacts',
    'phone'     : 'tel:',
    'dialer'    : 'tel:',
  };

  static Future<bool> openApp(String appName) async {
    final key = appName.toLowerCase().trim();

    // پاڵپشتی ناوی کوردی
    final kurdishMap = {
      'واتساپ'   : 'whatsapp',
      'تێلیگرام' : 'telegram',
      'یوتیوب'   : 'youtube',
      'ئینستا'   : 'instagram',
      'تیکتۆک'   : 'tiktok',
      'فەیسبووک' : 'facebook',
      'سپۆتیفای' : 'spotify',
      'کامێرا'   : 'camera',
      'ڕێکخستن'  : 'settings',
      'کۆنتاکت'  : 'contacts',
      'کەلێندەر' : 'calendar',
      'گووگڵ'    : 'chrome',
      'مەسەنجەر' : 'messenger',
      'گمەیل'    : 'gmail',
      'سنابچات'  : 'snapchat',
    };

    final resolvedKey = kurdishMap[key] ?? key;
    final scheme = _appSchemes[resolvedKey];

    if (scheme != null) {
      try {
        final uri = Uri.parse(scheme);
        if (await canLaunchUrl(uri)) return await launchUrl(uri);
      } catch (_) {}
    }

    // Fallback: گەڕانی لە پلەی ستۆر
    return await launchUrl(
      Uri.parse('market://search?q=$appName'),
      mode: LaunchMode.externalApplication,
    ).catchError((_) => false);
  }

  // ══════════════════════════════════════════════════════════════════════════
  // 🌍 URL OPENER
  // ══════════════════════════════════════════════════════════════════════════
  static Future<bool> openUrl(String url) async {
    if (!url.startsWith('http')) url = 'https://$url';
    return await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
  }

  // ══════════════════════════════════════════════════════════════════════════
  // 📞 PHONE — تەلەفۆن
  // ══════════════════════════════════════════════════════════════════════════
  static Future<bool> makeCall(String number) async {
    final clean = number.replaceAll(RegExp(r'[^\d+]'), '');
    return await launchUrl(Uri.parse('tel:$clean'));
  }

  // ── دیالەر کراوەبێت بەبێ تەلەفۆنکردن ─────────────────────────────────────
  static Future<bool> openDialer(String number) async {
    final clean = number.replaceAll(RegExp(r'[^\d+]'), '');
    return await launchUrl(Uri.parse('tel:$clean'),
        mode: LaunchMode.externalNonBrowserApplication);
  }

  // ══════════════════════════════════════════════════════════════════════════
  // 💬 SMS
  // ══════════════════════════════════════════════════════════════════════════
  static Future<bool> sendSms(String number, String message) async {
    final clean = number.replaceAll(RegExp(r'[^\d+]'), '');
    final uri = Uri.parse('sms:$clean?body=${Uri.encodeComponent(message)}');
    return await launchUrl(uri);
  }

  // ══════════════════════════════════════════════════════════════════════════
  // 💚 WHATSAPP
  // ══════════════════════════════════════════════════════════════════════════
  static Future<bool> openWhatsApp(String number, {String message = ''}) async {
    final clean = number.replaceAll(RegExp(r'[^\d+]'), '');
    final uri = Uri.parse('https://wa.me/$clean?text=${Uri.encodeComponent(message)}');
    return await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  // واتساپ کۆنتاکت بەبێ نومرە
  static Future<bool> openWhatsAppChat() async {
    return await openApp('whatsapp');
  }

  // ══════════════════════════════════════════════════════════════════════════
  // 📧 EMAIL
  // ══════════════════════════════════════════════════════════════════════════
  static Future<bool> sendEmail({
    required String to,
    String subject = '',
    String body = '',
  }) async {
    final uri = Uri(
      scheme: 'mailto',
      path: to,
      queryParameters: {
        if (subject.isNotEmpty) 'subject': subject,
        if (body.isNotEmpty) 'body': body,
      },
    );
    return await launchUrl(uri);
  }

  // ══════════════════════════════════════════════════════════════════════════
  // 📍 MAPS — نەخشە
  // ══════════════════════════════════════════════════════════════════════════
  static Future<bool> openMaps(String location) async {
    final encoded = Uri.encodeComponent(location);
    // گووگڵ مەپس
    final googleUri = Uri.parse('https://www.google.com/maps/search/?api=1&query=$encoded');
    return await launchUrl(googleUri, mode: LaunchMode.externalApplication);
  }

  static Future<bool> openMapsCoordinates(double lat, double lng) async {
    final uri = Uri.parse('geo:$lat,$lng?q=$lat,$lng');
    if (await canLaunchUrl(uri)) return await launchUrl(uri);
    // Fallback
    return await launchUrl(
      Uri.parse('https://www.google.com/maps?q=$lat,$lng'),
      mode: LaunchMode.externalApplication,
    );
  }

  // ══════════════════════════════════════════════════════════════════════════
  // 📋 CLIPBOARD — کلیپبۆرد
  // ══════════════════════════════════════════════════════════════════════════
  static Future<void> copyToClipboard(String text) async {
    await Clipboard.setData(ClipboardData(text: text));
  }

  static Future<String?> pasteFromClipboard() async {
    final data = await Clipboard.getData(Clipboard.kTextPlain);
    return data?.text;
  }

  // ══════════════════════════════════════════════════════════════════════════
  // 📳 HAPTICS — لەرزین
  // ══════════════════════════════════════════════════════════════════════════
  static Future<void> vibrate({int duration = 300}) async {
    await HapticFeedback.heavyImpact();
  }

  static Future<void> vibrateLight() async => HapticFeedback.lightImpact();
  static Future<void> vibrateMedium() async => HapticFeedback.mediumImpact();
  static Future<void> vibrateSelection() async => HapticFeedback.selectionClick();

  // ══════════════════════════════════════════════════════════════════════════
  // 🔦 FLASHLIGHT — بلایندەر
  // ══════════════════════════════════════════════════════════════════════════
  // تێبینی: پێویستی plugin زیادە → torch_light یان camera
  // ئەمەی خوارەوە method channel بەکاردەهێنێت
  static bool _flashOn = false;

  static Future<bool> toggleFlashlight() async {
    try {
      _flashOn = !_flashOn;
      await _channel.invokeMethod('toggleFlash', {'on': _flashOn});
      return _flashOn;
    } catch (_) {
      // Fallback بۆ ئەگەر method channel نەبوو
      _flashOn = false;
      return false;
    }
  }

  static Future<void> flashlightOn() async {
    _flashOn = true;
    try { await _channel.invokeMethod('toggleFlash', {'on': true}); } catch (_) {}
  }

  static Future<void> flashlightOff() async {
    _flashOn = false;
    try { await _channel.invokeMethod('toggleFlash', {'on': false}); } catch (_) {}
  }

  // ══════════════════════════════════════════════════════════════════════════
  // 🔊 VOLUME — دەنگ
  // ══════════════════════════════════════════════════════════════════════════
  static Future<void> setVolume(int level) async {
    // 0-15 بۆ Android
    try {
      await _channel.invokeMethod('setVolume', {'level': level.clamp(0, 15)});
    } catch (_) {}
  }

  static Future<void> muteDevice() async {
    try { await _channel.invokeMethod('setVolume', {'level': 0}); } catch (_) {}
  }

  static Future<void> maxVolume() async {
    try { await _channel.invokeMethod('setVolume', {'level': 15}); } catch (_) {}
  }

  // ══════════════════════════════════════════════════════════════════════════
  // 🌑 SCREEN — شاشە
  // ══════════════════════════════════════════════════════════════════════════
  static Future<void> keepScreenOn(bool on) async {
    try { await _channel.invokeMethod('keepScreenOn', {'on': on}); } catch (_) {}
  }

  static Future<void> setBrightness(double level) async {
    // 0.0 - 1.0
    try {
      await _channel.invokeMethod('setBrightness', {'level': level.clamp(0.0, 1.0)});
    } catch (_) {}
  }

  // ══════════════════════════════════════════════════════════════════════════
  // 🔔 NOTIFICATIONS — ئاگادارکردنەوە
  // ══════════════════════════════════════════════════════════════════════════
  static Future<void> showNotification({
    required String title,
    required String body,
    int id = 0,
    String? sound,
    bool vibrate = true,
  }) async {
    final androidDetails = AndroidNotificationDetails(
      'blackdeath_channel',
      'BlackDeath',
      channelDescription: 'BlackDeath AI',
      importance: Importance.max,
      priority: Priority.high,
      icon: '@mipmap/ic_launcher',
      enableVibration: vibrate,
      playSound: true,
      color: const Color(0xFFFF0000),
    );
    const iosDetails = DarwinNotificationDetails(
      presentAlert: true,
      presentBadge: true,
      presentSound: true,
    );
    await _notifications.show(
      id,
      title,
      body,
      NotificationDetails(android: androidDetails, iOS: iosDetails),
    );
  }

  // ئاگادارکردنەوەی دواخستراو
  static Future<void> scheduleNotification({
    required String title,
    required String body,
    required DateTime dateTime,
    int id = 1,
  }) async {
    // بۆ ئێستا: immediate + یادەوەری
    await showNotification(title: title, body: body, id: id);
  }

  // ئاگادارکردنەوەی هەموو
  static Future<void> cancelAllNotifications() async {
    await _notifications.cancelAll();
  }

  static Future<void> cancelNotification(int id) async {
    await _notifications.cancel(id);
  }

  // ══════════════════════════════════════════════════════════════════════════
  // 🔐 PERMISSIONS
  // ══════════════════════════════════════════════════════════════════════════
  static Future<Map<String, bool>> checkPermissions() async {
    return {
      'microphone'   : await Permission.microphone.isGranted,
      'camera'       : await Permission.camera.isGranted,
      'storage'      : await Permission.storage.isGranted,
      'contacts'     : await Permission.contacts.isGranted,
      'phone'        : await Permission.phone.isGranted,
      'sms'          : await Permission.sms.isGranted,
      'location'     : await Permission.location.isGranted,
      'notifications': await Permission.notification.isGranted,
      'calendar'     : await Permission.calendarFullAccess.isGranted,
    };
  }

  static Future<void> requestAllPermissions() async {
    await [
      Permission.microphone,
      Permission.camera,
      Permission.storage,
      Permission.contacts,
      Permission.phone,
      Permission.sms,
      Permission.location,
      Permission.notification,
      Permission.calendarFullAccess,
    ].request();
  }

  static Future<bool> requestPermission(Permission perm) async {
    final status = await perm.request();
    return status.isGranted;
  }

  // ══════════════════════════════════════════════════════════════════════════
  // 🤖 AI COMMAND PARSER — Gemini دەتوانێت ئەمانە بنێرێت
  // ══════════════════════════════════════════════════════════════════════════
  /// ئەمە سەرەکیترین فانکشنە — Gemini دەتوانێت پێیان بخات
  /// وەڵامی کوردی دەگەڕێنێتەوە
  static Future<String> executeCommand(String command) async {
    final cmd = command.toLowerCase().trim();

    // ── بەتری ──────────────────────────────────────────────────────────────
    if (cmd.contains('بەتری') || cmd.contains('battery') || cmd.contains('شارژ')) {
      final info = await getBatteryInfo();
      final charging = info['isCharging'] == true ? ' ⚡ شارژکراوە' : '';
      return '🔋 بەتری: ${info['level']}%$charging';
    }

    // ── نەت ────────────────────────────────────────────────────────────────
    if (cmd.contains('نەت') || cmd.contains('wifi') || cmd.contains('وایفای') ||
        cmd.contains('ئینتەرنێت') || cmd.contains('internet')) {
      final info = await getNetworkInfo();
      if (info['connected'] == true) {
        final type = info['isWifi'] == true ? '📶 WiFi' : '📱 داتای مۆبایل';
        return '🌐 پەیوەستە — $type';
      }
      return '📵 ئینتەرنێت نییە';
    }

    // ── دەستگا ─────────────────────────────────────────────────────────────
    if (cmd.contains('دەستگا') || cmd.contains('مۆبایل') || cmd.contains('device')) {
      return await getFullSystemStatus();
    }

    // ── فلاشلایت ───────────────────────────────────────────────────────────
    if (cmd.contains('فلاش') || cmd.contains('flash') || cmd.contains('بلایندەر') ||
        cmd.contains('چراغ')) {
      if (cmd.contains('گەموبکە') || cmd.contains('خامۆش') || cmd.contains('off')) {
        await flashlightOff();
        return '🔦 فلاشلایت خامۆشکرا';
      }
      final on = await toggleFlashlight();
      return on ? '🔦 فلاشلایت کراوەکرا' : '🔦 فلاشلایت خامۆشکرا';
    }

    // ── کۆپی ───────────────────────────────────────────────────────────────
    if (cmd.contains('کۆپی') || cmd.contains('copy')) {
      final text = cmd.replaceAll(RegExp(r'کۆپی|copy|\s'), '').trim();
      if (text.isNotEmpty) {
        await copyToClipboard(text);
        return '📋 کۆپیکرا: $text';
      }
      final pasted = await pasteFromClipboard();
      return pasted != null ? '📋 کلیپبۆرد: $pasted' : '📋 کلیپبۆرد بەتاڵە';
    }

    // ── لەرزین ─────────────────────────────────────────────────────────────
    if (cmd.contains('لەرزین') || cmd.contains('vibrate') || cmd.contains('تیتر')) {
      await vibrate();
      return '📳 لەرزینی دەستگا';
    }

    // ── دەنگ مووت ──────────────────────────────────────────────────────────
    if (cmd.contains('مووت') || cmd.contains('mute') || cmd.contains('دەنگ بکە خامۆش')) {
      await muteDevice();
      return '🔇 دەنگی دەستگا خامۆشکرا';
    }

    // ── تەلەفۆن ─────────────────────────────────────────────────────────────
    if (cmd.contains('تەلەفۆن') || cmd.contains('call') || cmd.contains('بانگ')) {
      final numMatch = RegExp(r'[\d+]{7,}').firstMatch(cmd);
      if (numMatch != null) {
        await makeCall(numMatch.group(0)!);
        return '📞 تەلەفۆنکردن: ${numMatch.group(0)}';
      }
      return '📞 نومرەی تەلەفۆن بنووسە';
    }

    // ── SMS ─────────────────────────────────────────────────────────────────
    if (cmd.contains('sms') || cmd.contains('پەیام بنێرە')) {
      return '💬 نومرە و پەیامەکەت بنووسە';
    }

    // ── واتساپ ──────────────────────────────────────────────────────────────
    if (cmd.contains('واتساپ') || cmd.contains('whatsapp')) {
      await openApp('whatsapp');
      return '💬 واتساپ کراوەکرا';
    }

    // ── تێلیگرام ────────────────────────────────────────────────────────────
    if (cmd.contains('تێلیگرام') || cmd.contains('telegram')) {
      await openApp('telegram');
      return '✈️ تێلیگرام کراوەکرا';
    }

    // ── یوتیوب ──────────────────────────────────────────────────────────────
    if (cmd.contains('یوتیوب') || cmd.contains('youtube')) {
      await openApp('youtube');
      return '▶️ یوتیوب کراوەکرا';
    }

    // ── ئینستاگرام ──────────────────────────────────────────────────────────
    if (cmd.contains('ئینستا') || cmd.contains('instagram')) {
      await openApp('instagram');
      return '📷 ئینستاگرام کراوەکرا';
    }

    // ── تیکتۆک ──────────────────────────────────────────────────────────────
    if (cmd.contains('تیکتۆک') || cmd.contains('tiktok')) {
      await openApp('tiktok');
      return '🎵 تیکتۆک کراوەکرا';
    }

    // ── گووگڵ کرۆم ──────────────────────────────────────────────────────────
    if (cmd.contains('گووگڵ') || cmd.contains('chrome') || cmd.contains('بگەڕێ')) {
      final query = cmd
          .replaceAll(RegExp(r'گووگڵ|chrome|بگەڕێ|بگەڕێوە'), '')
          .trim();
      if (query.isNotEmpty) {
        await openUrl('https://www.google.com/search?q=${Uri.encodeComponent(query)}');
        return '🔍 گەڕان بۆ: $query';
      }
      await openApp('chrome');
      return '🌍 کرۆم کراوەکرا';
    }

    // ── نەخشە ───────────────────────────────────────────────────────────────
    if (cmd.contains('نەخشە') || cmd.contains('maps') || cmd.contains('شوێن')) {
      final location = cmd
          .replaceAll(RegExp(r'نەخشە|maps|شوێن|بدۆزەرەوە'), '')
          .trim();
      if (location.isNotEmpty) {
        await openMaps(location);
        return '📍 نەخشەی $location کراوەکرا';
      }
      await openApp('maps');
      return '🗺️ نەخشە کراوەکرا';
    }

    // ── ڕێکخستن ─────────────────────────────────────────────────────────────
    if (cmd.contains('ڕێکخستن') || cmd.contains('settings')) {
      await openApp('settings');
      return '⚙️ ڕێکخستنەکان کراوەکرا';
    }

    // ── کامێرا ──────────────────────────────────────────────────────────────
    if (cmd.contains('کامێرا') || cmd.contains('camera') || cmd.contains('وێنە')) {
      await openApp('camera');
      return '📸 کامێرا کراوەکرا';
    }

    // ── ئاگادارکردنەوە ───────────────────────────────────────────────────────
    if (cmd.contains('ئاگادارم') || cmd.contains('یادم بێت') || cmd.contains('notify')) {
      final msg = cmd
          .replaceAll(RegExp(r'ئاگادارم بکەرەوە|یادم بێت|notify'), '')
          .trim();
      await showNotification(
        title: '☠ BlackDeath',
        body: msg.isNotEmpty ? msg : 'یادەوەری',
      );
      return '🔔 ئاگادارکردنەوە نێردرا: ${msg.isNotEmpty ? msg : "باشە!"}';
    }

    return ''; // هیچ فەرمانێک نەدۆزرایەوە
  }

  // ══════════════════════════════════════════════════════════════════════════
  // 📊 FULL SYSTEM STATUS
  // ══════════════════════════════════════════════════════════════════════════
  static Future<String> getFullSystemStatus() async {
    final battery = await getBatteryInfo();
    final network = await getNetworkInfo();
    final device  = await getDeviceInfo();
    final perms   = await checkPermissions();

    final permGranted = perms.values.where((v) => v).length;
    final permTotal   = perms.length;

    return '''
📱 دەستگا: ${device['brand'] ?? ''} ${device['model'] ?? ''} (${device['platform']?.toString().toUpperCase() ?? ''} ${device['version'] ?? ''})
🔋 بەتری: ${battery['level']}%${battery['isCharging'] == true ? ' ⚡ شارژکراوە' : ''}
🌐 نەت: ${network['connected'] == true ? (network['isWifi'] == true ? '📶 WiFi' : '📱 داتای مۆبایل') : '❌ نییە'}
🔐 مۆڵەتەکان: $permGranted/$permTotal دراون''';
  }

  // ══════════════════════════════════════════════════════════════════════════
  // 🔗 SHARE — هاوبەشکردن
  // ══════════════════════════════════════════════════════════════════════════
  static Future<void> shareText(String text) async {
    // نیازی share_plus plugin
    await launchUrl(
      Uri.parse('https://wa.me/?text=${Uri.encodeComponent(text)}'),
      mode: LaunchMode.externalApplication,
    );
  }

  // ══════════════════════════════════════════════════════════════════════════
  // 🛒 PLAY STORE
  // ══════════════════════════════════════════════════════════════════════════
  static Future<bool> openPlayStore(String packageName) async {
    return await launchUrl(
      Uri.parse('market://details?id=$packageName'),
      mode: LaunchMode.externalApplication,
    ).catchError((_) async => await launchUrl(
      Uri.parse('https://play.google.com/store/apps/details?id=$packageName'),
      mode: LaunchMode.externalApplication,
    ));
  }

  // ══════════════════════════════════════════════════════════════════════════
  // 📅 CALENDAR
  // ══════════════════════════════════════════════════════════════════════════
  static Future<bool> openCalendar() async {
    return await launchUrl(
      Uri.parse('content://com.android.calendar/time/'),
      mode: LaunchMode.externalApplication,
    ).catchError((_) async => await openApp('calendar'));
  }

  // ══════════════════════════════════════════════════════════════════════════
  // 🎵 MUSIC
  // ══════════════════════════════════════════════════════════════════════════
  static Future<bool> openSpotify([String? query]) async {
    if (query != null) {
      return await launchUrl(
        Uri.parse('spotify:search:${Uri.encodeComponent(query)}'),
      ).catchError((_) async => await openApp('spotify'));
    }
    return await openApp('spotify');
  }
}
