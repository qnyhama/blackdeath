import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'screens/splash_screen.dart';
import 'services/storage_service.dart';
import 'services/mobile_control_service.dart';
import 'services/voice_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // portrait تەنها
  await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);

  // UI تاریک
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
    systemNavigationBarColor: Color(0xFF000000),
  ));

  // سێ سێرڤیس ئامادەکردن
  await StorageService.init();
  await MobileControlService.init();
  await VoiceService.init();

  runApp(const BlackDeathApp());
}

class BlackDeathApp extends StatelessWidget {
  const BlackDeathApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'BlackDeath',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF000000),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFFFF0000),
          secondary: Color(0xFF8B0000),
          surface: Color(0xFF0A0A0A),
        ),
        textTheme: GoogleFonts.notoKufiArabicTextTheme(
          Theme.of(context).textTheme.apply(
            bodyColor: Colors.white,
            displayColor: Colors.white,
          ),
        ),
        useMaterial3: true,
      ),
      home: const SplashScreen(),
    );
  }
}
