import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../services/gemini_service.dart';
import '../services/voice_service.dart';
import '../services/mobile_control_service.dart';
import '../services/osint_service.dart';
import '../widgets/waveform_widget.dart';
import '../widgets/message_bubble.dart';
import 'settings_screen.dart';
import 'osint_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with SingleTickerProviderStateMixin {
  final List<Map<String, dynamic>> _messages = [];
  final ScrollController _scroll = ScrollController();
  final TextEditingController _textCtrl = TextEditingController();

  bool _isListening = false;
  bool _isThinking = false;
  bool _isSpeaking = false;
  bool _isCallMode = false;
  String _currentTranscript = '';
  String _partialResponse = '';

  late AnimationController _pulseCtrl;
  late Animation<double> _pulseAnim;
  int _selectedTab = 0;

  @override
  void initState() {
    super.initState();
    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    )..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 0.9, end: 1.1).animate(
      CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut),
    );

    final greetings = [
      'سڵاو هاوڵێ! ☠ BlackDeath ئامادەیە — بۆچی نەپرسیت؟ 😄',
      'یەخ! ئایا تۆ بوویت؟ 😂 چی پێویستتە ئەمڕۆ هاوڵێ؟',
      'BlackDeath ئامادەیە بۆ هەر شتێک — خواردن، هاکینگ، یاری، عەشق، هەموو! 🔴',
      'سڵاو! ئەمڕۆ چی داوتێتەوە؟ پرسیارت هەیە، وەڵامم هەیە 😎☠',
    ];
    _addMessage('system', greetings[DateTime.now().millisecond % greetings.length]);

    // مۆڵەتەکان داواکە لە دەستپێکردا
    Future.delayed(const Duration(seconds: 2), () {
      MobileControlService.requestAllPermissions();
    });
  }

  void _addMessage(String role, String text) {
    setState(() => _messages.add({'role': role, 'text': text, 'time': DateTime.now()}));
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) {
        _scroll.animateTo(
          _scroll.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  Future<void> _startListening() async {
    if (_isListening || _isSpeaking) return;
    if (!mounted) return;
    HapticFeedback.mediumImpact();
    setState(() { _isListening = true; _currentTranscript = ''; });
    await VoiceService.startListening(
      onResult: (text) {
        if (!mounted) return;
        setState(() => _currentTranscript = text);
        _sendMessage(text);
      },
      onDone: () {
        if (!mounted) return;
        setState(() => _isListening = false);
      },
    );
  }

  Future<void> _stopListening() async {
    await VoiceService.stopListening();
    if (!mounted) return;
    setState(() => _isListening = false);
  }

  // دوای قسەکردن — ئەگەر call mode بوو خۆکاری گوێ دەگرێت
  Future<void> _resumeListeningAfterSpeak() async {
    if (!_isCallMode || !mounted) return;
    await Future.delayed(const Duration(milliseconds: 600));
    if (_isCallMode && !_isListening && !_isSpeaking && mounted) {
      _startListening();
    }
  }

  Future<void> _sendMessage(String text) async {
    if (text.trim().isEmpty) return;
    _textCtrl.clear();
    _addMessage('user', text);
    setState(() { _isThinking = true; _partialResponse = ''; });

    // ── ١: چەک بکە کۆنترۆڵی مۆبایلە یان نا ──────────────────────────────
    final commandResult = await MobileControlService.executeCommand(text);
    if (commandResult.isNotEmpty) {
      setState(() => _isThinking = false);
      _addMessage('assistant', commandResult);
      if (_isCallMode) {
        await VoiceService.speakFull(commandResult);
      } else {
        await VoiceService.speak(commandResult);
      }
      setState(() => _isSpeaking = false);
      _resumeListeningAfterSpeak();
      return;
    }

    // ── ٢: هەواشناسی ─────────────────────────────────────────────────────
    final lower = text.toLowerCase();
    if (lower.contains('هەوا') || lower.contains('کەشوهەوا') || lower.contains('weather')) {
      final weatherResp = await _getWeatherResponse(text);
      setState(() => _isThinking = false);
      _addMessage('assistant', weatherResp);
      await VoiceService.speak(weatherResp);
      return;
    }

    // ── ٣: OSINT IP ──────────────────────────────────────────────────────
    if (lower.contains('ip') && (lower.contains('بگەڕێ') || lower.contains('چەک'))) {
      final ipMatch = RegExp(r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}').firstMatch(text);
      final ip = ipMatch?.group(0) ?? '8.8.8.8';
      final result = await OsintService.ipLookup(ip);
      final resp = result.isEmpty
          ? '⚠️ IP نەدۆزرایەوە'
          : '🌐 IP: ${result['ip']}\n🗺️ وڵات: ${result['country_name']}\n🏙️ شار: ${result['city']}';
      setState(() => _isThinking = false);
      _addMessage('assistant', resp);
      await VoiceService.speak(resp);
      return;
    }

    // ── ٤: Gemini AI ──────────────────────────────────────────────────────
    final responseBuffer = StringBuffer();
    await for (final chunk in GeminiService.chatStream(text)) {
      responseBuffer.write(chunk);
      setState(() => _partialResponse = responseBuffer.toString());
    }

    setState(() { _isThinking = false; _partialResponse = ''; });
    final finalResponse = responseBuffer.toString();
    if (finalResponse.isNotEmpty) {
      _addMessage('assistant', finalResponse);
      setState(() => _isSpeaking = true);
      if (_isCallMode) {
        await VoiceService.speakFull(finalResponse);
      } else {
        await VoiceService.speak(finalResponse);
      }
      setState(() => _isSpeaking = false);
      // ئەگەر call mode بوو — خۆکاری دووبارە گوێ دەگرێت وەکو Jarvis ☠
      _resumeListeningAfterSpeak();
    }
  }

  Future<String> _getWeatherResponse(String text) async {
    String city = 'Kirkuk';
    if (text.contains('سلێمانی')) city = 'Sulaymaniyah';
    else if (text.contains('هەولێر') || text.contains('ئەربیل')) city = 'Erbil';
    else if (text.contains('دهۆک')) city = 'Duhok';
    else if (text.contains('موسڵ')) city = 'Mosul';
    else if (text.contains('بەغدا')) city = 'Baghdad';
    else if (text.contains('کرکوک')) city = 'Kirkuk';

    final w = await OsintService.getWeather(city);
    if (w.isEmpty) return '⚠️ ناتوانم زانیاری هەواشناسی وەربگرم';
    final current = w['current'] as Map? ?? {};
    final temp = current['temperature_2m'];
    final humidity = current['relative_humidity_2m'];
    final wind = current['wind_speed_10m'];
    return '🌤️ $city:\n🌡️ ${temp}°C | 💧 ${humidity}% | 💨 ${wind} km/h';
  }

  void _toggleCallMode() {
    setState(() => _isCallMode = !_isCallMode);
    if (_isCallMode) _startListening();
    else { _stopListening(); VoiceService.stop(); }
  }

  @override
  void dispose() {
    _pulseCtrl.dispose();
    _scroll.dispose();
    _textCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_isCallMode) return _buildCallMode();
    return _buildMainUI();
  }

  // ── CALL MODE ─────────────────────────────────────────────────────────────
  Widget _buildCallMode() {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(children: [
        AnimatedBuilder(
          animation: _pulseAnim,
          builder: (_, __) => Center(
            child: Container(
              width: 300 * _pulseAnim.value,
              height: 300 * _pulseAnim.value,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                boxShadow: [BoxShadow(
                  color: const Color(0xFFFF0000).withOpacity(
                    _isListening ? 0.3 : (_isSpeaking ? 0.2 : 0.05)),
                  blurRadius: 80, spreadRadius: 40,
                )],
              ),
            ),
          ),
        ),
        SafeArea(child: Column(children: [
          const SizedBox(height: 40),
          Text(
            _isListening ? 'گوێم لێتەیە...'
              : _isThinking ? 'فیکرم لێوە...'
              : _isSpeaking ? 'قسە دەکەم...'
              : 'BlackDeath ئامادەیە',
            style: TextStyle(
              color: _isListening ? const Color(0xFFFF0000) : Colors.white54,
              fontSize: 18,
            ),
            textDirection: TextDirection.rtl,
          ),
          const Spacer(),
          AnimatedBuilder(
            animation: _pulseAnim,
            builder: (_, __) => Transform.scale(
              scale: _isListening || _isSpeaking ? _pulseAnim.value : 1.0,
              child: Container(
                width: 140, height: 140,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: _isListening ? const Color(0xFFFF0000) : const Color(0xFF333333),
                    width: 2,
                  ),
                  boxShadow: _isListening
                    ? [const BoxShadow(color: Color(0xFFFF0000), blurRadius: 30)]
                    : [],
                ),
                child: const Center(child: Text('☠', style: TextStyle(fontSize: 80, color: Color(0xFFFF0000)))),
              ),
            ),
          ),
          const SizedBox(height: 20),
          WaveformWidget(isActive: _isListening || _isSpeaking, color: const Color(0xFFFF0000)),
          if (_currentTranscript.isNotEmpty) Padding(
            padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 8),
            child: Text(_currentTranscript,
              textAlign: TextAlign.center,
              textDirection: TextDirection.rtl,
              style: const TextStyle(color: Colors.white70, fontSize: 15)),
          ),
          if (_partialResponse.isNotEmpty) Padding(
            padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 8),
            child: Text(_partialResponse,
              textAlign: TextAlign.center,
              textDirection: TextDirection.rtl,
              style: const TextStyle(color: Color(0xFFFF6666), fontSize: 14),
              maxLines: 4, overflow: TextOverflow.ellipsis),
          ),
          const Spacer(),
          GestureDetector(
            onTap: _toggleCallMode,
            child: Container(
              width: 72, height: 72,
              margin: const EdgeInsets.only(bottom: 48),
              decoration: BoxDecoration(
                color: const Color(0xFFCC0000),
                shape: BoxShape.circle,
                boxShadow: [BoxShadow(
                  color: const Color(0xFFFF0000).withOpacity(0.5),
                  blurRadius: 20, spreadRadius: 4,
                )],
              ),
              child: const Icon(Icons.call_end, color: Colors.white, size: 32),
            ),
          ),
        ])),
      ]),
    );
  }

  // ── MAIN UI ───────────────────────────────────────────────────────────────
  Widget _buildMainUI() {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: const Color(0xFF050505),
        elevation: 0,
        title: const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          Text('☠', style: TextStyle(fontSize: 22, color: Color(0xFFFF0000))),
          SizedBox(width: 8),
          Text('BlackDeath', style: TextStyle(
            color: Color(0xFFFF0000), fontWeight: FontWeight.bold, fontSize: 20,
            shadows: [Shadow(color: Color(0xFFFF0000), blurRadius: 8)],
          )),
        ]),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.settings, color: Color(0xFF666666)),
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SettingsScreen())),
          ),
        ],
        leading: IconButton(
          icon: const Icon(Icons.delete_outline, color: Color(0xFF666666)),
          onPressed: () {
            GeminiService.clearHistory();
            setState(() => _messages.clear());
            _addMessage('system', 'مێژووی گفتوگۆ سڕایەوە ☠');
          },
        ),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(height: 1, color: const Color(0xFF1A0000)),
        ),
      ),
      body: Column(children: [
        _buildTabBar(),
        Expanded(child: _selectedTab == 0
          ? _buildChatView()
          : _selectedTab == 1
            ? const OsintScreen()
            : _buildToolsView()),
        if (_selectedTab == 0) _buildInputArea(),
      ]),
    );
  }

  Widget _buildTabBar() {
    final tabs = [
      (Icons.forum_outlined, 'BlackDeath'),
      (Icons.radar, 'OSINT'),
      (Icons.apps, 'ئامرازەکان'),
    ];
    return Container(
      color: const Color(0xFF050505),
      child: Row(children: tabs.asMap().entries.map((e) {
        final selected = _selectedTab == e.key;
        return Expanded(child: GestureDetector(
          onTap: () => setState(() => _selectedTab = e.key),
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: 12),
            decoration: BoxDecoration(border: Border(bottom: BorderSide(
              color: selected ? const Color(0xFFFF0000) : Colors.transparent, width: 2,
            ))),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Icon(e.value.$1, size: 18,
                color: selected ? const Color(0xFFFF0000) : const Color(0xFF555555)),
              const SizedBox(height: 2),
              Text(e.value.$2, style: TextStyle(
                fontSize: 11,
                color: selected ? const Color(0xFFFF0000) : const Color(0xFF555555),
              )),
            ]),
          ),
        ));
      }).toList()),
    );
  }

  Widget _buildChatView() {
    return ListView.builder(
      controller: _scroll,
      padding: const EdgeInsets.all(16),
      itemCount: _messages.length + (_isThinking || _partialResponse.isNotEmpty ? 1 : 0),
      itemBuilder: (_, i) {
        if (i == _messages.length) {
          if (_partialResponse.isNotEmpty) {
            return MessageBubble(role: 'assistant', text: _partialResponse, isStreaming: true);
          }
          return const _ThinkingBubble();
        }
        final m = _messages[i];
        return MessageBubble(role: m['role'], text: m['text']);
      },
    );
  }

  Widget _buildInputArea() {
    return Container(
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 20),
      decoration: const BoxDecoration(
        color: Color(0xFF050505),
        border: Border(top: BorderSide(color: Color(0xFF1A0000))),
      ),
      child: Row(children: [
        // دوگمەی Call — گەورە و ئانیمەیشندار وەکو Jarvis
        GestureDetector(
          onTap: _toggleCallMode,
          child: AnimatedBuilder(
            animation: _pulseAnim,
            builder: (_, __) => Transform.scale(
              scale: _isCallMode ? _pulseAnim.value : 1.0,
              child: Container(
                width: 58, height: 58,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _isCallMode ? const Color(0xFFFF0000) : const Color(0xFFCC0000),
                  boxShadow: [BoxShadow(
                    color: const Color(0xFFFF0000).withOpacity(_isCallMode ? 0.7 : 0.4),
                    blurRadius: _isCallMode ? 20 : 12,
                    spreadRadius: _isCallMode ? 3 : 0,
                  )],
                ),
                child: Icon(
                  _isCallMode ? Icons.call_end : Icons.call,
                  color: Colors.white, size: 26,
                ),
              ),
            ),
          ),
        ),
        const SizedBox(width: 8),
        Expanded(child: TextField(
          controller: _textCtrl,
          textDirection: TextDirection.rtl,
          style: const TextStyle(color: Colors.white),
          decoration: InputDecoration(
            hintText: 'پرسیارت هەیە؟...',
            hintTextDirection: TextDirection.rtl,
            hintStyle: const TextStyle(color: Color(0xFF444444)),
            filled: true, fillColor: const Color(0xFF0A0A0A),
            contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(24),
              borderSide: const BorderSide(color: Color(0xFF2A0000)),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(24),
              borderSide: const BorderSide(color: Color(0xFF2A0000)),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(24),
              borderSide: const BorderSide(color: Color(0xFFFF0000), width: 1.5),
            ),
          ),
          onSubmitted: _sendMessage,
        )),
        const SizedBox(width: 8),
        GestureDetector(
          onTap: _isListening ? _stopListening : () {
            if (_textCtrl.text.isNotEmpty) _sendMessage(_textCtrl.text);
            else _startListening();
          },
          child: Container(
            width: 48, height: 48,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: _isListening ? const Color(0xFFFF0000) : const Color(0xFF1A0000),
              border: Border.all(color: const Color(0xFFFF0000), width: 1),
            ),
            child: Icon(
              _isListening ? Icons.stop : Icons.mic,
              color: const Color(0xFFFF0000), size: 22,
            ),
          ),
        ),
      ]),
    );
  }

  // ── TOOLS VIEW — ئامرازەکان ────────────────────────────────────────────────
  Widget _buildToolsView() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [

        // ── موبایل کۆنترۆڵ ─────────────────────────────────────────────────
        _toolSection('📱 کۆنترۆڵی موبایل', [
          ('🔋', 'بەتری', () async {
            final info = await MobileControlService.getBatteryInfo();
            _showInfoDialog('بەتری',
              '🔋 ${info['level']}%\n${info['isCharging'] == true ? '⚡ شارژکراوە' : '🔌 شارژ نییە'}');
          }),
          ('🌐', 'نەت', () async {
            final info = await MobileControlService.getNetworkInfo();
            _showInfoDialog('ئینتەرنێت',
              info['connected'] == true
                ? '✅ پەیوەستە\n${info['isWifi'] == true ? '📶 WiFi' : '📱 داتا'}'
                : '❌ پەیوەندی نییە');
          }),
          ('📱', 'دەستگا', () async {
            final s = await MobileControlService.getFullSystemStatus();
            _showInfoDialog('دەستگا', s);
          }),
          ('🔐', 'مۆڵەت', () async {
            final p = await MobileControlService.checkPermissions();
            final lines = p.entries.map((e) =>
              '${e.value ? "✅" : "❌"} ${e.key}').join('\n');
            _showInfoDialog('مۆڵەتەکان', lines);
            if (p.values.any((v) => !v)) {
              await MobileControlService.requestAllPermissions();
            }
          }),
        ]),

        // ── فیچەرەکان ──────────────────────────────────────────────────────
        _toolSection('⚡ فیچەرەکان', [
          ('🔦', 'فلاش', () async {
            final on = await MobileControlService.toggleFlashlight();
            _showSnack(on ? '🔦 فلاشلایت کراوەکرا' : '🔦 فلاشلایت خامۆشکرا');
          }),
          ('📳', 'لەرزین', () async {
            await MobileControlService.vibrate();
          }),
          ('🔇', 'مووت', () async {
            await MobileControlService.muteDevice();
            _showSnack('🔇 دەنگ خامۆشکرا');
          }),
          ('📋', 'کلیپ', () async {
            final text = await MobileControlService.pasteFromClipboard();
            _showInfoDialog('کلیپبۆرد', text ?? 'بەتاڵە');
          }),
        ]),

        // ── هەواشناسی ──────────────────────────────────────────────────────
        _toolSection('🌤️ هەواشناسی', [
          ('🏙️', 'هەولێر', () async {
            final w = await _getWeatherResponse('هەولێر');
            _showInfoDialog('هەواشناسی', w);
          }),
          ('🏔️', 'سلێمانی', () async {
            final w = await _getWeatherResponse('سلێمانی');
            _showInfoDialog('هەواشناسی', w);
          }),
          ('⛽', 'کرکوک', () async {
            final w = await _getWeatherResponse('کرکوک');
            _showInfoDialog('هەواشناسی', w);
          }),
          ('🌲', 'دهۆک', () async {
            final w = await _getWeatherResponse('دهۆک');
            _showInfoDialog('هەواشناسی', w);
          }),
        ]),

        // ── ئاپەکان ────────────────────────────────────────────────────────
        _toolSection('🚀 ئاپ بکەوەتە', [
          ('💬', 'واتساپ',  () => MobileControlService.openApp('whatsapp')),
          ('✈️', 'تێلیگرام', () => MobileControlService.openApp('telegram')),
          ('▶️', 'یوتیوب',   () => MobileControlService.openApp('youtube')),
          ('📷', 'ئینستا',   () => MobileControlService.openApp('instagram')),
          ('🎵', 'تیکتۆک',  () => MobileControlService.openApp('tiktok')),
          ('🌍', 'کرۆم',    () => MobileControlService.openApp('chrome')),
          ('🗺️', 'نەخشە',   () => MobileControlService.openMaps('Kurdistan Region')),
          ('⚙️', 'ڕێکخستن', () => MobileControlService.openApp('settings')),
        ]),

        // ── پەیوەندی ───────────────────────────────────────────────────────
        _toolSection('📞 پەیوەندی', [
          ('📞', 'تەلەفۆن', () => _quickInput('تەلەفۆن', 'نومرەی تەلەفۆن بنووسە',
              (v) => MobileControlService.makeCall(v))),
          ('💬', 'SMS', () => _quickInput('SMS', 'نومرە : پەیام',
              (v) {
                final parts = v.split(':');
                if (parts.length >= 2) {
                  MobileControlService.sendSms(parts[0].trim(), parts.sublist(1).join(':').trim());
                }
              })),
          ('💚', 'واتساپ', () => _quickInput('واتساپ', 'نومرەی بە کۆدی وڵات (+964...)',
              (v) => MobileControlService.openWhatsApp(v))),
          ('📧', 'ئیمەیڵ', () => _quickInput('ئیمەیڵ', 'ئادرێسی ئیمەیڵ',
              (v) => MobileControlService.sendEmail(to: v))),
        ]),

        // ── ئامرازی AI ─────────────────────────────────────────────────────
        _toolSection('🤖 پرسیاری BlackDeath', [
          ('🍽️', 'خواردن',  () => _askBD('چێشتێکی باش پێم پێشنیار بکە')),
          ('💪', 'وەرزش',  () => _askBD('ئیدمانێکم بدە بۆ ئەمڕۆ')),
          ('🎮', 'یاری',   () => _askBD('یارییەکی باش پێشنیار بکە')),
          ('🎵', 'مۆزیک',  () => _askBD('گۆرانییەکی باش پێشنیار بکە')),
          ('🧠', 'فێربوون', () => _askBD('شتێکی سەرنجڕاکێشم فێر بکە')),
          ('💼', 'کار',    () => _askBD('ئامۆژگاری کاری پێوەبدە')),
          ('🔐', 'هاکینگ', () => _askBD('ئامۆژگاری سایبەر سیکیوریتی پێوەبدە')),
          ('😈', 'تاریک',  () => _askBD('شتێکی تاریک باسم بکە')),
        ]),

        // ── ئامرازی سەرەکی ────────────────────────────────────────────────
        _toolSection('🛠️ سەرەکی', [
          ('⚙️', 'ڕێکخستن', () => Navigator.push(context,
              MaterialPageRoute(builder: (_) => const SettingsScreen()))),
          ('🗑️', 'سڕینەوە', () {
            GeminiService.clearHistory();
            setState(() => _messages.clear());
            _addMessage('system', 'مێژووی گفتوگۆ سڕایەوە ☠');
          }),
        ]),
      ]),
    );
  }

  Widget _toolSection(String title, List<(String, String, VoidCallback)> items) {
    return Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
      Padding(
        padding: const EdgeInsets.only(bottom: 10, top: 4),
        child: Text(title,
          textDirection: TextDirection.rtl,
          style: const TextStyle(
            color: Color(0xFFFF0000), fontSize: 14, fontWeight: FontWeight.bold,
          )),
      ),
      GridView.count(
        crossAxisCount: 4,
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        crossAxisSpacing: 10, mainAxisSpacing: 10,
        childAspectRatio: 0.85,
        children: items.map((t) => GestureDetector(
          onTap: t.$3,
          child: Container(
            decoration: BoxDecoration(
              color: const Color(0xFF0A0A0A),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: const Color(0xFF2A0000)),
            ),
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              Text(t.$1, style: const TextStyle(fontSize: 26)),
              const SizedBox(height: 5),
              Text(t.$2,
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.white70, fontSize: 11)),
            ]),
          ),
        )).toList(),
      ),
      const SizedBox(height: 16),
    ]);
  }

  Future<void> _askBD(String prompt) async {
    setState(() => _selectedTab = 0);
    await Future.delayed(const Duration(milliseconds: 200));
    _sendMessage(prompt);
  }

  void _quickInput(String title, String hint, Function(String) onConfirm) {
    final ctrl = TextEditingController();
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: const Color(0xFF0A0A0A),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: const BorderSide(color: Color(0xFF8B0000)),
        ),
        title: Text(title,
          style: const TextStyle(color: Color(0xFFFF0000), fontWeight: FontWeight.bold)),
        content: TextField(
          controller: ctrl,
          autofocus: true,
          style: const TextStyle(color: Colors.white),
          decoration: InputDecoration(
            hintText: hint,
            hintStyle: const TextStyle(color: Color(0xFF666666)),
            filled: true, fillColor: const Color(0xFF111111),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
              borderSide: const BorderSide(color: Color(0xFF8B0000)),
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('پاشگەزبوونەوە', style: TextStyle(color: Colors.white38)),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              onConfirm(ctrl.text.trim());
            },
            style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFCC0000)),
            child: const Text('ئەنجامدە'),
          ),
        ],
      ),
    );
  }

  void _showInfoDialog(String title, String content) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: const Color(0xFF0A0A0A),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: const BorderSide(color: Color(0xFF8B0000)),
        ),
        title: Text(title,
          style: const TextStyle(color: Color(0xFFFF0000), fontWeight: FontWeight.bold)),
        content: Text(content,
          textDirection: TextDirection.rtl,
          style: const TextStyle(color: Colors.white, height: 1.6)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('باشە', style: TextStyle(color: Color(0xFFFF0000))),
          ),
        ],
      ),
    );
  }

  void _showSnack(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg, textDirection: TextDirection.rtl),
      backgroundColor: const Color(0xFF8B0000),
      duration: const Duration(seconds: 2),
    ));
  }
}

class _ThinkingBubble extends StatefulWidget {
  const _ThinkingBubble();
  @override
  State<_ThinkingBubble> createState() => _ThinkingBubbleState();
}

class _ThinkingBubbleState extends State<_ThinkingBubble>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 600))
      ..repeat(reverse: true);
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.only(bottom: 8, right: 48),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(
          color: const Color(0xFF0A0A0A),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: const Color(0xFF2A0000)),
        ),
        child: AnimatedBuilder(
          animation: _ctrl,
          builder: (_, __) => Row(
            mainAxisSize: MainAxisSize.min,
            children: List.generate(3, (i) => Container(
              margin: const EdgeInsets.symmetric(horizontal: 3),
              width: 8, height: 8,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Color.lerp(
                  const Color(0xFF8B0000), const Color(0xFFFF0000),
                  sin((_ctrl.value * pi) + (i * pi / 3)).abs(),
                ),
              ),
            )),
          ),
        ),
      ),
    );
  }
}
