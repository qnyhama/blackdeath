import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../services/gemini_service.dart';
import '../services/voice_service.dart';
import '../services/mobile_control_service.dart';
import '../services/osint_service.dart';
import '../widgets/waveform_widget.dart';
import '../widgets/message_bubble.dart';
import 'settings_screen.dart';
import 'osint_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with SingleTickerProviderStateMixin {
  final List<Map<String, dynamic>> _messages = [];
  final ScrollController _scroll = ScrollController();
  final TextEditingController _textCtrl = TextEditingController();

  bool _isListening = false;
  bool _isThinking = false;
  bool _isSpeaking = false;
  bool _isCallMode = false;
  String _currentTranscript = '';
  String _partialResponse = '';
  int _selectedTab = 0; // 0=OSINT, 1=Tools

  late AnimationController _pulseCtrl;
  late Animation<double> _pulseAnim;

  @override
  void initState() {
    super.initState();
    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    )..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 0.92, end: 1.08).animate(
      CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut),
    );
    Future.delayed(const Duration(seconds: 2), () {
      MobileControlService.requestAllPermissions();
    });
  }

  void _addMessage(String role, String text) {
    setState(() => _messages.add({'role': role, 'text': text, 'time': DateTime.now()}));
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) {
        _scroll.animateTo(_scroll.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300), curve: Curves.easeOut);
      }
    });
  }

  Future<void> _startListening() async {
    if (_isListening || _isSpeaking) return;
    if (!mounted) return;
    HapticFeedback.mediumImpact();
    setState(() { _isListening = true; _currentTranscript = ''; });
    await VoiceService.startListening(
      onResult: (text) {
        if (!mounted) return;
        setState(() => _currentTranscript = text);
        _sendMessage(text);
      },
      onDone: () {
        if (!mounted) return;
        setState(() => _isListening = false);
      },
    );
  }

  Future<void> _stopListening() async {
    await VoiceService.stopListening();
    if (!mounted) return;
    setState(() => _isListening = false);
  }

  Future<void> _resumeListeningAfterSpeak() async {
    if (!_isCallMode || !mounted) return;
    await Future.delayed(const Duration(milliseconds: 800));
    if (_isCallMode && !_isListening && !_isSpeaking && mounted) {
      _startListening();
    }
  }

  Future<void> _sendMessage(String text) async {
    if (text.trim().isEmpty) return;
    _textCtrl.clear();
    _addMessage('user', text);
    setState(() { _isThinking = true; _partialResponse = ''; });

    // ── ١: کۆنترۆڵی موبایل
    final commandResult = await MobileControlService.executeCommand(text);
    if (commandResult.isNotEmpty) {
      setState(() => _isThinking = false);
      _addMessage('assistant', commandResult);
      setState(() => _isSpeaking = true);
      await VoiceService.speakFull(commandResult);
      setState(() => _isSpeaking = false);
      _resumeListeningAfterSpeak();
      return;
    }

    // ── ٢: هەواشناسی
    final lower = text.toLowerCase();
    if (lower.contains('هەوا') || lower.contains('weather')) {
      final weatherResp = await _getWeatherResponse(text);
      setState(() => _isThinking = false);
      _addMessage('assistant', weatherResp);
      setState(() => _isSpeaking = true);
      await VoiceService.speakFull(weatherResp);
      setState(() => _isSpeaking = false);
      _resumeListeningAfterSpeak();
      return;
    }

    // ── ٣: Gemini AI
    final responseBuffer = StringBuffer();
    await for (final chunk in GeminiService.chatStream(text)) {
      responseBuffer.write(chunk);
      if (mounted) setState(() => _partialResponse = responseBuffer.toString());
    }

    if (!mounted) return;
    setState(() { _isThinking = false; _partialResponse = ''; });
    final finalResponse = responseBuffer.toString();
    if (finalResponse.isNotEmpty) {
      _addMessage('assistant', finalResponse);
      setState(() => _isSpeaking = true);
      await VoiceService.speakFull(finalResponse);
      setState(() => _isSpeaking = false);
      _resumeListeningAfterSpeak();
    }
  }

  Future<String> _getWeatherResponse(String text) async {
    String city = 'Kirkuk';
    if (text.contains('سلێمانی')) city = 'Sulaymaniyah';
    else if (text.contains('هەولێر') || text.contains('ئەربیل')) city = 'Erbil';
    else if (text.contains('دهۆک')) city = 'Duhok';
    else if (text.contains('موسڵ')) city = 'Mosul';
    else if (text.contains('بەغدا')) city = 'Baghdad';
    final w = await OsintService.getWeather(city);
    if (w.isEmpty) return 'نازانم هەوای $city چۆنە ئێستا';
    final current = w['current'] as Map? ?? {};
    final temp = current['temperature_2m'];
    final humidity = current['relative_humidity_2m'];
    final wind = current['wind_speed_10m'];
    return '$city: ${temp}°C، شل ${humidity}%، با ${wind} کیلۆمەتر';
  }

  void _toggleCallMode() {
    HapticFeedback.heavyImpact();
    setState(() => _isCallMode = !_isCallMode);
    if (_isCallMode) {
      _startListening();
    } else {
      _stopListening();
      VoiceService.stop();
    }
  }

  @override
  void dispose() {
    _pulseCtrl.dispose();
    _scroll.dispose();
    _textCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_isCallMode) return _buildCallScreen();
    return _buildMainScreen();
  }

  // ══════════════════════════════════════════════════════════════════════════
  // JARVIS CALL SCREEN — تەنها ئەمە مەرجی سەرەکیە
  // ══════════════════════════════════════════════════════════════════════════
  Widget _buildCallScreen() {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(children: [

        // Background glow — وەکو Jarvis
        AnimatedBuilder(
          animation: _pulseAnim,
          builder: (_, __) => Center(
            child: Container(
              width: 380 * _pulseAnim.value,
              height: 380 * _pulseAnim.value,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(colors: [
                  const Color(0xFFCC0000).withOpacity(
                    _isListening ? 0.18 : (_isSpeaking ? 0.12 : 0.04)),
                  Colors.transparent,
                ]),
              ),
            ),
          ),
        ),

        // Grid lines — وەکو Jarvis HUD
        CustomPaint(
          painter: _JarvisGridPainter(),
          child: Container(),
        ),

        SafeArea(child: Column(children: [

          // Status text
          Padding(
            padding: const EdgeInsets.only(top: 32),
            child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 400),
              child: Text(
                key: ValueKey(_isListening ? 1 : _isThinking ? 2 : _isSpeaking ? 3 : 0),
                _isListening ? 'گوێم لێتەیە...'
                  : _isThinking ? 'فیکرم لێوە...'
                  : _isSpeaking ? 'BlackDeath قسەدەکات...'
                  : 'BLACKDEATH — ئامادەیە',
                style: TextStyle(
                  color: _isListening
                    ? const Color(0xFFFF4444)
                    : _isSpeaking
                      ? const Color(0xFFFF8888)
                      : const Color(0xFF666666),
                  fontSize: _isListening || _isSpeaking ? 18 : 14,
                  fontWeight: FontWeight.w300,
                  letterSpacing: 2,
                ),
                textDirection: TextDirection.rtl,
              ),
            ),
          ),

          const Spacer(flex: 2),

          // ☠ BlackDeath Logo — وەکو Jarvis core
          AnimatedBuilder(
            animation: _pulseAnim,
            builder: (_, __) {
              final scale = _isListening || _isSpeaking ? _pulseAnim.value : 1.0;
              return Transform.scale(
                scale: scale,
                child: Stack(alignment: Alignment.center, children: [
                  // Outer ring
                  Container(
                    width: 180, height: 180,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: const Color(0xFFCC0000).withOpacity(
                          _isListening ? 0.8 : 0.3),
                        width: 1.5,
                      ),
                    ),
                  ),
                  // Inner ring
                  Container(
                    width: 150, height: 150,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: const Color(0xFFFF0000).withOpacity(
                          _isListening ? 0.6 : 0.15),
                        width: 1,
                      ),
                    ),
                  ),
                  // Core
                  Container(
                    width: 120, height: 120,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.black,
                      boxShadow: [
                        BoxShadow(
                          color: const Color(0xFFFF0000).withOpacity(
                            _isListening ? 0.5 : (_isSpeaking ? 0.3 : 0.1)),
                          blurRadius: 40,
                          spreadRadius: 10,
                        ),
                      ],
                      border: Border.all(
                        color: const Color(0xFFFF0000).withOpacity(0.4),
                        width: 1,
                      ),
                    ),
                    child: const Center(
                      child: Text('☠',
                        style: TextStyle(fontSize: 60, color: Color(0xFFFF0000))),
                    ),
                  ),
                ]),
              );
            },
          ),

          const SizedBox(height: 24),

          // Waveform
          WaveformWidget(
            isActive: _isListening || _isSpeaking,
            color: const Color(0xFFFF0000),
          ),

          // Transcript
          if (_currentTranscript.isNotEmpty)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 8),
              child: Text(
                _currentTranscript,
                textAlign: TextAlign.center,
                textDirection: TextDirection.rtl,
                style: const TextStyle(
                  color: Colors.white60, fontSize: 15, height: 1.5),
              ),
            ),

          // Partial response
          if (_partialResponse.isNotEmpty)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 4),
              child: Text(
                _partialResponse,
                textAlign: TextAlign.center,
                textDirection: TextDirection.rtl,
                style: const TextStyle(
                  color: Color(0xFFFF6666), fontSize: 13, height: 1.5),
                maxLines: 4, overflow: TextOverflow.ellipsis,
              ),
            ),

          const Spacer(flex: 3),

          // End call button
          GestureDetector(
            onTap: _toggleCallMode,
            child: AnimatedBuilder(
              animation: _pulseAnim,
              builder: (_, __) => Container(
                width: 68, height: 68,
                margin: const EdgeInsets.only(bottom: 50),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: const Color(0xFFCC0000),
                  boxShadow: [BoxShadow(
                    color: const Color(0xFFFF0000).withOpacity(0.6),
                    blurRadius: 24, spreadRadius: 4,
                  )],
                ),
                child: const Icon(Icons.call_end, color: Colors.white, size: 30),
              ),
            ),
          ),
        ])),
      ]),
    );
  }

  // ══════════════════════════════════════════════════════════════════════════
  // MAIN SCREEN — پشتەوە (بەس بۆ مێژوو و ئامرازەکان)
  // ══════════════════════════════════════════════════════════════════════════
  Widget _buildMainScreen() {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: const Color(0xFF050505),
        elevation: 0,
        title: const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          Text('☠', style: TextStyle(fontSize: 22, color: Color(0xFFFF0000))),
          SizedBox(width: 8),
          Text('BlackDeath', style: TextStyle(
            color: Color(0xFFFF0000), fontWeight: FontWeight.bold, fontSize: 20,
            shadows: [Shadow(color: Color(0xFFFF0000), blurRadius: 8)],
          )),
        ]),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.settings, color: Color(0xFF555555)),
            onPressed: () => Navigator.push(context,
              MaterialPageRoute(builder: (_) => const SettingsScreen())),
          ),
        ],
        leading: IconButton(
          icon: const Icon(Icons.delete_outline, color: Color(0xFF555555)),
          onPressed: () {
            GeminiService.clearHistory();
            setState(() => _messages.clear());
          },
        ),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(height: 1, color: const Color(0xFF1A0000)),
        ),
      ),
      body: Column(children: [
        // Tabs — OSINT و ئامرازەکان
        _buildTabBar(),
        Expanded(child: _selectedTab == 0
          ? const OsintScreen()
          : _buildToolsView()),
      ]),

      // ── JARVIS CALL BUTTON — گەورەترین شتی UI
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      bottomNavigationBar: _buildBottomBar(),
    );
  }

  Widget _buildBottomBar() {
    return Container(
      height: 100,
      decoration: const BoxDecoration(
        color: Color(0xFF050505),
        border: Border(top: BorderSide(color: Color(0xFF1A0000))),
      ),
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [

        // Call Button — Jarvis style
        GestureDetector(
          onTap: _toggleCallMode,
          child: AnimatedBuilder(
            animation: _pulseAnim,
            builder: (_, __) => Stack(alignment: Alignment.center, children: [
              // Outer glow ring
              Container(
                width: 72 * _pulseAnim.value,
                height: 72 * _pulseAnim.value,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: const Color(0xFFFF0000).withOpacity(0.3),
                    width: 1,
                  ),
                ),
              ),
              // Main button
              Container(
                width: 58, height: 58,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: const Color(0xFFCC0000),
                  boxShadow: [BoxShadow(
                    color: const Color(0xFFFF0000).withOpacity(0.5),
                    blurRadius: 16, spreadRadius: 2,
                  )],
                ),
                child: const Icon(Icons.mic, color: Colors.white, size: 26),
              ),
            ]),
          ),
        ),

        const SizedBox(height: 4),
        const Text('BlackDeath بانگ بکە',
          style: TextStyle(color: Color(0xFF444444), fontSize: 11)),
      ]),
    );
  }

  Widget _buildTabBar() {
    return Container(
      color: const Color(0xFF050505),
      child: Row(children: [
        _tab(0, Icons.radar, 'OSINT'),
        _tab(1, Icons.apps, 'ئامرازەکان'),
      ]),
    );
  }

  Widget _tab(int index, IconData icon, String label) {
    final selected = _selectedTab == index;
    return Expanded(child: GestureDetector(
      onTap: () => setState(() => _selectedTab = index),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          border: Border(bottom: BorderSide(
            color: selected ? const Color(0xFFFF0000) : Colors.transparent,
            width: 2,
          )),
        ),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, size: 18,
            color: selected ? const Color(0xFFFF0000) : const Color(0xFF444444)),
          const SizedBox(height: 2),
          Text(label, style: TextStyle(
            fontSize: 11,
            color: selected ? const Color(0xFFFF0000) : const Color(0xFF444444),
          )),
        ]),
      ),
    ));
  }

  // ── TOOLS VIEW ────────────────────────────────────────────────────────────
  Widget _buildToolsView() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [

        _toolSection('📱 کۆنترۆڵی موبایل', [
          ('🔋', 'بەتری', () async {
            final i = await MobileControlService.getBatteryInfo();
            _dialog('بەتری', '${i['level']}%\n${i['isCharging'] == true ? 'شارژکراوە' : 'شارژ نییە'}');
          }),
          ('🌐', 'ئینتەرنێت', () async {
            final i = await MobileControlService.getNetworkInfo();
            _dialog('ئینتەرنێت', i['connected'] == true ? 'پەیوەستە\n${i['isWifi'] == true ? 'WiFi' : 'داتا'}' : 'پەیوەندی نییە');
          }),
          ('📱', 'دەستگا', () async {
            final s = await MobileControlService.getFullSystemStatus();
            _dialog('دەستگا', s);
          }),
          ('🔐', 'مۆڵەت', () async {
            final p = await MobileControlService.checkPermissions();
            _dialog('مۆڵەتەکان', p.entries.map((e) => '${e.value ? "✅" : "❌"} ${e.key}').join('\n'));
          }),
        ]),

        _toolSection('⚡ فیچەرەکان', [
          ('🔦', 'فلاش', () async { final on = await MobileControlService.toggleFlashlight(); _snack(on ? 'فلاش کراوەکرا' : 'فلاش خامۆشکرا'); }),
          ('📳', 'لەرزین', () => MobileControlService.vibrate()),
          ('🔇', 'مووت', () async { await MobileControlService.muteDevice(); _snack('دەنگ خامۆشکرا'); }),
          ('📋', 'کلیپ', () async { final t = await MobileControlService.pasteFromClipboard(); _dialog('کلیپبۆرد', t ?? 'بەتاڵە'); }),
        ]),

        _toolSection('🌤 هەواشناسی', [
          ('🏙', 'هەولێر', () async { _dialog('هەولێر', await _getWeatherResponse('هەولێر')); }),
          ('🏔', 'سلێمانی', () async { _dialog('سلێمانی', await _getWeatherResponse('سلێمانی')); }),
          ('🌲', 'دهۆک', () async { _dialog('دهۆک', await _getWeatherResponse('دهۆک')); }),
          ('⛽', 'کرکوک', () async { _dialog('کرکوک', await _getWeatherResponse('کرکوک')); }),
        ]),

        _toolSection('🚀 ئاپەکان', [
          ('💬', 'واتساپ', () => MobileControlService.openApp('whatsapp')),
          ('✈', 'تێلیگرام', () => MobileControlService.openApp('telegram')),
          ('▶', 'یوتیوب', () => MobileControlService.openApp('youtube')),
          ('📷', 'ئینستا', () => MobileControlService.openApp('instagram')),
          ('🎵', 'تیکتۆک', () => MobileControlService.openApp('tiktok')),
          ('🌍', 'کرۆم', () => MobileControlService.openApp('chrome')),
          ('🗺', 'نەخشە', () => MobileControlService.openMaps('Kurdistan')),
          ('⚙', 'ڕێکخستن', () => MobileControlService.openApp('settings')),
        ]),

        _toolSection('🤖 BlackDeath بپرسە', [
          ('🍽', 'خواردن', () => _askBD('چێشتێکی باش پێم پێشنیار بکە')),
          ('💪', 'وەرزش', () => _askBD('ئیدمانێکم بدە')),
          ('🎮', 'یاری', () => _askBD('یارییەکی باش پێشنیار بکە')),
          ('🧠', 'فێربوون', () => _askBD('شتێکی سەرنجڕاکێشم فێر بکە')),
          ('💼', 'کار', () => _askBD('ئامۆژگاری کاری پێوەبدە')),
          ('❤', 'پەیوەندی', () => _askBD('ئامۆژگاری کارەباری دڵ پێوەبدە')),
          ('🔐', 'هاکینگ', () => _askBD('ئامۆژگاری سایبەر سیکیوریتی')),
          ('🌍', 'جیهان', () => _askBD('نوێترین هەواڵی جیهان باسم بکە')),
        ]),

      ]),
    );
  }

  Widget _toolSection(String title, List<(String, String, VoidCallback)> items) {
    return Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
      Padding(
        padding: const EdgeInsets.only(bottom: 8, top: 4),
        child: Text(title, textDirection: TextDirection.rtl,
          style: const TextStyle(color: Color(0xFFFF0000), fontSize: 13, fontWeight: FontWeight.bold)),
      ),
      GridView.count(
        crossAxisCount: 4, shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        crossAxisSpacing: 10, mainAxisSpacing: 10, childAspectRatio: 0.85,
        children: items.map((t) => GestureDetector(
          onTap: t.$3,
          child: Container(
            decoration: BoxDecoration(
              color: const Color(0xFF0A0A0A),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: const Color(0xFF2A0000)),
            ),
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              Text(t.$1, style: const TextStyle(fontSize: 24)),
              const SizedBox(height: 4),
              Text(t.$2, textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.white60, fontSize: 11)),
            ]),
          ),
        )).toList(),
      ),
      const SizedBox(height: 14),
    ]);
  }

  Future<void> _askBD(String prompt) async {
    // Call mode دەکرێتەوە و پرسیارەکە دەنێردرێت
    _toggleCallMode();
    await Future.delayed(const Duration(milliseconds: 500));
    _sendMessage(prompt);
  }

  void _dialog(String title, String content) {
    showDialog(context: context, builder: (_) => AlertDialog(
      backgroundColor: const Color(0xFF0A0A0A),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: const BorderSide(color: Color(0xFF8B0000)),
      ),
      title: Text(title, style: const TextStyle(color: Color(0xFFFF0000), fontWeight: FontWeight.bold)),
      content: Text(content, textDirection: TextDirection.rtl,
        style: const TextStyle(color: Colors.white, height: 1.6)),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context),
          child: const Text('باشە', style: TextStyle(color: Color(0xFFFF0000)))),
      ],
    ));
  }

  void _snack(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg, textDirection: TextDirection.rtl),
      backgroundColor: const Color(0xFF8B0000),
      duration: const Duration(seconds: 2),
    ));
  }
}

// ── Jarvis HUD Grid Painter ────────────────────────────────────────────────
class _JarvisGridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFFFF0000).withOpacity(0.04)
      ..strokeWidth = 0.5;

    const spacing = 40.0;
    for (double x = 0; x < size.width; x += spacing) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y < size.height; y += spacing) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }
  @override
  bool shouldRepaint(_) => false;
}
