import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class MessageBubble extends StatelessWidget {
  final String role;
  final String text;
  final bool isStreaming;

  const MessageBubble({
    super.key,
    required this.role,
    required this.text,
    this.isStreaming = false,
  });

  @override
  Widget build(BuildContext context) {
    final isUser = role == 'user';
    final isSystem = role == 'system';

    return Align(
      alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
      child: GestureDetector(
        onLongPress: () {
          Clipboard.setData(ClipboardData(text: text));
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('کۆپی کرا', textDirection: TextDirection.rtl),
              backgroundColor: Color(0xFF8B0000),
              duration: Duration(seconds: 1),
            ),
          );
        },
        child: Container(
          margin: EdgeInsets.only(
            bottom: 10,
            left: isUser ? 48 : 0,
            right: isUser ? 0 : 48,
          ),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          decoration: BoxDecoration(
            color: isUser
                ? const Color(0xFF1A0000)
                : isSystem
                    ? const Color(0xFF050505)
                    : const Color(0xFF0A0A0A),
            borderRadius: BorderRadius.only(
              topLeft: const Radius.circular(16),
              topRight: const Radius.circular(16),
              bottomLeft: Radius.circular(isUser ? 16 : 4),
              bottomRight: Radius.circular(isUser ? 4 : 16),
            ),
            border: Border.all(
              color: isUser
                  ? const Color(0xFF8B0000)
                  : isSystem
                      ? const Color(0xFF222222)
                      : const Color(0xFF2A0000),
              width: 1,
            ),
            boxShadow: isUser
                ? [const BoxShadow(color: Color(0x338B0000), blurRadius: 8)]
                : [],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              if (isSystem)
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Text('☠ ', style: TextStyle(fontSize: 12, color: Color(0xFFFF0000))),
                    const Text('BlackDeath',
                        style: TextStyle(fontSize: 11, color: Color(0xFFFF0000),
                            fontWeight: FontWeight.bold)),
                  ],
                ),
              if (!isUser && !isSystem)
                const Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text('☠ ', style: TextStyle(fontSize: 11, color: Color(0xFF8B0000))),
                    Text('BD', style: TextStyle(fontSize: 10, color: Color(0xFF8B0000))),
                  ],
                ),
              if (!isSystem) const SizedBox(height: 4),
              Row(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Flexible(
                    child: Text(
                      text,
                      textDirection: TextDirection.rtl,
                      style: TextStyle(
                        color: isSystem ? Colors.white60 : Colors.white,
                        fontSize: 15,
                        height: 1.5,
                      ),
                    ),
                  ),
                  if (isStreaming) ...[
                    const SizedBox(width: 4),
                    const _BlinkCursor(),
                  ],
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _BlinkCursor extends StatefulWidget {
  const _BlinkCursor();

  @override
  State<_BlinkCursor> createState() => _BlinkCursorState();
}

class _BlinkCursorState extends State<_BlinkCursor>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 500))
      ..repeat(reverse: true);
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _ctrl,
      builder: (_, __) => Opacity(
        opacity: _ctrl.value,
        child: Container(
          width: 2,
          height: 16,
          color: const Color(0xFFFF0000),
        ),
      ),
    );
  }
}
