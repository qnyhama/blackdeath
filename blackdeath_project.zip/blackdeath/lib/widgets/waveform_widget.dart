import 'dart:math';
import 'package:flutter/material.dart';

class WaveformWidget extends StatefulWidget {
  final bool isActive;
  final Color color;
  final int barCount;

  const WaveformWidget({
    super.key,
    required this.isActive,
    this.color = const Color(0xFFFF0000),
    this.barCount = 24,
  });

  @override
  State<WaveformWidget> createState() => _WaveformWidgetState();
}

class _WaveformWidgetState extends State<WaveformWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  final _rng = Random();
  List<double> _heights = [];

  @override
  void initState() {
    super.initState();
    _heights = List.generate(widget.barCount, (_) => 0.1);
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 100),
    )..addListener(_updateHeights);

    if (widget.isActive) _ctrl.repeat();
  }

  void _updateHeights() {
    if (!widget.isActive) {
      setState(() {
        _heights = List.generate(widget.barCount, (_) => 0.1);
      });
      return;
    }
    setState(() {
      _heights = List.generate(
        widget.barCount,
        (i) {
          final center = widget.barCount / 2;
          final dist = (i - center).abs() / center;
          final base = (1 - dist) * 0.8;
          return base * (0.2 + _rng.nextDouble() * 0.8);
        },
      );
    });
  }

  @override
  void didUpdateWidget(WaveformWidget oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.isActive && !_ctrl.isAnimating) {
      _ctrl.repeat();
    } else if (!widget.isActive && _ctrl.isAnimating) {
      _ctrl.stop();
      _updateHeights();
    }
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 60,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: List.generate(widget.barCount, (i) {
          return AnimatedContainer(
            duration: const Duration(milliseconds: 80),
            width: 3,
            height: max(4, _heights[i] * 50),
            margin: const EdgeInsets.symmetric(horizontal: 2),
            decoration: BoxDecoration(
              color: widget.color.withOpacity(0.4 + _heights[i] * 0.6),
              borderRadius: BorderRadius.circular(2),
            ),
          );
        }),
      ),
    );
  }
}
