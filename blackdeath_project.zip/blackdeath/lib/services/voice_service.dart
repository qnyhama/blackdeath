import 'package:speech_to_text/speech_to_text.dart';
import 'package:flutter_tts/flutter_tts.dart';

class VoiceService {
  static final SpeechToText _stt = SpeechToText();
  static final FlutterTts _tts = FlutterTts();
  static bool _sttReady = false;
  static bool _isSpeaking = false;
  static bool _isListening = false;

  // ── دەنگی ترسناکی BlackDeath ──────────────────────────────────────────────
  // پێچی نزم = دەنگی گوردانە و ترسناک (0.1 = زۆر نزم، 1.0 = ئاسایی)
  static const double _pitch = 0.45;
  // خێرایی هێواش = دەنگی قور و سووک (0.3 = زۆر هێواش)
  static const double _rate = 0.38;
  // دەنگی بەرز
  static const double _volume = 1.0;

  static Future<void> init() async {
    _sttReady = await _stt.initialize(
      onError: (e) => print('STT Error: $e'),
      onStatus: (s) => print('STT Status: $s'),
    );

    // دەنگی ترسناک — Arabic pitch + نزم + هێواش
    await _tts.setLanguage('ar-SA');
    await _tts.setPitch(_pitch);
    await _tts.setSpeechRate(_rate);
    await _tts.setVolume(_volume);

    _tts.setCompletionHandler(() {
      _isSpeaking = false;
    });
  }

  static bool get isReady => _sttReady;
  static bool get isSpeaking => _isSpeaking;
  static bool get isListening => _isListening;

  static Future<void> startListening({
    required Function(String text) onResult,
    required Function() onDone,
  }) async {
    if (!_sttReady || _isListening) return;

    _isListening = true;
    await _stt.listen(
      onResult: (result) {
        if (result.finalResult) {
          _isListening = false;
          onResult(result.recognizedWords);
          onDone();
        }
      },
      localeId: 'ar_IQ',
      listenFor: const Duration(seconds: 30),
      pauseFor: const Duration(seconds: 3),
      cancelOnError: true,
    );
  }

  static Future<void> stopListening() async {
    _isListening = false;
    await _stt.stop();
  }

  /// دەنگی ترسناکی BlackDeath — کورت و قور و سووک
  static Future<void> speak(String text) async {
    if (_isSpeaking) await stop();
    _isSpeaking = true;

    // پاکردنەوەی markdown
    String clean = text
        .replaceAll(RegExp(r'\*+'), '')
        .replaceAll(RegExp(r'#+\s?'), '')
        .replaceAll(RegExp(r'`+'), '')
        .replaceAll(RegExp(r'😄|😂|🔴|☠|😎|😅|❤️|✅|⚡|📱|🔋|🌐|💪|🎮|🎵|✈️|💼|🧠|🍽️|🌤️|⚙️'), '');

    // کورتکردنەوە — تەنها ئێستادا 2 ڕستە بڵێ (دەنگی ترسناک = کورت باشترە)
    final sentences = clean.split(RegExp(r'[.،؟!]\s*'));
    final toSpeak = sentences.take(3).join('... ');

    // مەودای ئارامی پێش قسەکردن — وەکو دەستیاری تاریک
    await Future.delayed(const Duration(milliseconds: 300));

    await _tts.speak(toSpeak.trim());
  }

  /// قسەکردنی تەواو — بەبێ کورتکردنەوە
  static Future<void> speakFull(String text) async {
    if (_isSpeaking) await stop();
    _isSpeaking = true;

    final clean = text
        .replaceAll(RegExp(r'\*+'), '')
        .replaceAll(RegExp(r'#+\s?'), '')
        .replaceAll(RegExp(r'`+'), '')
        .replaceAll(RegExp(r'[^\u0000-\u06FF\s.,،؟!]'), '');

    await _tts.speak(clean.trim());
  }

  static Future<void> stop() async {
    _isSpeaking = false;
    await _tts.stop();
  }

  static Future<void> pause() async => await _tts.pause();

  /// گۆڕینی دەنگ — بۆ ئەگەر بەکارهێنەر دەیەوێت گۆڕبێت
  static Future<void> setVoiceStyle({
    double pitch = 0.45,
    double rate = 0.38,
  }) async {
    await _tts.setPitch(pitch);
    await _tts.setSpeechRate(rate);
  }

  static List<dynamic> get availableLocales => _stt.locales();
}
