import 'package:shared_preferences/shared_preferences.dart';

class StorageService {
  static late SharedPreferences _prefs;

  static Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
  }

  static Future<void> saveApiKey(String key) async {
    await _prefs.setString('gemini_api_key', key);
  }

  static Future<String?> getApiKey() async {
    return _prefs.getString('gemini_api_key');
  }

  static Future<void> saveMemory(String key, String value) async {
    final memory = getMemory();
    memory[key] = value;
    await _prefs.setString('bd_memory', _encodeMap(memory));
  }

  static Map<String, String> getMemory() {
    final raw = _prefs.getString('bd_memory');
    if (raw == null) return {};
    return Map<String, String>.from(_decodeMap(raw));
  }

  static Future<void> saveChatHistory(List<Map<String, String>> history) async {
    final encoded = history.map((m) => '${m['role']}|||${m['text']}').join('~~~');
    await _prefs.setString('chat_history', encoded);
  }

  static List<Map<String, String>> getChatHistory() {
    final raw = _prefs.getString('chat_history');
    if (raw == null || raw.isEmpty) return [];
    return raw.split('~~~').map((item) {
      final parts = item.split('|||');
      if (parts.length < 2) return <String, String>{};
      return {'role': parts[0], 'text': parts[1]};
    }).where((m) => m.isNotEmpty).toList();
  }

  static String _encodeMap(Map<String, String> map) {
    return map.entries.map((e) => '${e.key}::${e.value}').join('||');
  }

  static Map<String, dynamic> _decodeMap(String encoded) {
    if (encoded.isEmpty) return {};
    final map = <String, dynamic>{};
    for (final pair in encoded.split('||')) {
      final idx = pair.indexOf('::');
      if (idx > 0) {
        map[pair.substring(0, idx)] = pair.substring(idx + 2);
      }
    }
    return map;
  }

  static Future<void> setOnboarded() async {
    await _prefs.setBool('onboarded', true);
  }

  static bool isOnboarded() => _prefs.getBool('onboarded') ?? false;
}
