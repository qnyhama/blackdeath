import 'package:url_launcher/url_launcher.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:battery_plus/battery_plus.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

class MobileControlService {
  static final _battery = Battery();
  static final _connectivity = Connectivity();
  static final _deviceInfo = DeviceInfoPlugin();
  static final _notifications = FlutterLocalNotificationsPlugin();

  static Future<void> init() async {
    // Init notifications
    const androidSettings = AndroidInitializationSettings('@mipmap/ic_launcher');
    const iosSettings = DarwinInitializationSettings(
      requestAlertPermission: true,
      requestBadgePermission: true,
      requestSoundPermission: true,
    );
    await _notifications.initialize(
      const InitializationSettings(android: androidSettings, iOS: iosSettings),
    );
  }

  // ── Battery ──────────────────────────────────────────────────────────────
  static Future<Map<String, dynamic>> getBatteryInfo() async {
    final level = await _battery.batteryLevel;
    final state = await _battery.batteryState;
    return {
      'level': level,
      'state': state.name,
      'isCharging': state == BatteryState.charging,
    };
  }

  // ── Network ──────────────────────────────────────────────────────────────
  static Future<Map<String, dynamic>> getNetworkInfo() async {
    final result = await _connectivity.checkConnectivity();
    return {
      'connected': result != ConnectivityResult.none,
      'type': result.name,
      'isWifi': result == ConnectivityResult.wifi,
      'isMobile': result == ConnectivityResult.mobile,
    };
  }

  // ── Device Info ──────────────────────────────────────────────────────────
  static Future<Map<String, dynamic>> getDeviceInfo() async {
    try {
      final info = await _deviceInfo.androidInfo;
      return {
        'brand': info.brand,
        'model': info.model,
        'version': info.version.release,
        'sdk': info.version.sdkInt,
      };
    } catch (_) {
      try {
        final info = await _deviceInfo.iosInfo;
        return {
          'brand': 'Apple',
          'model': info.model,
          'version': info.systemVersion,
        };
      } catch (_) {
        return {};
      }
    }
  }

  // ── App Launcher ─────────────────────────────────────────────────────────
  static Future<bool> openApp(String appName) async {
    final Map<String, String> appSchemes = {
      'whatsapp': 'whatsapp://',
      'telegram': 'tg://',
      'youtube': 'youtube://',
      'instagram': 'instagram://',
      'twitter': 'twitter://',
      'x': 'twitter://',
      'tiktok': 'tiktok://',
      'chrome': 'googlechrome://',
      'maps': 'comgooglemaps://',
      'camera': 'camera://',
      'settings': 'app-settings:',
    };

    final scheme = appSchemes[appName.toLowerCase()];
    if (scheme != null) {
      final uri = Uri.parse(scheme);
      if (await canLaunchUrl(uri)) {
        return await launchUrl(uri);
      }
    }
    return false;
  }

  // ── URL / Web ─────────────────────────────────────────────────────────────
  static Future<bool> openUrl(String url) async {
    if (!url.startsWith('http')) url = 'https://$url';
    final uri = Uri.parse(url);
    return await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  // ── Phone Call ────────────────────────────────────────────────────────────
  static Future<bool> makeCall(String number) async {
    final uri = Uri.parse('tel:$number');
    return await launchUrl(uri);
  }

  // ── SMS ───────────────────────────────────────────────────────────────────
  static Future<bool> sendSms(String number, String message) async {
    final uri = Uri.parse('sms:$number?body=${Uri.encodeComponent(message)}');
    return await launchUrl(uri);
  }

  // ── WhatsApp ──────────────────────────────────────────────────────────────
  static Future<bool> openWhatsApp(String number, String message) async {
    final uri = Uri.parse(
        'https://wa.me/$number?text=${Uri.encodeComponent(message)}');
    return await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  // ── Permissions ───────────────────────────────────────────────────────────
  static Future<Map<String, bool>> checkPermissions() async {
    return {
      'microphone': await Permission.microphone.isGranted,
      'camera': await Permission.camera.isGranted,
      'storage': await Permission.storage.isGranted,
      'contacts': await Permission.contacts.isGranted,
      'phone': await Permission.phone.isGranted,
      'notifications': await Permission.notification.isGranted,
    };
  }

  static Future<void> requestAllPermissions() async {
    await [
      Permission.microphone,
      Permission.camera,
      Permission.storage,
      Permission.contacts,
      Permission.phone,
      Permission.notification,
    ].request();
  }

  // ── Notifications ─────────────────────────────────────────────────────────
  static Future<void> showNotification({
    required String title,
    required String body,
    int id = 0,
  }) async {
    const androidDetails = AndroidNotificationDetails(
      'blackdeath_channel',
      'BlackDeath',
      channelDescription: 'BlackDeath AI notifications',
      importance: Importance.high,
      priority: Priority.high,
      icon: '@mipmap/ic_launcher',
    );
    const iosDetails = DarwinNotificationDetails();
    await _notifications.show(
      id,
      title,
      body,
      const NotificationDetails(android: androidDetails, iOS: iosDetails),
    );
  }

  // ── Alarm / Reminder ──────────────────────────────────────────────────────
  static Future<void> scheduleReminder({
    required String title,
    required String body,
    required DateTime dateTime,
    int id = 1,
  }) async {
    // Note: requires timezone package setup
    await showNotification(title: title, body: body, id: id);
  }

  // ── System Status (for AI context) ───────────────────────────────────────
  static Future<String> getFullSystemStatus() async {
    final battery = await getBatteryInfo();
    final network = await getNetworkInfo();
    final device = await getDeviceInfo();

    return '''
📱 دەستگا: ${device['brand']} ${device['model']} (Android/iOS ${device['version']})
🔋 بەتری: ${battery['level']}% ${battery['isCharging'] == true ? '(شارژکراو)' : ''}
🌐 نەت: ${network['connected'] == true ? (network['isWifi'] == true ? 'WiFi' : 'داتای مۆبایل') : 'پەیوەندی نییە'}
''';
  }
}
