import 'dart:convert';
import 'package:http/http.dart' as http;

/// OSINT & Intelligence Service
/// بەکاردەهێنرێت بۆ گەڕان لە وێب، ئاگادارکردنەوەی زانیاری
class OsintService {
  // DuckDuckGo Instant Answer API (بەخۆڕایی)
  static const String _ddgApi = 'https://api.duckduckgo.com/';

  // Quick news/info search
  static Future<String> quickSearch(String query) async {
    try {
      final uri = Uri.parse(_ddgApi).replace(queryParameters: {
        'q': query,
        'format': 'json',
        'no_html': '1',
        'skip_disambig': '1',
      });

      final response = await http.get(uri).timeout(const Duration(seconds: 8));
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final abstract = data['AbstractText'] as String? ?? '';
        final answer = data['Answer'] as String? ?? '';
        return [answer, abstract].where((s) => s.isNotEmpty).join('\n').take(500);
      }
    } catch (_) {}
    return '';
  }

  // Search for a person/username (OSINT)
  static Future<Map<String, dynamic>> searchPerson(String name) async {
    final results = <String, dynamic>{};
    try {
      final searchResult = await quickSearch('$name site:linkedin.com OR site:twitter.com OR site:instagram.com');
      results['web'] = searchResult;
    } catch (_) {}
    return results;
  }

  // IP Lookup
  static Future<Map<String, dynamic>> ipLookup(String ip) async {
    try {
      final response = await http
          .get(Uri.parse('https://ipapi.co/$ip/json/'))
          .timeout(const Duration(seconds: 8));
      if (response.statusCode == 200) {
        return jsonDecode(response.body) as Map<String, dynamic>;
      }
    } catch (_) {}
    return {};
  }

  // Get current news headlines
  static Future<List<String>> getNewsHeadlines() async {
    final headlines = <String>[];
    try {
      // Using RSS feed via public API
      final response = await http
          .get(Uri.parse('https://gnews.io/api/v4/top-headlines?lang=ar&max=5&apikey=free'))
          .timeout(const Duration(seconds: 8));
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final articles = data['articles'] as List? ?? [];
        for (final a in articles.take(5)) {
          headlines.add(a['title'] as String? ?? '');
        }
      }
    } catch (_) {
      // Fallback: return example
      headlines.add('خزمەتگوزارییەکانی نیوز ئێستا بەردەست نین');
    }
    return headlines.where((h) => h.isNotEmpty).toList();
  }

  // Check if a website is up
  static Future<bool> checkSiteStatus(String url) async {
    try {
      final response = await http
          .head(Uri.parse(url))
          .timeout(const Duration(seconds: 5));
      return response.statusCode < 400;
    } catch (_) {
      return false;
    }
  }

  // Get weather data
  static Future<Map<String, dynamic>> getWeather(String city) async {
    try {
      // Open-Meteo (بەخۆڕایی - پێویستی API Key نییە)
      final geoResponse = await http.get(
        Uri.parse('https://geocoding-api.open-meteo.com/v1/search?name=$city&count=1&language=en&format=json'),
      ).timeout(const Duration(seconds: 5));

      if (geoResponse.statusCode == 200) {
        final geo = jsonDecode(geoResponse.body);
        final results = geo['results'] as List?;
        if (results != null && results.isNotEmpty) {
          final lat = results[0]['latitude'];
          final lon = results[0]['longitude'];

          final weatherResponse = await http.get(
            Uri.parse('https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,relative_humidity_2m,wind_speed_10m,weather_code&timezone=auto'),
          ).timeout(const Duration(seconds: 5));

          if (weatherResponse.statusCode == 200) {
            return jsonDecode(weatherResponse.body) as Map<String, dynamic>;
          }
        }
      }
    } catch (_) {}
    return {};
  }
}

extension StringTake on String {
  String take(int n) => length <= n ? this : substring(0, n);
}
