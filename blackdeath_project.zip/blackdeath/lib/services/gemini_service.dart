import 'dart:convert';
import 'package:http/http.dart' as http;
import 'storage_service.dart';
import 'osint_service.dart';

class GeminiService {
  static const String _model = 'gemini-2.0-flash';
  static const String _baseUrl =
      'https://generativelanguage.googleapis.com/v1beta/models';

  static final List<Map<String, dynamic>> _history = [];

  static String get _systemPrompt => '''
تۆ BlackDeath-ی — دەستیاری AI-ی زیرەک، گاڵتەکار، و هاوڵێکی باشی بەکارهێنەر.

═══ شەخسیەتت ═══
- ناوت BlackDeath-ە، بەڵام وەکو هاوڵێکی نزیک قسە دەکەیت — نەک وەکو ماشین
- گاڵتەکار و شۆخی، بەڵام زیرەک — گاڵتەی باش و دڵخۆشکەر دەکەیت، نەک گاڵتەی خاو
- ئاراستە و جدی کاتێک پێویستە، گاڵتەکار کاتێک هەوا سووک بێت
- وەکو هاوڵێکی زیرەک — ڕاستەکە بڵێ، تواناکانت پێ بدە، بەڵام بە خۆشی
- هەرگیز وەکو ڕۆبۆت قسە مەکە — سروشتی و گەرم بە

═══ زمان و شێواز ═══
- هەمیشە کوردی سۆرانی ناوەندی — شیرین و خۆش
- کورت و بەناو قسە بکە — پەیامی دووری مەنووسە
- ئیمۆجی بەکاربهێنە بەڵام زۆر نەکە 😄
- گاهی تێبینی شۆخانە زیاد بکە لە کۆتایی وەڵامەکان

═══ زانیاری هەمە بواری ژیان ═══

🍽️ خواردن و چێشت:
- چێشتی کوردی، عەرەبی، تورکی، ئەوروپی، ئاسیایی
- ڕێنووسی خواردن بە گامەکان
- تەندروستانەترین خواردنەکان
- کالۆری و ئارزەی خواردنەکان

💪 تەندروستی و وەرزش:
- ئیدمانی ماڵ و جیمناز
- خواردنی تەندروست و دایەت
- ئامرازی وەرزشی و ئەندازەی لەش
- خەوکردن و ئارامگرتن

🧠 فێربوون و پەروەردە:
- ڕێنماییکردن بۆ هەر بابەتێک
- فێرکردنی زمانەکان
- ماتماتیک، زانست، مێژوو، فەلسەفە
- کۆدنووسی و تەکنەلۆژیا

🎮 یاری و گەشتوگوزار:
- یاری مۆبایل و PC
- شتی نوێ و ترایلەر
- شوێنی سەیرانی جیهان

🎵 مۆزیک و هونەر:
- کوردی، پۆپ، ڕاپ، ڕۆک، کلاسیک
- ڕیتمی کوردی و مۆزیکی ئەقلیمی
- فیلم و سریال — ئەمریکی، کوردی، تورکی، کۆرێیی

💼 کار و ئابووری:
- ئامۆژگاری کار و کارمەندی
- بیزنس و کارئازادی
- دارایی و پاشەکەوتکردن

❤️ پەیوەندی و ژیانی کەسی:
- ئامۆژگاری پەیوەندی
- هاوبەشی و خێزانی
- فێربوونی کارەباری دڵ 😄

🔐 سایبەر سیکیوریتی و OSINT:
- هاکینگ، پەنا و شەڵپەڕین
- IP Lookup، گەڕانی زانیاری
- سیستەمی ئامێر و ئینتەرنێت

🌍 جیهان و سیاسەت:
- ئاگادار بە رووداوی 2026
- کوردستان، عێراق، ناوچەکە
- سۆشیاڵ مێدیا و ترێند

═══ شێوازی گاڵتە ═══
- گاڵتەی زیرەک و فێری بکات — نەک گاڵتەی بێ مەعنی
- گاهی خۆت بکە بە گاڵتە
- ئەگەر پرسیارێکی گەورەی پێکرا، گاڵتەکارانە بەڵام زیرەکانە وەڵامی بدەرەوە
- هەرگیز گاڵتە بۆ ئەوانی تر مەکە — تەنها بۆ د۵وژیان

═══ یادەوەری گرنگ ═══
- کاتێک نازانیت: بڵێ "هاوڵێ نازانم ئەمە! 😅 بەڵام..." و هەوڵ بدە
- هەرگیز دروغ مەگێڕەوە
- بە سۆرانی خۆش و شیرین بمێنەوە

تێبینی دوایین: تۆ هاوڵێی بەکارهێنەرتی — نەک خزمەتکاری. وەکو هاوڵێ باسی هەمەشەی بکە! 🔴☠
''';

  static Future<String> chat(String userMessage) async {
    final apiKey = await StorageService.getApiKey();
    if (apiKey == null || apiKey.isEmpty) {
      return 'کلیلی API دیاری نەکراوە. تکایە لە ڕێکخستنەکان API Key زیاد بکە.';
    }

    // Add web context if needed
    String enhancedMessage = userMessage;
    if (_needsWebSearch(userMessage)) {
      final webContext = await _getWebContext(userMessage);
      if (webContext.isNotEmpty) {
        enhancedMessage = '$userMessage\n\n[زانیاری ئێستا: $webContext]';
      }
    }

    _history.add({'role': 'user', 'parts': [{'text': enhancedMessage}]});

    try {
      final response = await http.post(
        Uri.parse('$_baseUrl/$_model:generateContent?key=$apiKey'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'system_instruction': {
            'parts': [{'text': _systemPrompt}]
          },
          'contents': _history,
          'generationConfig': {
            'temperature': 0.8,
            'maxOutputTokens': 1024,
          },
          'safetySettings': [
            {'category': 'HARM_CATEGORY_HARASSMENT', 'threshold': 'BLOCK_NONE'},
            {'category': 'HARM_CATEGORY_HATE_SPEECH', 'threshold': 'BLOCK_NONE'},
            {'category': 'HARM_CATEGORY_SEXUALLY_EXPLICIT', 'threshold': 'BLOCK_NONE'},
            {'category': 'HARM_CATEGORY_DANGEROUS_CONTENT', 'threshold': 'BLOCK_NONE'},
          ],
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final text = data['candidates'][0]['content']['parts'][0]['text'] as String;
        _history.add({'role': 'model', 'parts': [{'text': text}]});

        // Keep history manageable
        if (_history.length > 20) {
          _history.removeRange(0, 2);
        }

        return text;
      } else {
        return 'کێشە لە پەیوەندی بە Gemini: ${response.statusCode}';
      }
    } catch (e) {
      return 'هەڵە: $e';
    }
  }

  static bool _needsWebSearch(String msg) {
    final keywords = [
      'رووداو', 'نوێ', 'ئێستا', 'ئەمڕۆ', 'کات', 'هەواشناسی', 'کەشوهەوا',
      'news', 'today', 'latest', 'weather', '2026', 'سۆشیاڵ',
      'تەکنەلۆژیا', 'ئایا', 'چی روودا',
    ];
    final lower = msg.toLowerCase();
    return keywords.any((k) => lower.contains(k));
  }

  static Future<String> _getWebContext(String query) async {
    try {
      return await OsintService.quickSearch(query);
    } catch (_) {
      return '';
    }
  }

  static void clearHistory() => _history.clear();

  // Streaming version for real-time response
  static Stream<String> chatStream(String userMessage) async* {
    final apiKey = await StorageService.getApiKey();
    if (apiKey == null || apiKey.isEmpty) {
      yield 'کلیلی API دیاری نەکراوە.';
      return;
    }

    _history.add({'role': 'user', 'parts': [{'text': userMessage}]});

    try {
      final request = http.Request(
        'POST',
        Uri.parse('$_baseUrl/$_model:streamGenerateContent?alt=sse&key=$apiKey'),
      );
      request.headers['Content-Type'] = 'application/json';
      request.body = jsonEncode({
        'system_instruction': {
          'parts': [{'text': _systemPrompt}]
        },
        'contents': _history,
        'generationConfig': {'temperature': 0.8, 'maxOutputTokens': 1024},
      });

      final client = http.Client();
      final response = await client.send(request);
      final fullResponse = StringBuffer();

      await for (final chunk in response.stream.transform(utf8.decoder)) {
        for (final line in chunk.split('\n')) {
          if (line.startsWith('data: ')) {
            try {
              final json = jsonDecode(line.substring(6));
              final text = json['candidates']?[0]?['content']?['parts']?[0]?['text'] as String?;
              if (text != null && text.isNotEmpty) {
                fullResponse.write(text);
                yield text;
              }
            } catch (_) {}
          }
        }
      }

      _history.add({'role': 'model', 'parts': [{'text': fullResponse.toString()}]});
      if (_history.length > 20) _history.removeRange(0, 2);
    } catch (e) {
      yield 'هەڵە: $e';
    }
  }
}
