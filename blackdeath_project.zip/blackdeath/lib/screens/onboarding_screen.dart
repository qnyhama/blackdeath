import 'package:flutter/material.dart';
import '../services/storage_service.dart';
import '../services/mobile_control_service.dart';
import 'home_screen.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final _apiController = TextEditingController();
  bool _loading = false;
  String _error = '';
  bool _obscure = true;
  int _step = 0; // 0=welcome, 1=permissions, 2=api

  @override
  void dispose() {
    _apiController.dispose();
    super.dispose();
  }

  Future<void> _requestPermissions() async {
    await MobileControlService.requestAllPermissions();
    setState(() => _step = 2);
  }

  Future<void> _saveAndContinue() async {
    final key = _apiController.text.trim();
    if (key.isEmpty) {
      setState(() => _error = 'تکایە Gemini API Key بنووسە');
      return;
    }
    setState(() {_loading = true; _error = '';});

    await StorageService.saveApiKey(key);
    await StorageService.setOnboarded();

    if (!mounted) return;
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (_) => const HomeScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: AnimatedSwitcher(
            duration: const Duration(milliseconds: 400),
            child: _step == 0
                ? _buildWelcome()
                : _step == 1
                    ? _buildPermissions()
                    : _buildApiSetup(),
          ),
        ),
      ),
    );
  }

  Widget _buildWelcome() {
    return Column(
      key: const ValueKey(0),
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        const Text('☠', style: TextStyle(fontSize: 80, color: Color(0xFFFF0000))),
        const SizedBox(height: 24),
        const Text(
          'BlackDeath',
          style: TextStyle(
            fontSize: 36, fontWeight: FontWeight.bold,
            color: Color(0xFFFF0000),
            shadows: [Shadow(color: Color(0xFFFF0000), blurRadius: 20)],
          ),
        ),
        const SizedBox(height: 12),
        const Text(
          'دەستیاری AI-ی تەواوی تۆ\nبە کوردی سۆرانی',
          textAlign: TextAlign.center,
          textDirection: TextDirection.rtl,
          style: TextStyle(fontSize: 18, color: Color(0xFF888888), height: 1.6),
        ),
        const SizedBox(height: 48),
        _redButton('دەست بکە', () => setState(() => _step = 1)),
      ],
    );
  }

  Widget _buildPermissions() {
    return Column(
      key: const ValueKey(1),
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        const Text(
          'مۆڵەتەکان',
          textDirection: TextDirection.rtl,
          style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold, color: Colors.white),
        ),
        const SizedBox(height: 16),
        const Text(
          'BlackDeath پێویستی بە مۆڵەتەکانی خوارەوەیە بۆ کارکردنی تەواو:',
          textDirection: TextDirection.rtl,
          style: TextStyle(color: Color(0xFF888888), fontSize: 15, height: 1.6),
        ),
        const SizedBox(height: 32),
        ...[
          ('🎤', 'مایکرۆفۆن', 'بۆ قسەکردن و فەرمان'),
          ('📷', 'کامێرا', 'بۆ بینین و شیکردنەوە'),
          ('📁', 'فایل', 'بۆ خوێندنەوە و دەستکاریکردن'),
          ('📞', 'تەلەفۆن', 'بۆ بەرپرسایەتی تەلەفۆن'),
          ('🔔', 'ئاگادارکردنەوە', 'بۆ یادەوەری و ئەلارم'),
        ].map((item) => _permissionTile(item.$1, item.$2, item.$3)),
        const SizedBox(height: 40),
        _redButton('مۆڵەت بدە و بەردەوام بە', _requestPermissions),
      ],
    );
  }

  Widget _buildApiSetup() {
    return Column(
      key: const ValueKey(2),
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        const Text(
          'Gemini API Key',
          style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold, color: Colors.white),
        ),
        const SizedBox(height: 12),
        const Text(
          'بۆ بەکارهێنانی BlackDeath پێویستت بە کلیلی Gemini API-ە.\nبەخۆڕایی دەست پێبکە لە: aistudio.google.com',
          textDirection: TextDirection.rtl,
          style: TextStyle(color: Color(0xFF888888), fontSize: 14, height: 1.6),
        ),
        const SizedBox(height: 32),
        TextField(
          controller: _apiController,
          obscureText: _obscure,
          style: const TextStyle(color: Colors.white, fontFamily: 'monospace'),
          decoration: InputDecoration(
            hintText: 'AIza...',
            hintStyle: const TextStyle(color: Color(0xFF444444)),
            filled: true,
            fillColor: const Color(0xFF0A0A0A),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: const BorderSide(color: Color(0xFF8B0000)),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: const BorderSide(color: Color(0xFFFF0000), width: 2),
            ),
            suffixIcon: IconButton(
              icon: Icon(_obscure ? Icons.visibility : Icons.visibility_off,
                  color: const Color(0xFF666666)),
              onPressed: () => setState(() => _obscure = !_obscure),
            ),
          ),
        ),
        if (_error.isNotEmpty) ...[
          const SizedBox(height: 8),
          Text(_error, style: const TextStyle(color: Color(0xFFFF0000), fontSize: 13)),
        ],
        const SizedBox(height: 24),
        _redButton(
          _loading ? 'چاوەڕوان بە...' : 'داخڵ بە',
          _loading ? null : _saveAndContinue,
        ),
      ],
    );
  }

  Widget _permissionTile(String emoji, String name, String desc) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        textDirection: TextDirection.rtl,
        children: [
          Text(emoji, style: const TextStyle(fontSize: 22)),
          const SizedBox(width: 12),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(name, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
              Text(desc, style: const TextStyle(color: Color(0xFF666666), fontSize: 12)),
            ],
          ),
        ],
      ),
    );
  }

  Widget _redButton(String label, VoidCallback? onTap) {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton(
        onPressed: onTap,
        style: ElevatedButton.styleFrom(
          backgroundColor: const Color(0xFFCC0000),
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(vertical: 16),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          elevation: 8,
          shadowColor: const Color(0xFFFF0000),
        ),
        child: Text(label, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
      ),
    );
  }
}
