import 'package:flutter/material.dart';
import '../services/osint_service.dart';

class OsintScreen extends StatefulWidget {
  const OsintScreen({super.key});

  @override
  State<OsintScreen> createState() => _OsintScreenState();
}

class _OsintScreenState extends State<OsintScreen> {
  final _searchCtrl = TextEditingController();
  final _ipCtrl = TextEditingController();
  String _searchResult = '';
  String _ipResult = '';
  List<String> _news = [];
  bool _loadingSearch = false;
  bool _loadingIp = false;
  bool _loadingNews = false;
  int _tab = 0; // 0=search, 1=ip, 2=news

  @override
  void dispose() {
    _searchCtrl.dispose();
    _ipCtrl.dispose();
    super.dispose();
  }

  Future<void> _doSearch() async {
    if (_searchCtrl.text.isEmpty) return;
    setState(() {_loadingSearch = true; _searchResult = '';});
    final result = await OsintService.quickSearch(_searchCtrl.text);
    setState(() {
      _loadingSearch = false;
      _searchResult = result.isEmpty
          ? '⚠️ هیچ ئەنجامێک نەدۆزرایەوە'
          : result;
    });
  }

  Future<void> _doIpLookup() async {
    if (_ipCtrl.text.isEmpty) return;
    setState(() {_loadingIp = true; _ipResult = '';});
    final result = await OsintService.ipLookup(_ipCtrl.text.trim());
    if (result.isEmpty) {
      setState(() {_loadingIp = false; _ipResult = '⚠️ IP نەدۆزرایەوە';});
      return;
    }
    final sb = StringBuffer();
    sb.writeln('🌐 IP: ${result['ip'] ?? _ipCtrl.text}');
    sb.writeln('🗺️ وڵات: ${result['country_name'] ?? '-'}');
    sb.writeln('🏙️ شار: ${result['city'] ?? '-'}');
    sb.writeln('📡 ISP: ${result['org'] ?? '-'}');
    sb.writeln('🔢 ASN: ${result['asn'] ?? '-'}');
    sb.writeln('📍 ئاستەنگا: ${result['latitude']}, ${result['longitude']}');
    sb.writeln('⏰ کاتژمێری ناوچە: ${result['timezone'] ?? '-'}');
    setState(() {_loadingIp = false; _ipResult = sb.toString();});
  }

  Future<void> _loadNews() async {
    setState(() {_loadingNews = true; _news = [];});
    final result = await OsintService.getNewsHeadlines();
    setState(() {_loadingNews = false; _news = result;});
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // Sub tabs
        Container(
          color: const Color(0xFF050505),
          child: Row(
            children: [
              _subTab(0, '🔍 گەڕان'),
              _subTab(1, '🌐 IP'),
              _subTab(2, '📰 هەواڵ'),
            ],
          ),
        ),

        Expanded(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: _tab == 0
                ? _buildSearch()
                : _tab == 1
                    ? _buildIpLookup()
                    : _buildNews(),
          ),
        ),
      ],
    );
  }

  Widget _subTab(int idx, String label) {
    final sel = _tab == idx;
    return Expanded(
      child: GestureDetector(
        onTap: () {
          setState(() => _tab = idx);
          if (idx == 2 && _news.isEmpty) _loadNews();
        },
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 10),
          decoration: BoxDecoration(
            border: Border(
              bottom: BorderSide(
                color: sel ? const Color(0xFFFF0000) : Colors.transparent,
                width: 2,
              ),
            ),
          ),
          child: Text(
            label,
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 12,
              color: sel ? const Color(0xFFFF0000) : const Color(0xFF555555),
              fontWeight: sel ? FontWeight.bold : FontWeight.normal,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildSearch() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        const Text('گەڕانی OSINT',
            textDirection: TextDirection.rtl,
            style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        const Text('گەڕان لە وێب بۆ زانیاری و سایبەر ئینتیلیجنس',
            textDirection: TextDirection.rtl,
            style: TextStyle(color: Colors.white54, fontSize: 13)),
        const SizedBox(height: 16),
        _inputField(_searchCtrl, 'ناو، ئیمەیڵ، دۆمەین...', TextDirection.rtl),
        const SizedBox(height: 12),
        _redBtn('🔍 بگەڕێ', _loadingSearch ? null : _doSearch),
        if (_loadingSearch) ...[
          const SizedBox(height: 16),
          const Center(child: CircularProgressIndicator(color: Color(0xFFFF0000))),
        ],
        if (_searchResult.isNotEmpty) ...[
          const SizedBox(height: 16),
          _resultCard(_searchResult),
        ],
      ],
    );
  }

  Widget _buildIpLookup() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        const Text('IP Lookup',
            style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        const Text('زانیاری IP ئادرێسەکە بزانە',
            textDirection: TextDirection.rtl,
            style: TextStyle(color: Colors.white54, fontSize: 13)),
        const SizedBox(height: 16),
        _inputField(_ipCtrl, '192.168.1.1 یان 8.8.8.8', TextDirection.ltr),
        const SizedBox(height: 12),
        _redBtn('🔎 چەک بکە', _loadingIp ? null : _doIpLookup),
        if (_loadingIp) ...[
          const SizedBox(height: 16),
          const Center(child: CircularProgressIndicator(color: Color(0xFFFF0000))),
        ],
        if (_ipResult.isNotEmpty) ...[
          const SizedBox(height: 16),
          _resultCard(_ipResult),
        ],
      ],
    );
  }

  Widget _buildNews() {
    if (_loadingNews) {
      return const Center(
        child: Padding(
          padding: EdgeInsets.all(40),
          child: CircularProgressIndicator(color: Color(0xFFFF0000)),
        ),
      );
    }
    if (_news.isEmpty) {
      return Column(
        children: [
          const SizedBox(height: 40),
          const Text('📰', style: TextStyle(fontSize: 48)),
          const SizedBox(height: 16),
          const Text('هەواڵ بار بکە',
              style: TextStyle(color: Colors.white54)),
          const SizedBox(height: 24),
          _redBtn('📡 هەواڵ بار بکە', _loadNews),
        ],
      );
    }
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            TextButton(
              onPressed: _loadNews,
              child: const Text('نوێکردنەوە', style: TextStyle(color: Color(0xFFFF0000))),
            ),
            const Text('هەواڵی ئێستا',
                textDirection: TextDirection.rtl,
                style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
          ],
        ),
        ..._news.map((h) => Container(
          margin: const EdgeInsets.only(bottom: 10),
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: const Color(0xFF0A0A0A),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: const Color(0xFF2A0000)),
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            textDirection: TextDirection.rtl,
            children: [
              const Text('📰 ', style: TextStyle(fontSize: 16)),
              Expanded(
                child: Text(h,
                    textDirection: TextDirection.rtl,
                    style: const TextStyle(color: Colors.white, fontSize: 14, height: 1.5)),
              ),
            ],
          ),
        )),
      ],
    );
  }

  Widget _inputField(TextEditingController ctrl, String hint, TextDirection dir) {
    return TextField(
      controller: ctrl,
      textDirection: dir,
      style: const TextStyle(color: Colors.white),
      decoration: InputDecoration(
        hintText: hint,
        hintTextDirection: dir,
        hintStyle: const TextStyle(color: Color(0xFF444444)),
        filled: true,
        fillColor: const Color(0xFF0A0A0A),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: Color(0xFF2A0000)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: Color(0xFFFF0000), width: 1.5),
        ),
      ),
    );
  }

  Widget _redBtn(String label, VoidCallback? onTap) {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton(
        onPressed: onTap,
        style: ElevatedButton.styleFrom(
          backgroundColor: const Color(0xFFCC0000),
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(vertical: 14),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          elevation: 6,
          shadowColor: const Color(0xFFFF0000),
        ),
        child: Text(label, style: const TextStyle(fontWeight: FontWeight.bold)),
      ),
    );
  }

  Widget _resultCard(String content) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF0A0A0A),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFF2A2A00)),
      ),
      child: Text(
        content,
        textDirection: TextDirection.rtl,
        style: const TextStyle(color: Colors.white, fontSize: 14, height: 1.6),
      ),
    );
  }
}
