import 'package:flutter/material.dart';
import '../services/storage_service.dart';
import '../services/gemini_service.dart';
import '../services/voice_service.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final _apiCtrl = TextEditingController();
  bool _obscure = true;
  String _status = '';

  @override
  void initState() {
    super.initState();
    _loadKey();
  }

  Future<void> _loadKey() async {
    final key = await StorageService.getApiKey();
    if (key != null) {
      _apiCtrl.text = key;
    }
  }

  Future<void> _save() async {
    await StorageService.saveApiKey(_apiCtrl.text.trim());
    setState(() => _status = '✅ پاشەکەوتکرا');
    Future.delayed(const Duration(seconds: 2), () {
      if (mounted) setState(() => _status = '');
    });
  }

  @override
  void dispose() {
    _apiCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: const Color(0xFF050505),
        title: const Text('⚙️ ڕێکخستن',
            style: TextStyle(color: Colors.white, fontSize: 18)),
        iconTheme: const IconThemeData(color: Colors.white54),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(height: 1, color: const Color(0xFF1A0000)),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          // API Key section
          _sectionTitle('🔑 Gemini API Key'),
          const SizedBox(height: 8),
          const Text(
            'دەست بکە لە: aistudio.google.com',
            textDirection: TextDirection.rtl,
            style: TextStyle(color: Colors.white54, fontSize: 13),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _apiCtrl,
            obscureText: _obscure,
            style: const TextStyle(color: Colors.white, fontFamily: 'monospace', fontSize: 13),
            decoration: InputDecoration(
              filled: true,
              fillColor: const Color(0xFF0A0A0A),
              hintText: 'AIza...',
              hintStyle: const TextStyle(color: Color(0xFF444444)),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: const BorderSide(color: Color(0xFF2A0000)),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: const BorderSide(color: Color(0xFFFF0000)),
              ),
              suffixIcon: IconButton(
                icon: Icon(_obscure ? Icons.visibility : Icons.visibility_off,
                    color: Colors.white38),
                onPressed: () => setState(() => _obscure = !_obscure),
              ),
            ),
          ),
          const SizedBox(height: 12),
          ElevatedButton(
            onPressed: _save,
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFFCC0000),
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              padding: const EdgeInsets.symmetric(vertical: 14),
            ),
            child: const Text('پاشەکەوت بکە', style: TextStyle(fontWeight: FontWeight.bold)),
          ),
          if (_status.isNotEmpty) ...[
            const SizedBox(height: 8),
            Text(_status, textAlign: TextAlign.center,
                style: const TextStyle(color: Color(0xFF00CC00))),
          ],

          const SizedBox(height: 32),
          const Divider(color: Color(0xFF1A0000)),
          const SizedBox(height: 16),

          // Voice settings
          _sectionTitle('🎙️ دەنگی BlackDeath'),
          const SizedBox(height: 8),
          const Text(
            'دەنگی ترسناک — پێچ و خێرایی گۆڕ',
            textDirection: TextDirection.rtl,
            style: TextStyle(color: Colors.white54, fontSize: 13),
          ),
          const SizedBox(height: 16),
          _VoiceSliders(),

          const SizedBox(height: 32),
          const Divider(color: Color(0xFF1A0000)),
          const SizedBox(height: 16),

          // Clear history
          _sectionTitle('🗑️ مێژوو'),
          const SizedBox(height: 8),
          OutlinedButton(
            onPressed: () {
              GeminiService.clearHistory();
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('مێژووی گفتوگۆ سڕایەوە',
                      textDirection: TextDirection.rtl),
                  backgroundColor: Color(0xFF8B0000),
                ),
              );
            },
            style: OutlinedButton.styleFrom(
              foregroundColor: const Color(0xFFFF0000),
              side: const BorderSide(color: Color(0xFF8B0000)),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              padding: const EdgeInsets.symmetric(vertical: 14),
            ),
            child: const Text('سڕینەوەی مێژووی گفتوگۆ'),
          ),

          const SizedBox(height: 32),
          const Divider(color: Color(0xFF1A0000)),
          const SizedBox(height: 16),

          // About
          _sectionTitle('ℹ️ دەربارە'),
          const SizedBox(height: 12),
          _infoRow('ناو', 'BlackDeath AI'),
          _infoRow('وەشان', '1.0.0'),
          _infoRow('زمان', 'کوردی سۆرانی'),
          _infoRow('AI', 'Google Gemini'),
          _infoRow('دروستکراوە', 'بۆ iOS & Android'),

          const SizedBox(height: 48),
          const Center(
            child: Text(
              '☠ BlackDeath ☠',
              style: TextStyle(
                color: Color(0xFF3A0000),
                fontSize: 18,
                letterSpacing: 4,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _sectionTitle(String title) {
    return Text(
      title,
      textDirection: TextDirection.rtl,
      style: const TextStyle(
        color: Color(0xFFFF0000),
        fontSize: 16,
        fontWeight: FontWeight.bold,
      ),
    );
  }

  Widget _infoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(value, style: const TextStyle(color: Colors.white, fontSize: 14)),
          Text(label, style: const TextStyle(color: Colors.white54, fontSize: 14)),
        ],
      ),
    );
  }
}

/// ── Slider دەنگی ترسناک ────────────────────────────────────────────────────
class _VoiceSliders extends StatefulWidget {
  @override
  State<_VoiceSliders> createState() => _VoiceSlidersState();
}

class _VoiceSlidersState extends State<_VoiceSliders> {
  double _pitch = 0.45;  // نزم = ترسناک
  double _rate  = 0.38;  // هێواش = قور

  String _pitchLabel() {
    if (_pitch < 0.4) return '😈 ئەبلیس';
    if (_pitch < 0.6) return '☠ ترسناک';
    if (_pitch < 0.8) return '🤖 ڕۆبۆت';
    return '👤 ئاسایی';
  }

  String _rateLabel() {
    if (_rate < 0.35) return '🐢 زۆر هێواش';
    if (_rate < 0.5)  return '😈 هێواشی تاریک';
    if (_rate < 0.7)  return '🤖 ئاسایی';
    return '⚡ خێرا';
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF0A0A0A),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFF2A0000)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          // Pitch
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(_pitchLabel(),
                  style: const TextStyle(color: Color(0xFFFF0000), fontSize: 13)),
              const Text('پێچی دەنگ',
                  textDirection: TextDirection.rtl,
                  style: TextStyle(color: Colors.white70, fontSize: 13)),
            ],
          ),
          SliderTheme(
            data: SliderTheme.of(context).copyWith(
              activeTrackColor: const Color(0xFFFF0000),
              inactiveTrackColor: const Color(0xFF2A0000),
              thumbColor: const Color(0xFFFF0000),
              overlayColor: const Color(0x33FF0000),
            ),
            child: Slider(
              value: _pitch,
              min: 0.1,
              max: 1.0,
              onChanged: (v) {
                setState(() => _pitch = v);
                VoiceService.setVoiceStyle(pitch: _pitch, rate: _rate);
              },
            ),
          ),
          const SizedBox(height: 8),

          // Rate
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(_rateLabel(),
                  style: const TextStyle(color: Color(0xFFFF0000), fontSize: 13)),
              const Text('خێرایی قسەکردن',
                  textDirection: TextDirection.rtl,
                  style: TextStyle(color: Colors.white70, fontSize: 13)),
            ],
          ),
          SliderTheme(
            data: SliderTheme.of(context).copyWith(
              activeTrackColor: const Color(0xFFFF0000),
              inactiveTrackColor: const Color(0xFF2A0000),
              thumbColor: const Color(0xFFFF0000),
              overlayColor: const Color(0x33FF0000),
            ),
            child: Slider(
              value: _rate,
              min: 0.1,
              max: 1.0,
              onChanged: (v) {
                setState(() => _rate = v);
                VoiceService.setVoiceStyle(pitch: _pitch, rate: _rate);
              },
            ),
          ),
          const SizedBox(height: 12),

          // Test button
          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              onPressed: () async {
                await VoiceService.speak('من BlackDeath-م... تاریکی لەگەڵمە... 😈');
              },
              icon: const Icon(Icons.play_arrow, color: Color(0xFFFF0000), size: 18),
              label: const Text('تاقیکردنەوەی دەنگ ☠',
                  style: TextStyle(color: Color(0xFFFF0000))),
              style: OutlinedButton.styleFrom(
                side: const BorderSide(color: Color(0xFF8B0000)),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
