import 'dart:math';
import 'package:flutter/material.dart';
import '../services/storage_service.dart';
import '../services/voice_service.dart';
import '../services/mobile_control_service.dart';
import 'onboarding_screen.dart';
import 'home_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _pulse;
  late Animation<double> _fade;
  double _glitchOffset = 0;
  bool _showSubtitle = false;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2500),
    );
    _pulse = Tween<double>(begin: 0.85, end: 1.0).animate(
      CurvedAnimation(parent: _ctrl, curve: Curves.easeInOut),
    );
    _fade = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _ctrl, curve: const Interval(0.0, 0.5)),
    );

    _ctrl.repeat(reverse: true);

    // Glitch effect
    Future.delayed(const Duration(milliseconds: 400), () {
      _startGlitch();
    });

    Future.delayed(const Duration(milliseconds: 900), () {
      if (mounted) setState(() => _showSubtitle = true);
    });

    _initAndNavigate();
  }

  void _startGlitch() {
    for (int i = 0; i < 6; i++) {
      Future.delayed(Duration(milliseconds: i * 80), () {
        if (mounted) {
          setState(() {
            _glitchOffset = (Random().nextDouble() - 0.5) * 8;
          });
          Future.delayed(const Duration(milliseconds: 60), () {
            if (mounted) setState(() => _glitchOffset = 0);
          });
        }
      });
    }
  }

  Future<void> _initAndNavigate() async {
    await Future.wait([
      VoiceService.init(),
      MobileControlService.init(),
    ]);

    await Future.delayed(const Duration(seconds: 3));

    if (!mounted) return;

    final isOnboarded = StorageService.isOnboarded();
    Navigator.of(context).pushReplacement(
      PageRouteBuilder(
        pageBuilder: (_, __, ___) =>
            isOnboarded ? const HomeScreen() : const OnboardingScreen(),
        transitionsBuilder: (_, anim, __, child) =>
            FadeTransition(opacity: anim, child: child),
        transitionDuration: const Duration(milliseconds: 600),
      ),
    );
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          // Background grid
          CustomPaint(painter: _GridPainter(), size: Size.infinite),

          // Red glow center
          Center(
            child: AnimatedBuilder(
              animation: _ctrl,
              builder: (_, __) => Container(
                width: 300 * _pulse.value,
                height: 300 * _pulse.value,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFFFF0000).withOpacity(0.15 * _pulse.value),
                      blurRadius: 120,
                      spreadRadius: 60,
                    ),
                  ],
                ),
              ),
            ),
          ),

          // Main content
          Center(
            child: FadeTransition(
              opacity: _fade,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  // Logo skull / BD icon
                  Transform.translate(
                    offset: Offset(_glitchOffset, 0),
                    child: const _SkullIcon(),
                  ),
                  const SizedBox(height: 24),

                  // Title with glitch
                  Stack(
                    children: [
                      if (_glitchOffset != 0) ...[
                        Transform.translate(
                          offset: Offset(_glitchOffset * 2, 0),
                          child: const Text(
                            'BlackDeath',
                            style: TextStyle(
                              fontSize: 42,
                              fontWeight: FontWeight.w900,
                              color: Color(0xFF00FFFF),
                              letterSpacing: 4,
                            ),
                          ),
                        ),
                      ],
                      const Text(
                        'BlackDeath',
                        style: TextStyle(
                          fontSize: 42,
                          fontWeight: FontWeight.w900,
                          color: Color(0xFFFF0000),
                          letterSpacing: 4,
                          shadows: [
                            Shadow(color: Color(0xFFFF0000), blurRadius: 20),
                            Shadow(color: Color(0xFFFF0000), blurRadius: 40),
                          ],
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 8),

                  AnimatedOpacity(
                    opacity: _showSubtitle ? 1.0 : 0.0,
                    duration: const Duration(milliseconds: 500),
                    child: const Text(
                      'دەستیاری AI | کوردی سۆرانی',
                      style: TextStyle(
                        fontSize: 16,
                        color: Color(0xFF888888),
                        letterSpacing: 2,
                      ),
                      textDirection: TextDirection.rtl,
                    ),
                  ),

                  const SizedBox(height: 60),

                  // Loading bar
                  SizedBox(
                    width: 200,
                    child: AnimatedBuilder(
                      animation: _ctrl,
                      builder: (_, __) => LinearProgressIndicator(
                        value: null,
                        backgroundColor: const Color(0xFF1A0000),
                        valueColor: AlwaysStoppedAnimation<Color>(
                          Color.lerp(
                            const Color(0xFF8B0000),
                            const Color(0xFFFF0000),
                            _pulse.value,
                          )!,
                        ),
                        minHeight: 2,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _SkullIcon extends StatelessWidget {
  const _SkullIcon();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 80,
      height: 80,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        border: Border.all(color: const Color(0xFFFF0000), width: 2),
        boxShadow: const [
          BoxShadow(color: Color(0xFFFF0000), blurRadius: 20, spreadRadius: 2),
        ],
      ),
      child: const Center(
        child: Text(
          '☠',
          style: TextStyle(fontSize: 44, color: Color(0xFFFF0000)),
        ),
      ),
    );
  }
}

class _GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFF0D0D0D)
      ..strokeWidth = 0.5;
    const step = 40.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(_) => false;
}
