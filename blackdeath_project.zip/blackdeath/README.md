# ☠ BlackDeath AI

> دەستیاری AI-ی هەمە توانا بە کوردی سۆرانی — بۆ iOS و Android

---

## ✨ تایبەتمەندییەکان

| تایبەتمەندی | ڕووناکی |
|---|---|
| 🎤 قسەکردن | بانگکردن و قسەکردن بە دەنگ بە کوردی سۆرانی |
| 🧠 AI زیرەک | Gemini 2.0 Flash — وەڵامی هەر پرسیارێک |
| 🌐 ئاگاداری جیهان | زانیاری 2026، سۆشیاڵ مێدیا، تەکنەلۆژیا |
| 🔐 OSINT | گەڕانی ئینتیلیجنس، IP Lookup، هەواڵ |
| 📱 کۆنترۆڵی موبایل | باتری، نەت، کراوەکردنی ئاپ، تەلەفۆن، SMS |
| 🔔 ئاگادارکردنەوە | یادەوەری و نۆتیفیکەیشن |
| 🌤️ هەواشناسی | زانیاری کەشوهەوا بە کوردی |

---

## 🚀 چۆن دروست بکەیت

### پێشمەرجەکان
- Flutter SDK 3.2+
- Dart 3.2+
- Android Studio یان Xcode
- Gemini API Key (بەخۆڕایی: aistudio.google.com)

### دامەزراندن

```bash
# 1. پاکێجەکان دابمەزرێنە
flutter pub get

# 2. بۆ Android
flutter build apk --release
# فایلەکە: build/app/outputs/flutter-apk/app-release.apk

# 3. بۆ iOS
flutter build ios --release
# دواتر لە Xcode بکەیتەوە و Archive بکە
```

### ڕاکردن بۆ تاقیکردنەوە
```bash
flutter run
```

---

## 📁 پڕۆژەکە چۆنە

```
blackdeath/
├── lib/
│   ├── main.dart                    # سەرەتاکە
│   ├── screens/
│   │   ├── splash_screen.dart       # شاشەی دەستپێکردن (BlackDeath + گلیچ)
│   │   ├── onboarding_screen.dart   # دامەزراندنی یەکەم جار
│   │   ├── home_screen.dart         # پەڕەی سەرەکی (چات + کاڵ + تابەکان)
│   │   ├── osint_screen.dart        # OSINT - گەڕان + IP + هەواڵ
│   │   └── settings_screen.dart     # ڕێکخستن
│   ├── services/
│   │   ├── gemini_service.dart      # AI - Gemini API
│   │   ├── voice_service.dart       # دەنگ - STT + TTS
│   │   ├── mobile_control_service.dart  # کۆنترۆڵی موبایل
│   │   ├── osint_service.dart       # گەڕان و ئینتیلیجنس
│   │   └── storage_service.dart     # پاشەکەوتکردن
│   └── widgets/
│       ├── message_bubble.dart      # بابڵی پەیام
│       └── waveform_widget.dart     # وێوفۆرمی دەنگ
├── android/                         # Android - مۆڵەتەکان
├── ios/                             # iOS - Info.plist
└── pubspec.yaml                     # پاکێجەکان
```

---

## 🎤 فەرمانەکان (بە دەنگ)

| فەرمان | وەڵام |
|---|---|
| "بەتریم چەندە؟" | دەرئەنجامی باتری |
| "نەتم هەیە؟" | دەرئەنجامی ئینتەرنێت |
| "واتساپم بکەوەتە" | کراوەکردنی WhatsApp |
| "هەوای کرکوک چۆنە؟" | زانیاری کەشوهەوا |
| "ئیمڕۆ چی روودا؟" | گەڕانی هەواڵ |
| هەر پرسیارێک | Gemini AI وەڵامی دەداتەوە |

---

## 🎨 دیزاین

- **ڕەنگ:** ڕەش + سووری AI (Red-on-Black)
- **فۆنت:** کوردی سۆرانی (NotoKufi Arabic)
- **گلیچ ئەفێکت:** لە splash screen
- **وێوفۆرم:** جووڵەی دەنگ لە کاڵ مۆد
- **ئانیمەیشن:** پووڵس + fade

---

## 🔑 Gemini API Key

1. بڕۆ بۆ: https://aistudio.google.com
2. حیساب دروست بکە یان داخڵ بە
3. "Get API Key" دابگرتە
4. لە ئاپەکەدا: ڕێکخستن → API Key

---

## ☠ BlackDeath — دەستیاری AI-ی تۆ
