"""Local face-presence / eye-contact monitor for Ahmad Jarvis.

This module detects whether a face/eyes are visible in the local webcam feed.
It does NOT identify a person or perform biometric identity matching.
"""
from __future__ import annotations
import threading, time
from pathlib import Path
import cv2

class FaceMonitor:
    def __init__(self, on_frame=None, on_status=None):
        self.on_frame = on_frame
        self.on_status = on_status
        self.active = False
        self._stop = threading.Event()
        self._thread = None

    def start(self):
        if self.active:
            return "Face camera is already on."
        self._stop.clear(); self.active = True
        self._thread = threading.Thread(target=self._run, daemon=True, name="face-monitor")
        self._thread.start()
        return "Face camera is starting."

    def stop(self):
        self._stop.set(); self.active = False
        return "Face camera is off."

    def _run(self):
        cap = None
        try:
            # Prefer the saved camera index from the existing camera selector.
            idx = 0
            try:
                import json
                cfg = Path(__file__).resolve().parent.parent / "config" / "api_keys.json"
                idx = int(json.loads(cfg.read_text(encoding="utf-8")).get("camera_index", 0))
            except Exception:
                pass
            backend = cv2.CAP_DSHOW if __import__('sys').platform == 'win32' else cv2.CAP_ANY
            cap = cv2.VideoCapture(idx, backend)
            if not cap.isOpened():
                self._status("NO CAMERA")
                self.active = False
                return
            cap.set(cv2.CAP_PROP_FRAME_WIDTH, 960)
            cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 540)
            face_cascade = cv2.CascadeClassifier(str(Path(cv2.data.haarcascades) / 'haarcascade_frontalface_default.xml'))
            eye_cascade = cv2.CascadeClassifier(str(Path(cv2.data.haarcascades) / 'haarcascade_eye_tree_eyeglasses.xml'))
            last_status = ""
            while not self._stop.is_set():
                ok, frame = cap.read()
                if not ok:
                    time.sleep(.08); continue
                gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
                faces = face_cascade.detectMultiScale(gray, 1.1, 5, minSize=(70,70))
                eyes_total = 0
                for (x,y,w,h) in faces:
                    cv2.rectangle(frame, (x,y), (x+w,y+h), (0,0,255), 2)
                    roi = gray[y:y+h//2, x:x+w]
                    eyes = eye_cascade.detectMultiScale(roi, 1.1, 5, minSize=(20,20))
                    eyes_total += len(eyes)
                    for ex,ey,ew,eh in eyes[:2]:
                        cv2.rectangle(frame, (x+ex,y+ey), (x+ex+ew,y+ey+eh), (255,0,0), 1)
                status = "FACE + EYES DETECTED" if faces != () and len(faces) and eyes_total else ("FACE DETECTED" if len(faces) else "NO FACE")
                if status != last_status:
                    self._status(status); last_status = status
                ok2, enc = cv2.imencode('.jpg', frame, [int(cv2.IMWRITE_JPEG_QUALITY), 78])
                if ok2 and self.on_frame:
                    self.on_frame(enc.tobytes())
                time.sleep(.04)
        except Exception as e:
            self._status(f"FACE CAMERA ERROR: {e}")
        finally:
            if cap is not None:
                try: cap.release()
                except Exception: pass
            self.active = False

    def _status(self, s):
        if self.on_status:
            try: self.on_status(s)
            except Exception: pass
