"""AI website builder for JARVIS.
Generates a self-contained local HTML website with Gemini and opens it locally.
"""
from pathlib import Path
import json, os, re, subprocess, sys
from google import genai

BASE_DIR = Path(__file__).resolve().parent.parent
OUT_DIR = BASE_DIR / "generated_sites"
MODEL = "gemini-2.5-flash"


def _key():
    k = os.environ.get("GEMINI_API_KEY", "").strip()
    if k:
        return k
    try:
        return (json.loads((BASE_DIR / "config" / "api_keys.json").read_text(encoding="utf-8")).get("gemini_api_key") or "").strip()
    except Exception:
        return ""


def _slug(s):
    s = re.sub(r"[^a-zA-Z0-9_-]+", "-", (s or "jarvis-site")).strip("-").lower()
    return (s[:48] or "jarvis-site")


def _extract_html(text):
    m = re.search(r"```(?:html)?\s*(.*?)```", text or "", re.I | re.S)
    return (m.group(1) if m else (text or "")).strip()


def build_website(description: str, name: str = "jarvis-site", open_site: bool = True):
    description = (description or "").strip()
    if not description:
        return "Website description is required."
    key = _key()
    if not key:
        return "Gemini API key is not configured."

    prompt = f"""Create a polished modern single-page website for this request:\n{description}\n\nRules:\n- Return ONLY complete HTML, no Markdown fences.\n- One self-contained file: inline CSS and JavaScript, no external assets required.\n- Responsive on phone and desktop.\n- Accessible semantic HTML.\n- If Kurdish/Sorani text is requested, use proper UTF-8 and RTL layout.\n- Do not include tracking, credential collection, or malicious code.\n"""
    client = genai.Client(api_key=key)
    resp = client.models.generate_content(model=MODEL, contents=prompt)
    html = _extract_html(getattr(resp, "text", ""))
    if "<html" not in html.lower() or "<body" not in html.lower():
        return "Gemini returned invalid website HTML."

    folder = OUT_DIR / _slug(name)
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / "index.html"
    path.write_text(html, encoding="utf-8")

    if open_site:
        try:
            if sys.platform.startswith("win"):
                os.startfile(path)  # type: ignore[attr-defined]
            elif sys.platform == "darwin":
                subprocess.Popen(["open", str(path)])
            else:
                subprocess.Popen(["xdg-open", str(path)])
        except Exception:
            pass
    return f"AI website created: {path}"
