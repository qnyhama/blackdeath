import ipaddress, shutil, socket, subprocess

DEFAULT_PORTS = '80,443,554,8000,8080,8443,8554'

def _validate_target(target):
    net = ipaddress.ip_network(str(target).strip(), strict=False)
    if net.version != 4 or not (net.is_private or net.is_loopback or net.is_link_local):
        raise ValueError('Only private/local IPv4 targets are allowed (for example 192.168.1.0/24).')
    if net.num_addresses > 4096:
        raise ValueError('Network is too large. Use a range of at most 4096 addresses.')
    return net

def _ports(value):
    out=[]
    for part in str(value or DEFAULT_PORTS).split(','):
        part=part.strip()
        if not part: continue
        if '-' in part:
            a,b=map(int,part.split('-',1))
            if b<a or b-a>100: raise ValueError('Invalid port range.')
            out.extend(range(a,b+1))
        else: out.append(int(part))
    out=sorted(set(out))
    if not out or any(p<1 or p>65535 for p in out) or len(out)>256: raise ValueError('Invalid ports.')
    return out

def _fallback_scan(net, ports):
    rows=[]
    for ip in net.hosts():
        for p in ports:
            s=socket.socket(); s.settimeout(0.18)
            try:
                if s.connect_ex((str(ip),p))==0:
                    rows.append({'ip':str(ip),'port':p,'state':'open','camera_hint':p in (554,8554,8000,8080,80,443,8443)})
            finally: s.close()
    return rows

def camera_security_scan(target, ports=DEFAULT_PORTS, service_detection=True):
    net=_validate_target(target); port_list=_ports(ports); port_arg=','.join(map(str,port_list))
    nmap=shutil.which('nmap')
    if nmap:
        cmd=[nmap,'-n','-T3','--open','-p',port_arg]
        if service_detection: cmd += ['-sV','--version-light']
        cmd += [str(net)]
        cp=subprocess.run(cmd,capture_output=True,text=True,timeout=240)
        return {'mode':'nmap','target':str(net),'ports':port_list,'output':cp.stdout,'error':cp.stderr,'returncode':cp.returncode}
    return {'mode':'fallback_tcp','target':str(net),'ports':port_list,'results':_fallback_scan(net,port_list),'note':'Nmap was not found; basic TCP inventory was used.'}

def camera_security_action(parameters):
    action=(parameters or {}).get('action','scan')
    if action not in ('scan','inventory'):
        raise ValueError('Supported actions: scan, inventory')
    return camera_security_scan((parameters or {}).get('target'), (parameters or {}).get('ports',DEFAULT_PORTS), (parameters or {}).get('service_detection',True))
